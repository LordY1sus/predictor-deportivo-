import unittest
from unittest.mock import patch
from app.providers.api_sports import (
    parse_football_lineups, fetch_football_lineups, fetch_football_injuries, APISportsError
)


def lineup_item(team_id, name, prefix):
    return {
        "team": {"id": team_id, "name": name},
        "formation": "4-3-3",
        "coach": {"name": "Coach " + name},
        "startXI": [{"player": {"id": i, "name": f"{prefix} Player {i}"}}
                    for i in range(1, 12)],
        "substitutes": [{"player": {"id": 99, "name": prefix + " Substitute"}}],
    }


class APISportsLineupTests(unittest.TestCase):
    def setUp(self):
        self.payload = {"errors": [], "response": [
            lineup_item(1, "Home FC", "H"), lineup_item(2, "Away FC", "A")
        ]}

    def test_parse_complete_official_lineups(self):
        record = parse_football_lineups(self.payload, "Home FC", "Away FC",
                                        "2026-11-22T12:00:00+00:00")
        self.assertEqual(record["status"], "official")
        self.assertEqual(len(record["teams"]["home"]["starters"]), 11)
        self.assertEqual(len(record["teams"]["away"]["starters"]), 11)
        self.assertEqual(record["source"], "api_sports_official_lineups")

    def test_rejects_missing_team(self):
        with self.assertRaises(APISportsError):
            parse_football_lineups({"errors": [], "response": [self.payload["response"][0]]},
                                   "Home FC", "Away FC")

    def test_rejects_incomplete_starting_eleven(self):
        broken = {"errors": [], "response": [dict(x) for x in self.payload["response"]]}
        broken["response"][0] = dict(broken["response"][0])
        broken["response"][0]["startXI"] = broken["response"][0]["startXI"][:10]
        with self.assertRaises(APISportsError):
            parse_football_lineups(broken, "Home FC", "Away FC")

    def test_rejects_duplicate_starter_names(self):
        broken = {"errors": [], "response": [dict(x) for x in self.payload["response"]]}
        broken["response"][0] = dict(broken["response"][0])
        broken["response"][0]["startXI"] = list(broken["response"][0]["startXI"])
        broken["response"][0]["startXI"][1] = {"player": {"name": "H Player 1"}}
        with self.assertRaises(APISportsError):
            parse_football_lineups(broken, "Home FC", "Away FC")

    @patch("app.providers.api_sports._request_json")
    def test_fetch_lineups_uses_fixture_id_and_key_header(self, request):
        request.return_value = (self.payload, {"x-ratelimit-requests-remaining": "87"})
        result = fetch_football_lineups(123, "Home FC", "Away FC", "secret")
        self.assertEqual(result["lineup"]["status"], "official")
        self.assertIn("fixture=123", request.call_args.args[0])
        self.assertNotIn("secret", request.call_args.args[0])

    @patch("app.providers.api_sports._request_json")
    def test_parse_injury_observations_without_fabricated_publication_date(self, request):
        request.return_value = ({"errors": [], "response": [{
            "fixture": {"id": 123}, "team": {"name": "Home FC"},
            "player": {"id": 5, "name": "Player X", "type": "Missing Fixture", "reason": "Injury"}
        }]}, {})
        result = fetch_football_injuries(123, "secret", captured_at="2026-11-22T12:00:00+00:00")
        self.assertEqual(result["reports"][0]["player_name"], "Player X")
        self.assertIn("provider_observed_at", result["reports"][0])
        self.assertNotIn("published_at", result["reports"][0])


if __name__ == "__main__":
    unittest.main()
