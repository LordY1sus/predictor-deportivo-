import unittest
from datetime import timezone
from app.providers.espn_scoreboard import parse_scoreboard
from app.storage.database import Database
import tempfile, os

class ProviderTests(unittest.TestCase):
    def test_parse_espn_event(self):
        data={"events":[{"id":"42","date":"2026-11-23T01:00:00Z",
          "status":{"type":{"state":"pre","completed":False}},
          "competitions":[{"competitors":[
            {"homeAway":"home","team":{"displayName":"Home FC"}},
            {"homeAway":"away","team":{"displayName":"Away FC"}}]}]}]}
        rows=parse_scoreboard(data,"football",timezone.utc)
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]["status"],"SCHEDULED")
        self.assertEqual(rows[0]["home_name"],"Home FC")

    def test_odds_match_requires_teams_and_near_time(self):
        path=tempfile.mktemp()
        db=Database(path)
        db.upsert_match({"id":"m1","sport":"football","home_name":"Home FC","away_name":"Away FC",
          "kickoff_utc":"2026-11-23T01:00:00+00:00","kickoff_local":"2026-11-22T17:00:00-08:00",
          "status":"SCHEDULED"})
        self.assertEqual(db.find_match_for_odds("football","Home FC","Away FC","2026-11-23T01:10:00+00:00"),"m1")
        self.assertIsNone(db.find_match_for_odds("football","Other FC","Away FC","2026-11-23T01:10:00+00:00"))
        db.close(); os.remove(path)

if __name__ == "__main__": unittest.main()
