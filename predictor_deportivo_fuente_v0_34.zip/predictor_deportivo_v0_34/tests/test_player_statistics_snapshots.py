import unittest
from datetime import datetime, timezone
from unittest.mock import patch
from app.storage.database import Database
from app.providers.api_sports import APISportsError, parse_football_player_statistics, fetch_football_player_statistics
from app.services.player_statistics import PlayerStatisticsSnapshotService


class PlayerStatisticsSnapshotTests(unittest.TestCase):
    def setUp(self):
        self.db = Database(":memory:")
        self.kickoff = "2026-11-23T20:00:00+00:00"

    def tearDown(self):
        self.db.conn.close()

    def sample(self):
        return {"response": [{"player": {"id": 7, "name": "Forward One"},
            "statistics": [{"team": {"id": 10, "name": "Home FC"},
                "games": {"position": "Attacker", "appearences": 12},
                "goals": {"total": 8, "assists": 2}}]}]}

    def test_parser_retains_player_stats_and_capture_time(self):
        rows = parse_football_player_statistics(self.sample(), "2026-11-23T18:00:00+00:00", self.kickoff)
        self.assertEqual(rows[0]["player_id"], "7")
        self.assertEqual(rows[0]["stats"]["goals"]["total"], 8)
        self.assertEqual(rows[0]["team_id"], "10")

    def test_parser_rejects_future_snapshot(self):
        with self.assertRaises(APISportsError):
            parse_football_player_statistics(self.sample(), "2026-11-23T21:00:00+00:00", self.kickoff)

    @patch("app.providers.api_sports._request_json")
    def test_fetch_uses_team_league_season_and_pagination(self, request):
        request.return_value = (self.sample(), {"x-ratelimit-requests-remaining": "99"})
        result = fetch_football_player_statistics(10, 39, 2026, "secret", page=2,
            kickoff_utc=self.kickoff, captured_at="2026-11-23T18:00:00+00:00")
        self.assertEqual(result["page"], 2)
        self.assertIn("team=10", request.call_args.args[0])
        self.assertIn("page=2", request.call_args.args[0])

    def test_capture_persists_and_lineup_reads_only_pre_kickoff_snapshot(self):
        from app.services.player_statistics import PlayerStatisticsSnapshotService
        service = PlayerStatisticsSnapshotService(self.db)
        payload = self.sample()
        with patch("app.providers.api_sports._request_json", return_value=(payload, {})):
            service.capture_football_team(10, 39, 2026, "secret", self.kickoff,
                captured_at="2026-11-23T18:00:00+00:00")
        lineup = {"teams": {"home": {"starters": ["Forward One"]}, "away": {"starters": []}}}
        snapshot = service.lineup_snapshot(lineup, self.kickoff)
        self.assertEqual(len(snapshot["home:Forward One"]), 1)
        self.assertEqual(snapshot["home:Forward One"][0]["stats"]["season_stats"]["goals"]["total"], 8)

    def test_lineup_does_not_use_post_kickoff_observation(self):
        self.db.save_player_observation({"id":"future", "sport":"football", "player_id":"7",
            "team_name":"Home FC", "observed_at":"2026-11-23T21:00:00+00:00",
            "source":"test", "stats":{"player_name":"Forward One","goals":{ "total":99}}})
        lineup = {"teams": {"home": {"starters": ["Forward One"]}, "away": {"starters": []}}}
        snapshot = PlayerStatisticsSnapshotService(self.db).lineup_snapshot(lineup, self.kickoff)
        self.assertEqual(snapshot["home:Forward One"], [])


if __name__ == "__main__":
    unittest.main()
