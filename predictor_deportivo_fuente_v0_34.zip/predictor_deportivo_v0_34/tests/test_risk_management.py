import unittest
from app.analytics.risk_management import calculate_stake, simulate_bankroll


class RiskManagementTests(unittest.TestCase):
    def test_positive_edge_stake_is_capped(self):
        result = calculate_stake(1000, 0.60, 2.0)
        self.assertTrue(result['eligible'])
        self.assertAlmostEqual(result['stake'], 10.0)
        self.assertAlmostEqual(result['stake_pct'], 0.01)

    def test_no_edge_means_zero_stake(self):
        result = calculate_stake(1000, 0.50, 2.0)
        self.assertFalse(result['eligible'])
        self.assertEqual(result['stake'], 0)

    def test_negative_edge_means_zero_stake(self):
        self.assertEqual(calculate_stake(1000, 0.4, 2.0)['stake'], 0)

    def test_custom_fraction_and_cap(self):
        result = calculate_stake(500, 0.7, 2.0, kelly_fraction=0.5, max_stake_pct=0.02)
        self.assertAlmostEqual(result['stake'], 10)

    def test_invalid_bankroll_rejected(self):
        with self.assertRaises(ValueError):
            calculate_stake(0, 0.6, 2)

    def test_invalid_probability_rejected(self):
        with self.assertRaises(ValueError):
            calculate_stake(100, 1, 2)

    def test_non_finite_values_rejected(self):
        with self.assertRaises(ValueError):
            calculate_stake(float('nan'), .6, 2)

    def test_simulate_win_loss_push(self):
        result = simulate_bankroll(100, [
            {'stake': 10, 'decimal_odds': 2, 'outcome': 'win'},
            {'stake': 10, 'decimal_odds': 2, 'outcome': 'loss'},
            {'stake': 5, 'decimal_odds': 2, 'outcome': 'push'},
        ])
        self.assertAlmostEqual(result['ending_bankroll'], 100)
        self.assertEqual((result['wins'], result['losses'], result['pushes']), (1, 1, 1))
        self.assertAlmostEqual(result['max_drawdown_pct'], 10 / 110)

    def test_loss_cannot_exceed_available_balance(self):
        with self.assertRaises(ValueError):
            simulate_bankroll(10, [{'stake': 11, 'decimal_odds': 2, 'outcome': 'loss'}])

    def test_unknown_outcome_rejected(self):
        with self.assertRaises(ValueError):
            simulate_bankroll(100, [{'stake': 5, 'decimal_odds': 2, 'outcome': 'void'}])

    def test_empty_simulation(self):
        result = simulate_bankroll(250, [])
        self.assertEqual(result['ending_bankroll'], 250)
        self.assertEqual(result['max_drawdown_pct'], 0)


if __name__ == '__main__':
    unittest.main()
