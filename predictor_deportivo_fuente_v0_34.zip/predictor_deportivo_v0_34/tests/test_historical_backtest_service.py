import json, os, tempfile, unittest
from app.storage.database import Database
from app.services.historical_backtest import HistoricalBacktestService


class HistoricalBacktestServiceTests(unittest.TestCase):
    def setUp(self):
        self.path = tempfile.mktemp()
        self.db = Database(self.path)
        self.service = HistoricalBacktestService(self.db)
        self.match = {"id": "espn:football:100", "sport": "football",
                      "home_name": "Home FC", "away_name": "Away FC",
                      "kickoff_utc": "2026-11-20T20:00:00+00:00",
                      "kickoff_local": "2026-11-20T20:00:00+00:00", "status": "FINISHED"}
        self.db.upsert_match(self.match)
        self.db.save_historical_result({"id": "espn:football:100", "sport": "football",
            "home_name": "Home FC", "away_name": "Away FC",
            "kickoff_utc": "2026-11-20T20:00:00+00:00", "home_score": 2,
            "away_score": 1, "source": "espn_scoreboard",
            "captured_at": "2026-11-21T01:00:00+00:00"})

    def tearDown(self):
        self.db.close()
        if os.path.exists(self.path): os.remove(self.path)

    def projection(self, created, probs):
        snapshot = {"generated_input_at": created,
                    "payload": {"observations": [{"observed_at": "2026-11-20T17:00:00+00:00"}]},
                    "lineup": {"status": "official", "source": "https://league.example/lineups",
                               "confirmed_at": "2026-11-20T18:00:00+00:00"}}
        with self.db.lock:
            self.db.conn.execute("""INSERT INTO projections
                (match_id,created_at,simulations,result_json,input_snapshot_json,model_version,seed)
                VALUES(?,?,?,?,?,?,?)""",
                (self.match["id"], created, 10000, json.dumps(probs), json.dumps(snapshot), "test", 1))
            self.db.conn.commit()

    def test_uses_latest_projection_before_kickoff(self):
        self.projection("2026-11-20T18:00:00+00:00", {"home_win": .2, "draw": .4, "away_win": .4})
        self.projection("2026-11-20T19:59:00+00:00", {"home_win": .7, "draw": .2, "away_win": .1})
        report = self.service.evaluate("football")
        self.assertEqual(report["samples"], 1)
        self.assertEqual(report["by_sport"]["football"]["accuracy"], 1.0)
        self.assertEqual(report["by_period"]["football"]["2026-11"]["samples"], 1)
        self.assertIn("descriptive only", report["period_grouping"])


    def test_period_breakdown_separates_utc_months(self):
        self.projection("2026-11-20T19:00:00+00:00", {"home_win": .6, "draw": .2, "away_win": .2})
        report = self.service.evaluate("football")
        self.assertEqual(list(report["by_period"]["football"]), ["2026-11"])
        self.assertEqual(report["by_period"]["football"]["2026-11"]["samples"], 1)

    def test_excludes_projection_created_after_kickoff(self):
        self.projection("2026-11-20T20:01:00+00:00", {"home_win": .9, "draw": .05, "away_win": .05})
        report = self.service.evaluate("football")
        self.assertEqual(report["samples"], 0)
        self.assertEqual(report["exclusions"]["without_pre_match_projection"], 1)

    def test_rejects_result_captured_before_kickoff(self):
        with self.db.lock:
            self.db.conn.execute("UPDATE historical_results SET captured_at=? WHERE id=?",
                                 ("2026-11-20T19:00:00+00:00", "espn:football:100"))
            self.db.conn.commit()
        self.projection("2026-11-20T19:00:00+00:00", {"home_win": .6, "draw": .2, "away_win": .2})
        report = self.service.evaluate("football")
        self.assertEqual(report["samples"], 0)
        self.assertEqual(report["exclusions"]["invalid_result"], 1)

    def test_evaluates_basketball_binary_probabilities(self):
        match = {"id": "espn:basketball:200", "sport": "basketball",
                 "home_name": "Lakers", "away_name": "Celtics",
                 "kickoff_utc": "2026-11-20T22:00:00+00:00",
                 "kickoff_local": "2026-11-20T22:00:00+00:00", "status": "FINISHED"}
        self.db.upsert_match(match)
        self.db.save_historical_result({"id": "espn:basketball:200", "sport": "basketball",
            "home_name": "Lakers", "away_name": "Celtics", "kickoff_utc": match["kickoff_utc"],
            "home_score": 110, "away_score": 105, "source": "espn_scoreboard",
            "captured_at": "2026-11-21T02:00:00+00:00"})
        with self.db.lock:
            snapshot = {"generated_input_at": "2026-11-20T21:00:00+00:00",
                        "payload": {"observations": [{"observed_at": "2026-11-20T19:00:00+00:00"}]},
                        "lineup": {"status": "official", "source": "https://league.example/lineups",
                                   "confirmed_at": "2026-11-20T20:00:00+00:00"}}
            self.db.conn.execute("""INSERT INTO projections
                (match_id,created_at,simulations,result_json,input_snapshot_json,model_version,seed)
                VALUES(?,?,?,?,?,?,?)""",
                (match["id"], "2026-11-20T21:00:00+00:00", 10000,
                 json.dumps({"home_win": .7, "away_win": .3}), json.dumps(snapshot), "test", 1))
            self.db.conn.commit()
        report = self.service.evaluate("basketball")
        self.assertEqual(report["samples"], 1)
        self.assertEqual(report["by_sport"]["basketball"]["accuracy"], 1.0)

    def test_rejects_ambiguous_result_match(self):
        self.db.save_historical_result({"id": "second", "sport": "football",
            "home_name": "Home FC", "away_name": "Away FC",
            "kickoff_utc": "2026-11-20T20:00:00+00:00", "home_score": 1,
            "away_score": 0, "source": "other", "captured_at": "2026-11-21T01:00:00+00:00"})
        self.projection("2026-11-20T19:00:00+00:00", {"home_win": .6, "draw": .2, "away_win": .2})
        report = self.service.evaluate("football")
        self.assertEqual(report["samples"], 0)
        self.assertEqual(report["exclusions"]["ambiguous_result"], 1)

    def test_aliases_match_historical_team_names(self):
        self.db.save_team_alias("football", "Home FC", "Home United")
        self.db.save_team_alias("football", "Away FC", "Away United")
        # Match event uses the canonical labels while the stored result retains original labels.
        with self.db.lock:
            self.db.conn.execute("UPDATE matches SET home_name='Home United', away_name='Away United' WHERE id=?",
                                 (self.match["id"],))
            self.db.conn.commit()
        self.projection("2026-11-20T19:00:00+00:00", {"home_win": .6, "draw": .2, "away_win": .2})
        self.assertEqual(self.service.evaluate("football")["samples"], 1)


if __name__ == "__main__": unittest.main()
