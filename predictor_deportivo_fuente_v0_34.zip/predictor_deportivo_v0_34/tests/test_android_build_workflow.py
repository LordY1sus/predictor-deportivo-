from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]


class AndroidBuildWorkflowTests(unittest.TestCase):
    def test_workflow_runs_tests_before_build_and_publishes_release_asset(self):
        workflow = (ROOT / ".github/workflows/android-apk.yml").read_text(encoding="utf-8")
        self.assertIn("needs: test", workflow)
        self.assertIn("needs: build", workflow)
        self.assertIn("softprops/action-gh-release@v2", workflow)
        self.assertIn("dist/*.apk", workflow)
        self.assertIn("contents: write", workflow)
        self.assertIn("if-no-files-found: error", workflow)

    def test_workflow_uses_matching_artifact_name_across_jobs(self):
        workflow = (ROOT / ".github/workflows/android-apk.yml").read_text(encoding="utf-8")
        expected = "predictor-deportivo-${{ github.ref_name }}-debug-apk"
        self.assertEqual(workflow.count(expected), 2)

    def test_workflow_checks_apk_integrity_and_arm64_before_upload(self):
        workflow = (ROOT / ".github/workflows/android-apk.yml").read_text(encoding="utf-8")
        self.assertIn('unzip -t "${apks[0]}"', workflow)
        self.assertIn("^lib/arm64-v8a/", workflow)
        self.assertIn("sha256sum", workflow)
        self.assertIn("SHA256SUMS.txt", workflow)

    def test_android_package_excludes_tests_and_python_bytecode(self):
        spec = (ROOT / "buildozer.spec").read_text(encoding="utf-8")
        self.assertIn("source.exclude_dirs = tests,.git,.github,__pycache__", spec)
        self.assertIn("source.exclude_patterns = *.pyc,*/__pycache__/*", spec)
        self.assertIn("android.archs = arm64-v8a", spec)


if __name__ == "__main__":
    unittest.main()
