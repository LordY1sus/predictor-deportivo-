import os
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from app.storage.database import Database
from app.services.lineup_intake import LineupIntakeService
from app.services.lineup_validator import validate_lineup


class LineupIntakeTests(unittest.TestCase):
    def setUp(self):
        self.path = tempfile.mktemp()
        self.db = Database(self.path)
        self.kickoff = (datetime.now(timezone.utc) + timedelta(days=1)).isoformat()
        self.db.upsert_match({
            "id": "match-1", "sport": "football", "home_name": "Home",
            "away_name": "Away", "kickoff_utc": self.kickoff,
            "kickoff_local": self.kickoff, "status": "SCHEDULED", "payload": {}
        })
        self.service = LineupIntakeService(self.db)

    def tearDown(self):
        self.db.close()
        if os.path.exists(self.path): os.remove(self.path)

    def teams(self, n=11):
        return {side: {"starters": [f"{side}-{i}" for i in range(n)]}
                for side in ("home", "away")}

    def test_saves_user_attested_official_lineup(self):
        record = self.service.save_user_confirmed_official(
            "match-1", self.teams(), "https://league.example/lineups", user_attested=True)
        self.assertEqual(record["verification_method"], "user_attested_manual_entry")
        self.assertEqual(len(self.db.get_lineup("match-1")["teams"]["home"]["starters"]), 11)

    def test_requires_explicit_user_attestation(self):
        with self.assertRaisesRegex(ValueError, "Confirmar|confirmar"):
            self.service.save_user_confirmed_official(
                "match-1", self.teams(), "https://league.example/lineups", user_attested=False)

    def test_rejects_non_https_or_http_source(self):
        with self.assertRaisesRegex(ValueError, "enlace"):
            self.service.save_user_confirmed_official(
                "match-1", self.teams(), "league.example/lineups", user_attested=True)

    def test_rejects_wrong_starter_count(self):
        with self.assertRaisesRegex(ValueError, "11 titulares"):
            self.service.save_user_confirmed_official(
                "match-1", self.teams(10), "https://league.example/lineups", user_attested=True)

    def test_rejects_lineup_confirmed_after_kickoff(self):
        kickoff = datetime.fromisoformat(self.kickoff)
        with self.assertRaisesRegex(ValueError, "antes del inicio"):
            self.service.save_user_confirmed_official(
                "match-1", self.teams(), "https://league.example/lineups",
                confirmed_at=(kickoff + timedelta(minutes=1)).isoformat(), user_attested=True)

    def test_rejects_live_match(self):
        self.db.upsert_match({
            "id": "match-1", "sport": "football", "home_name": "Home", "away_name": "Away",
            "kickoff_utc": self.kickoff, "kickoff_local": self.kickoff,
            "status": "LIVE", "payload": {}
        })
        with self.assertRaisesRegex(ValueError, "programados"):
            self.service.save_user_confirmed_official(
                "match-1", self.teams(), "https://league.example/lineups", user_attested=True)

    def test_basketball_requires_official_injury_report(self):
        self.db.upsert_match({
            "id": "basket-1", "sport": "basketball", "home_name": "Home", "away_name": "Away",
            "kickoff_utc": self.kickoff, "kickoff_local": self.kickoff,
            "status": "SCHEDULED", "payload": {}
        })
        teams = self.teams(5)
        with self.assertRaisesRegex(ValueError, "informe oficial de lesiones"):
            self.service.save_user_confirmed_official(
                "basket-1", teams, "https://league.example/lineups", user_attested=True)

    def test_baseball_requires_starting_pitchers(self):
        self.db.upsert_match({
            "id": "baseball-1", "sport": "baseball", "home_name": "Home", "away_name": "Away",
            "kickoff_utc": self.kickoff, "kickoff_local": self.kickoff,
            "status": "SCHEDULED", "payload": {}
        })
        with self.assertRaisesRegex(ValueError, "pitcher abridor"):
            self.service.save_user_confirmed_official(
                "baseball-1", self.teams(9), "https://league.example/lineups", user_attested=True)


if __name__ == "__main__":
    unittest.main()
