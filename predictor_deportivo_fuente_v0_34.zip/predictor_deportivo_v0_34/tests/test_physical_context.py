import unittest
from datetime import datetime,timezone,timedelta
from app.services.physical_context import calculate_rest_context
from app.services.lineup_validator import validate_lineup

class PhysicalContextTests(unittest.TestCase):
    def test_rest_period(self):
        now=datetime.now(timezone.utc)
        previous=(now-timedelta(hours=48)).isoformat()
        result=calculate_rest_context(previous,now.isoformat())
        self.assertEqual(result["rest_hours"],48)
        self.assertTrue(result["rest_short"])

    def test_travel_requires_provenance(self):
        now=datetime.now(timezone.utc)
        with self.assertRaises(ValueError):
            calculate_rest_context(None,now.isoformat(),travel_km=120)

    def test_travel_timestamp_must_be_pre_match(self):
        now=datetime.now(timezone.utc)
        with self.assertRaises(ValueError):
            calculate_rest_context(None,now.isoformat(),travel_km=120,
                                   observed_at=(now+timedelta(minutes=1)).isoformat(),source="test")

    def test_football_lineup_requires_11_unique_names(self):
        now=datetime.now(timezone.utc)
        kickoff=(now+timedelta(hours=2)).isoformat()
        team=["Player "+str(i) for i in range(11)]
        record={"status":"official","source":"league","confirmed_at":now.isoformat(),
                "teams":{"home":{"starters":team},"away":{"starters":team}}}
        self.assertTrue(validate_lineup("football",record,kickoff))
        record["teams"]["home"]["starters"][0]="Player 1"
        with self.assertRaises(ValueError): validate_lineup("football",record,kickoff)

    def test_basketball_injury_report_needs_provenance(self):
        now=datetime.now(timezone.utc); kickoff=(now+timedelta(hours=2)).isoformat()
        team=["P"+str(i) for i in range(5)]
        record={"status":"official","source":"league","confirmed_at":now.isoformat(),
                "teams":{"home":{"starters":team},"away":{"starters":team}},
                "official_injury_report":{"source":"league","published_at":now.isoformat()}}
        self.assertTrue(validate_lineup("basketball",record,kickoff))
        record["official_injury_report"]={"source":"league"}
        with self.assertRaises(ValueError): validate_lineup("basketball",record,kickoff)

if __name__=="__main__": unittest.main()
