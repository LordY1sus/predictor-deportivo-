import unittest
from datetime import datetime,timezone,timedelta
from app.services.historical_form import summarize_team_form
from app.analytics.backtesting import evaluate_multiclass,evaluate_binary

class HistoricalAndBacktestTests(unittest.TestCase):
    def test_form_excludes_future_results(self):
        now=datetime.now(timezone.utc)
        rows=[
          {"sport":"football","home_name":"A","away_name":"B","kickoff_utc":(now-timedelta(days=1)).isoformat(),"home_score":2,"away_score":0},
          {"sport":"football","home_name":"A","away_name":"C","kickoff_utc":(now+timedelta(days=1)).isoformat(),"home_score":0,"away_score":3},
        ]
        r=summarize_team_form(rows,"A","football",now.isoformat())
        self.assertEqual(r["games"],1)
        self.assertEqual(r["win_rate"],1.0)

    def test_empty_form_has_no_fake_averages(self):
        r=summarize_team_form([],"A","football",datetime.now(timezone.utc).isoformat())
        self.assertIsNone(r["scoring_average"])

    def test_multiclass_metrics(self):
        rows=[{"probabilities":{"home_win":.8,"draw":.1,"away_win":.1},"outcome":"home_win"}]
        r=evaluate_multiclass(rows)
        self.assertEqual(r["accuracy"],1.0)
        self.assertGreaterEqual(r["brier_score"],0)

    def test_reject_probabilities_not_summing_to_one(self):
        with self.assertRaises(ValueError):
            evaluate_multiclass([{"probabilities":{"home_win":.8,"draw":.1,"away_win":.3},"outcome":"home_win"}])

    def test_binary_metrics(self):
        r=evaluate_binary([{"probability":.9,"outcome":1},{"probability":.2,"outcome":0}])
        self.assertEqual(r["accuracy"],1.0)
        self.assertIn("expected_calibration_error", r)
        self.assertEqual(r["expected_calibration_error"], 0.15)
        self.assertEqual(sum(x["samples"] for x in r["calibration_bins"]), 2)

    def test_multiclass_calibration_uses_confidence_of_predicted_class(self):
        rows = [
            {"probabilities":{"home_win":.8,"draw":.1,"away_win":.1},"outcome":"home_win"},
            {"probabilities":{"home_win":.7,"draw":.2,"away_win":.1},"outcome":"away_win"},
        ]
        r = evaluate_multiclass(rows)
        self.assertAlmostEqual(r["expected_calibration_error"], .45)
        self.assertEqual(r["calibration_bins"][0]["samples"], 1)

    def test_rejects_non_finite_probabilities(self):
        with self.assertRaises(ValueError):
            evaluate_binary([{"probability":float("nan"),"outcome":1}])

if __name__=="__main__": unittest.main()
