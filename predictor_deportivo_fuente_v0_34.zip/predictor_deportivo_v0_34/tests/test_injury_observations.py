import unittest
from app.storage.database import Database


class InjuryObservationTests(unittest.TestCase):
    def setUp(self):
        self.db = Database(":memory:")
        self.db.upsert_match({"id":"m1","sport":"football","home_name":"Home","away_name":"Away",
            "kickoff_utc":"2026-11-23T20:00:00+00:00","kickoff_local":"2026-11-23T12:00:00-08:00",
            "status":"SCHEDULED","payload":{}})

    def tearDown(self):
        self.db.close()

    def test_save_and_read_injury_observation(self):
        report = {"player_id":"9","player_name":"Player","team_name":"Home","type":"Missing Fixture",
                  "reason":"Injury","provider_observed_at":"2026-11-22T12:00:00+00:00","source":"api_sports"}
        self.assertEqual(self.db.save_injury_observations("m1", [report]), 1)
        self.assertEqual(self.db.save_injury_observations("m1", [report]), 0)
        rows = self.db.get_injury_observations("m1", "2026-11-23T20:00:00+00:00")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["player_name"], "Player")

    def test_future_observations_excluded_by_cutoff(self):
        report = {"player_id":"9","player_name":"Player","team_name":"Home","type":"Questionable",
                  "reason":"Test","provider_observed_at":"2026-11-24T12:00:00+00:00","source":"api_sports"}
        self.db.save_injury_observations("m1", [report])
        self.assertEqual(self.db.get_injury_observations("m1", "2026-11-23T20:00:00+00:00"), [])


if __name__ == "__main__": unittest.main()
