import unittest
from app.storage.database import Database
from app.services.team_statistics_expectations import TeamStatisticsExpectationService


class TeamStatisticsExpectationTests(unittest.TestCase):
    def setUp(self):
        self.db = Database(":memory:")
        self.match = {"sport": "football", "kickoff_utc": "2026-11-23T20:00:00+00:00",
                      "payload_json": '{"home_team_id":10,"away_team_id":20,"league_id":39,"season":2026}'}

    def tearDown(self):
        self.db.close()

    def save(self, team_id, goals_for, goals_against):
        self.db.save_team_stat_observation({
            "sport": "football", "team_id": str(team_id), "team_name": str(team_id),
            "league_id": "39", "competition": "Premier League", "season": "2026",
            "valid_before": "2026-11-22", "observed_at": "2026-11-22T12:00:00+00:00",
            "source": "test", "statistics": {
                "fixtures": {"played": {"home": 2, "away": 2}},
                "goals": {"for": {"total": {"home": goals_for, "away": goals_for}},
                          "against": {"total": {"home": goals_against, "away": goals_against}}}
            }})

    def test_official_venue_rates_blend_into_historical_expectations(self):
        self.save(10, 2, 1)
        self.save(20, 3, 4)
        payload = {"home": {"expected_goals": 2.5}, "away": {"expected_goals": 2.5},
                   "observations": [{"observed_at": "2026-11-22T09:00:00+00:00", "source": "history"}]}
        result = TeamStatisticsExpectationService(self.db).apply(self.match, payload)
        self.assertAlmostEqual(result["home"]["expected_goals"], 1.85)
        self.assertAlmostEqual(result["away"]["expected_goals"], 1.525)
        self.assertEqual(result["team_statistics_adjustment"]["method"], "venue_specific_goals_rates_blend")
        self.assertEqual(len(result["observations"]), 2)

    def test_missing_away_statistics_keeps_original_payload(self):
        self.save(10, 2, 1)
        payload = {"home": {"expected_goals": 2.0}, "away": {"expected_goals": 1.0}, "observations": []}
        result = TeamStatisticsExpectationService(self.db).apply(self.match, payload)
        self.assertNotIn("team_statistics_adjustment", result)
        self.assertEqual(result["home"]["expected_goals"], 2.0)

    def test_future_observation_is_not_used(self):
        self.save(10, 2, 1)
        self.save(20, 3, 4)
        # Replace the away row with an observation after kickoff.
        self.db.save_team_stat_observation({"sport":"football", "team_id":"20", "team_name":"20",
            "league_id":"39", "competition":"Premier League", "season":"2026",
            "valid_before":"2026-11-22", "observed_at":"2026-11-24T12:00:00+00:00",
            "source":"test", "statistics":{"fixtures":{"played":{"home":2,"away":2}},
            "goals":{"for":{"total":{"home":3,"away":3}},"against":{"total":{"home":4,"away":4}}}}})
        payload = {"home":{"expected_goals":2.0},"away":{"expected_goals":1.0},"observations":[]}
        result = TeamStatisticsExpectationService(self.db).apply(self.match, payload)
        self.assertNotIn("team_statistics_adjustment", result)


if __name__ == "__main__": unittest.main()
