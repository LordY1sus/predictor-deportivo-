import os
import tempfile
import unittest
from app.storage.database import Database
from app.services.historical_import import HistoricalImportService, HistoricalImportError, parse_historical_csv

HEADER = "id,sport,home_name,away_name,kickoff_utc,home_score,away_score,source,captured_at\n"
ROW = "g1,football,Alpha,Beta,2026-11-01T18:00:00Z,2,1,league_official,2026-11-01T20:00:00Z\n"


class HistoricalImportTests(unittest.TestCase):
    def setUp(self):
        self.path = tempfile.mktemp(suffix=".db")
        self.db = Database(self.path)
        self.service = HistoricalImportService(self.db)

    def tearDown(self):
        self.db.close()
        if os.path.exists(self.path): os.remove(self.path)

    def test_imports_and_reports_duplicates_without_overwriting(self):
        first = self.service.import_csv(HEADER + ROW)
        second = self.service.import_csv(HEADER + ROW.replace(",2,1,", ",9,0,"))
        self.assertEqual(first, {"read": 1, "inserted": 1, "duplicates": 0})
        self.assertEqual(second, {"read": 1, "inserted": 0, "duplicates": 1})
        rows = self.db.historical_results_before("football", "Alpha", "2026-11-03T00:00:00+00:00")
        self.assertEqual(rows[0]["home_score"], 2)

    def test_imports_optional_competition_column(self):
        header = HEADER.rstrip("\n") + ",competition\n"
        row = ROW.rstrip("\n") + ",Premier League\n"
        self.service.import_csv(header + row)
        rows = self.db.historical_results_before("football", "Alpha", "2026-11-03T00:00:00+00:00",
                                                competition="Premier League")
        self.assertEqual(rows[0]["competition"], "Premier League")

    def test_rejects_timezone_missing(self):
        with self.assertRaises(HistoricalImportError):
            parse_historical_csv(HEADER + ROW.replace("2026-11-01T18:00:00Z", "2026-11-01T18:00:00"))

    def test_rejects_invalid_score(self):
        with self.assertRaises(HistoricalImportError):
            parse_historical_csv(HEADER + ROW.replace(",2,1,", ",-2,1,"))

    def test_validation_is_atomic(self):
        bad = ROW.replace("g1,", "g2,").replace(",2,1,", ",x,1,")
        with self.assertRaises(HistoricalImportError):
            self.service.import_csv(HEADER + ROW + bad)
        rows = self.db.historical_results_before("football", "Alpha", "2026-11-03T00:00:00+00:00")
        self.assertEqual(rows, [])

    def test_rejects_historical_match_in_future(self):
        future = ROW.replace("2026-11-01T18:00:00Z", "2099-11-01T18:00:00Z").replace("2026-11-01T20:00:00Z", "2099-11-01T20:00:00Z")
        with self.assertRaises(HistoricalImportError):
            parse_historical_csv(HEADER + future)

    def test_rejects_capture_before_kickoff(self):
        invalid = ROW.replace("2026-11-01T20:00:00Z", "2026-11-01T17:00:00Z")
        with self.assertRaises(HistoricalImportError):
            parse_historical_csv(HEADER + invalid)

    def test_rejects_duplicate_ids_inside_file(self):
        with self.assertRaises(HistoricalImportError):
            parse_historical_csv(HEADER + ROW + ROW)


    def test_imports_from_csv_file(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", encoding="utf-8", delete=False) as handle:
            handle.write(HEADER + ROW)
            path = handle.name
        try:
            result = self.service.import_file(path)
            self.assertEqual(result, {"read": 1, "inserted": 1, "duplicates": 0})
        finally:
            os.remove(path)

    def test_file_import_rejects_non_csv(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as handle:
            handle.write(HEADER + ROW)
            path = handle.name
        try:
            with self.assertRaises(HistoricalImportError):
                self.service.import_file(path)
        finally:
            os.remove(path)

    def test_file_import_enforces_size_limit(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False) as handle:
            handle.write(HEADER + ROW)
            path = handle.name
        try:
            with self.assertRaises(HistoricalImportError):
                self.service.import_file(path, max_bytes=5)
        finally:
            os.remove(path)


if __name__ == "__main__": unittest.main()
