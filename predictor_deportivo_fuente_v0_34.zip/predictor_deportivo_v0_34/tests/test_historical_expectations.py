import os
import tempfile
import unittest
from datetime import datetime, timezone, timedelta
from app.storage.database import Database
from app.services.historical_expectations import HistoricalExpectationService, InsufficientHistoryError


class HistoricalExpectationTests(unittest.TestCase):
    def setUp(self):
        self.path = tempfile.mktemp(suffix='.db')
        self.db = Database(self.path)
        self.now = datetime.now(timezone.utc)
        self.match = {
            'id': 'upcoming', 'sport': 'football', 'home_name': 'Alpha', 'away_name': 'Beta',
            'kickoff_utc': (self.now + timedelta(days=1)).isoformat(),
            'kickoff_local': (self.now + timedelta(days=1)).astimezone().isoformat(),
            'status': 'SCHEDULED', 'payload': {}
        }
        self.db.upsert_match(self.match)

    def tearDown(self):
        self.db.close()
        if os.path.exists(self.path): os.remove(self.path)

    def add_result(self, idx, home, away, hs, a_s, days_ago, competition=''):
        played = self.now - timedelta(days=days_ago)
        self.db.save_historical_result({
            'id': f'h{idx}', 'sport': 'football', 'home_name': home, 'away_name': away,
            'kickoff_utc': played.isoformat(), 'home_score': hs, 'away_score': a_s,
            'source': 'test_fixture', 'captured_at': (played + timedelta(hours=2)).isoformat(),
            'competition': competition
        })

    def seed(self):
        for i in range(6):
            self.add_result(i, 'Alpha', f'OpponentA{i}', 2, 1, 10+i)
            self.add_result(i+10, f'OpponentB{i}', 'Beta', 1, 2, 20+i)

    def test_builds_proxy_from_only_past_results(self):
        self.seed()
        payload = HistoricalExpectationService(self.db).build_payload(self.match)
        self.assertAlmostEqual(payload['home']['expected_goals'], 1.5)
        self.assertAlmostEqual(payload['away']['expected_goals'], 1.5)
        self.assertEqual(payload['sample']['home_games'], 6)
        self.assertEqual(payload['baseline_method'], 'historical_score_average_proxy')
        self.assertTrue(all(datetime.fromisoformat(x['observed_at']) < self.now + timedelta(days=1)
                            for x in payload['observations']))

    def test_scopes_history_to_the_target_competition(self):
        self.match["payload"] = {"league": "Premier League"}
        self.db.upsert_match(self.match)
        for i in range(5):
            self.add_result(i, "Alpha", f"PL Opponent {i}", 2, 1, 10+i, "Premier League")
            self.add_result(i+10, f"Cup Opponent {i}", "Beta", 1, 2, 20+i, "Premier League")
            self.add_result(i+20, "Alpha", f"Other Opponent {i}", 8, 0, 30+i, "Friendly Cup")
            self.add_result(i+30, f"Other Opponent B {i}", "Beta", 0, 8, 40+i, "Friendly Cup")
        payload = HistoricalExpectationService(self.db).build_payload(self.match)
        self.assertAlmostEqual(payload["home"]["expected_goals"], 1.5)
        self.assertAlmostEqual(payload["away"]["expected_goals"], 1.5)
        self.assertEqual(payload["sample"]["competition"], "Premier League")

    def test_insufficient_history_blocks_projection_payload(self):
        for i in range(4):
            self.add_result(i, 'Alpha', f'Opponent{i}', 1, 0, 10+i)
            self.add_result(i+10, f'Other{i}', 'Beta', 0, 1, 20+i)
        with self.assertRaises(InsufficientHistoryError):
            HistoricalExpectationService(self.db).build_payload(self.match)

    def test_future_history_is_excluded(self):
        self.seed()
        future = self.now + timedelta(hours=3)
        self.db.save_historical_result({
            'id':'future','sport':'football','home_name':'Alpha','away_name':'Beta',
            'kickoff_utc':future.isoformat(),'home_score':9,'away_score':0,
            'source':'future_test','captured_at':self.now.isoformat()
        })
        payload = HistoricalExpectationService(self.db).build_payload(self.match)
        self.assertEqual(payload['sample']['home_games'], 6)

if __name__ == '__main__': unittest.main()
