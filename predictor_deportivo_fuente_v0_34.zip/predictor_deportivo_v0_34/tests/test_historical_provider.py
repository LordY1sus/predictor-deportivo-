import unittest
from datetime import date, datetime, timezone
from unittest.mock import patch

from app.providers import espn_scoreboard
from app.services.sync_service import SyncService
from app.storage.database import Database
import tempfile, os


class ESPNHistoricalProviderTests(unittest.TestCase):
    def payload(self):
        return {"events": [
            {"id": "done", "date": "2026-11-20T18:00:00Z",
             "status": {"type": {"state": "post", "completed": True}},
             "competitions": [{"competitors": [
                 {"homeAway": "home", "score": "3", "team": {"displayName": "Home"}},
                 {"homeAway": "away", "score": "1", "team": {"displayName": "Away"}}]}]},
            {"id": "live", "date": "2026-11-20T20:00:00Z",
             "status": {"type": {"state": "in", "completed": False}},
             "competitions": [{"competitors": [
                 {"homeAway": "home", "score": "1", "team": {"displayName": "A"}},
                 {"homeAway": "away", "score": "0", "team": {"displayName": "B"}}]}]},
            {"id": "no-score", "date": "2026-11-20T21:00:00Z",
             "status": {"type": {"state": "post", "completed": True}},
             "competitions": [{"competitors": [
                 {"homeAway": "home", "team": {"displayName": "C"}},
                 {"homeAway": "away", "team": {"displayName": "D"}}]}]}
        ]}

    @patch("app.providers.espn_scoreboard._fetch_json")
    def test_only_finished_scored_events_are_returned(self, fetch):
        fetch.return_value = self.payload()
        captured = "2026-11-22T12:00:00+00:00"
        rows = espn_scoreboard.fetch_historical_day("football", date(2026, 11, 20), captured)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["id"], "espn:football:done")
        self.assertEqual((rows[0]["home_score"], rows[0]["away_score"]), (3, 1))
        self.assertEqual(rows[0]["source"], "espn_scoreboard")
        self.assertIn("dates=20261120", fetch.call_args.args[0])

    def test_rejects_unknown_sport(self):
        with self.assertRaises(espn_scoreboard.ProviderError):
            espn_scoreboard.fetch_historical_day("hockey", date(2026, 11, 20))


class HistoricalSyncTests(unittest.TestCase):
    def setUp(self):
        self.path = tempfile.mktemp()
        self.db = Database(self.path)
        self.service = SyncService(self.db)

    def tearDown(self):
        self.db.close()
        if os.path.exists(self.path): os.remove(self.path)

    @patch("app.services.sync_service.fetch_historical_day")
    def test_range_imports_and_does_not_overwrite(self, fetch):
        row = {"id": "espn:football:1", "sport": "football", "home_name": "A",
               "away_name": "B", "kickoff_utc": "2026-11-20T18:00:00+00:00",
               "home_score": 2, "away_score": 0, "source": "espn_scoreboard",
               "captured_at": "2026-11-22T12:00:00+00:00"}
        fetch.return_value = [row]
        first = self.service.sync_historical_range("football", "2026-11-20", "2026-11-20")
        second = self.service.sync_historical_range("football", "2026-11-20", "2026-11-20")
        self.assertEqual(first["inserted"], 1)
        self.assertEqual(second["inserted"], 0)
        self.assertEqual(second["duplicates"], 1)

    def test_rejects_too_wide_range(self):
        with self.assertRaises(ValueError):
            self.service.sync_historical_range("football", "2026-01-01", "2026-02-15")

    def test_rejects_future_range(self):
        future = (datetime.now(timezone.utc).date().replace(day=28)).isoformat()
        with self.assertRaises(ValueError):
            self.service.sync_historical_range("football", future, future)

    def test_rejects_reversed_range_and_invalid_sport(self):
        with self.assertRaises(ValueError):
            self.service.sync_historical_range("football", "2026-11-21", "2026-11-20")
        with self.assertRaises(ValueError):
            self.service.sync_historical_range("hockey", "2026-11-20", "2026-11-20")


if __name__ == "__main__": unittest.main()
