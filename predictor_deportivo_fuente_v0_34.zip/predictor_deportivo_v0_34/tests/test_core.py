import unittest, tempfile, os
from app.analytics.ev import evaluate
from app.engines.simple_models import project_match
from app.services.lineup_validator import validate_lineup
from app.storage.database import Database

class CoreTests(unittest.TestCase):
    def test_ev_positive(self):
        self.assertTrue(evaluate(.60,2.0)["eligible"])
    def test_simulation_bounds(self):
        with self.assertRaises(ValueError):
            project_match("football",{},999)
    def test_lineup_requires_official(self):
        with self.assertRaises(ValueError):
            validate_lineup("football",{}, "2026-11-23T20:00:00+00:00")
    def test_finished_hidden_but_preserved(self):
        path=tempfile.mktemp()
        db=Database(path)
        db.upsert_match({"id":"x","sport":"football","home_name":"A","away_name":"B",
          "kickoff_utc":"2026-11-22T19:00:00+00:00","kickoff_local":"2026-11-22T11:00:00-08:00",
          "status":"FINISHED"})
        self.assertEqual(db.get_today_matches(local_date="2026-11-22"),[])
        self.assertIsNotNone(db.get_match("x"))
        db.close(); os.remove(path)

if __name__ == "__main__": unittest.main()
