import unittest
from datetime import datetime, timezone, timedelta
from app.services.pre_match_validator import validate_pre_match_payload
from app.analytics.opportunity_builder import build_opportunities

class PreMatchAndMarketTests(unittest.TestCase):
    def setUp(self):
        self.kickoff=(datetime.now(timezone.utc)+timedelta(hours=3)).isoformat()
        self.match={"id":"m","sport":"football","home_name":"Home","away_name":"Away","kickoff_utc":self.kickoff}
        self.lineup={"status":"official"}
        self.payload={"home":{"expected_goals":1.4},"away":{"expected_goals":1.1},
                      "observations":[{"observed_at":datetime.now(timezone.utc).isoformat()}]}

    def test_valid_pre_match_data(self):
        self.assertTrue(validate_pre_match_payload(self.match,self.payload,self.lineup))

    def test_reject_future_observation(self):
        payload=dict(self.payload)
        payload["observations"]=[{"observed_at":(datetime.now(timezone.utc)+timedelta(hours=4)).isoformat()}]
        with self.assertRaises(ValueError):
            validate_pre_match_payload(self.match,payload,self.lineup)

    def test_exact_market_mapping_and_positive_ev_only(self):
        projection={"home_win":.65,"draw":.2,"away_win":.15}
        captured=datetime.now(timezone.utc).isoformat()
        odds=[{"market":"h2h","selection":"Home","line":None,"decimal_odds":2.0,"captured_at":captured},
              {"market":"totals","selection":"Over","line":2.5,"decimal_odds":3.0,"captured_at":captured}]
        opportunities=build_opportunities(self.match,projection,odds)
        self.assertEqual(len(opportunities),1)
        self.assertEqual(opportunities[0]["selection"],"Home")

    def test_stale_quote_is_excluded(self):
        old=(datetime.now(timezone.utc)-timedelta(hours=8)).isoformat()
        odds=[{"market":"h2h","selection":"Home","line":None,"decimal_odds":2.0,"captured_at":old}]
        self.assertEqual(build_opportunities(self.match,{"home_win":.7},odds),[])

    def test_rank_keeps_bookmakers_and_orders_by_ev(self):
        captured=datetime.now(timezone.utc).isoformat()
        odds=[
            {"market":"h2h","selection":"Home","line":None,"decimal_odds":2.0,"captured_at":captured,"bookmaker":"A"},
            {"market":"h2h","selection":"Home","line":None,"decimal_odds":2.4,"captured_at":captured,"bookmaker":"B"},
        ]
        result=build_opportunities(self.match,{"home_win":.7},odds)
        self.assertEqual([x["bookmaker"] for x in result],["B","A"])
        self.assertGreater(result[0]["expected_value"],result[1]["expected_value"])

    def test_quote_captured_after_kickoff_is_excluded(self):
        kickoff = datetime.now(timezone.utc) - timedelta(minutes=2)
        match = dict(self.match, kickoff_utc=kickoff.isoformat())
        quote_time = (kickoff + timedelta(seconds=30)).isoformat()
        odds = [{"market":"h2h", "selection":"Home", "line":None,
                 "decimal_odds":2.0, "captured_at":quote_time}]
        self.assertEqual(build_opportunities(match, {"home_win":.8}, odds,
                         now_utc=kickoff-timedelta(seconds=30)), [])

    def test_no_prematch_opportunities_after_kickoff(self):
        kickoff = datetime.now(timezone.utc) - timedelta(seconds=1)
        match = dict(self.match, kickoff_utc=kickoff.isoformat())
        quote_time = (kickoff - timedelta(minutes=2)).isoformat()
        odds = [{"market":"h2h", "selection":"Home", "line":None,
                 "decimal_odds":2.0, "captured_at":quote_time}]
        self.assertEqual(build_opportunities(match, {"home_win":.8}, odds,
                         now_utc=datetime.now(timezone.utc)), [])

    def test_reject_timezone_naive_kickoff(self):
        match = dict(self.match, kickoff_utc="2030-01-01T20:00:00")
        with self.assertRaises(ValueError):
            build_opportunities(match, {"home_win":.7}, [])

if __name__ == "__main__": unittest.main()
