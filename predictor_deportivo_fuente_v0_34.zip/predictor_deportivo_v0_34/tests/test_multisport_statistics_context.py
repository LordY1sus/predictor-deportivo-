import unittest
from app.storage.database import Database
from app.services.multisport_statistics_context import MultiSportStatisticsContextService


class MultiSportStatisticsContextTests(unittest.TestCase):
    def setUp(self):
        self.db = Database(":memory:")
        self.match = {"sport": "basketball", "kickoff_utc": "2026-11-23T20:00:00+00:00",
            "payload_json": '{"home_team_id": "10", "away_team_id": "20", "league_id": "12", "season": "2026"}'}

    def tearDown(self):
        self.db.close()

    def save(self, team, observed="2026-11-23T18:00:00+00:00", valid="2026-11-22"):
        self.db.save_team_stat_observation({"sport":"basketball", "team_id":str(team),
            "team_name":str(team), "league_id":"12", "competition":"League", "season":"2026",
            "valid_before":valid, "observed_at":observed, "source":"test",
            "statistics":{"points":110, "team":{"id":team}}})

    def test_requires_both_teams_and_returns_auditable_pre_match_context(self):
        self.save(10); self.save(20)
        result = MultiSportStatisticsContextService(self.db).snapshot_for_match(self.match)
        self.assertEqual(result["method"], "pre_match_team_snapshot_audit_only")
        self.assertEqual(result["teams"]["home"]["statistics"]["points"], 110)

    def test_missing_opponent_snapshot_disables_context(self):
        self.save(10)
        self.assertEqual(MultiSportStatisticsContextService(self.db).snapshot_for_match(self.match), {})

    def test_rejects_same_day_validity_even_if_capture_precedes_kickoff(self):
        self.save(10, valid="2026-11-23"); self.save(20)
        self.assertEqual(MultiSportStatisticsContextService(self.db).snapshot_for_match(self.match), {})

    def test_rejects_observation_after_kickoff(self):
        self.save(10, observed="2026-11-23T21:00:00+00:00"); self.save(20)
        self.assertEqual(MultiSportStatisticsContextService(self.db).snapshot_for_match(self.match), {})

    def test_ignores_other_sports(self):
        self.match["sport"] = "football"
        self.assertEqual(MultiSportStatisticsContextService(self.db).snapshot_for_match(self.match), {})


if __name__ == "__main__":
    unittest.main()
