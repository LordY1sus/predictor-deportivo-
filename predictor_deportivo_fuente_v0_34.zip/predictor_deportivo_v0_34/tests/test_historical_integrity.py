import os
import tempfile
import unittest
from datetime import datetime, timezone, timedelta
from app.storage.database import Database
from app.services.historical_integrity import HistoricalIntegrityService


class HistoricalIntegrityTests(unittest.TestCase):
    def setUp(self):
        self.path = tempfile.mktemp(suffix='.db')
        self.db = Database(self.path)
        self.service = HistoricalIntegrityService(self.db, duplicate_window_minutes=180)
        self.now = datetime(2026, 11, 22, 12, tzinfo=timezone.utc)

    def tearDown(self):
        self.db.close()
        if os.path.exists(self.path):
            os.remove(self.path)

    def add(self, ident, source, kickoff, captured=None, home='Alpha', away='Beta', competition=''):
        kickoff_dt = datetime.fromisoformat(kickoff.replace('Z', '+00:00'))
        captured = captured or (kickoff_dt + timedelta(hours=3)).isoformat()
        self.db.save_historical_result({
            'id': ident, 'sport': 'football', 'home_name': home, 'away_name': away,
            'kickoff_utc': kickoff, 'home_score': 2, 'away_score': 1,
            'source': source, 'captured_at': captured, 'competition': competition,
        })

    def test_flags_possible_duplicates_without_deleting_records(self):
        self.add('a', 'provider_a', '2026-11-01T18:00:00Z')
        self.add('b', 'provider_b', '2026-11-01T18:30:00Z')
        report = self.service.audit('football', now=self.now)
        self.assertEqual(len(report['possible_duplicate_groups']), 1)
        self.assertEqual(report['possible_duplicate_records'], 2)
        self.assertEqual(report['automatic_changes'], 0)
        self.assertEqual(report['total_records'], 2)

    def test_does_not_flag_same_teams_far_apart(self):
        self.add('a', 'provider_a', '2026-11-01T18:00:00Z')
        self.add('b', 'provider_b', '2026-11-03T18:00:00Z')
        report = self.service.audit('football', now=self.now)
        self.assertEqual(report['possible_duplicate_groups'], [])

    def test_does_not_group_identical_teams_across_competitions(self):
        self.add('league', 'provider_a', '2026-11-01T18:00:00Z', competition='League A')
        self.add('cup', 'provider_b', '2026-11-01T18:30:00Z', competition='Cup B')
        report = self.service.audit('football', now=self.now)
        self.assertEqual(report['possible_duplicate_groups'], [])

    def test_reports_temporal_inconsistencies_and_sources(self):
        self.add('a', 'provider_a', '2026-11-01T18:00:00Z', '2026-11-01T17:00:00Z')
        self.add('b', '', '2026-11-23T18:00:00Z', '2026-11-24T18:00:00Z')
        report = self.service.audit('football', now=self.now)
        self.assertEqual(report['temporal_issue_count'], 3)
        self.assertEqual(report['missing_source_records'], 1)
        self.assertEqual(report['sources']['provider_a'], 1)


if __name__ == '__main__':
    unittest.main()
