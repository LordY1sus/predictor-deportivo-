import unittest
from unittest.mock import patch
from app.providers.api_sports import parse_games, fetch_day, fetch_status, fetch_football_team_statistics, APISportsError


class APISportsProviderTests(unittest.TestCase):
    def test_parse_football_finished_fixture(self):
        payload = {"errors": [], "response": [{
            "fixture": {"id": 77, "date": "2026-11-20T18:00:00+00:00", "status": {"short": "FT"}},
            "teams": {"home": {"id": 10, "name": "Home FC"}, "away": {"id": 20, "name": "Away FC"}},
            "goals": {"home": 2, "away": 1}, "league": {"id": 39, "season": 2026, "name": "Premier League"}
        }]}
        rows = parse_games(payload, "football", "2026-11-21T00:00:00+00:00")
        self.assertEqual(rows[0]["match"]["status"], "FINISHED")
        self.assertEqual(rows[0]["result"]["home_score"], 2)
        self.assertEqual(rows[0]["result"]["source"], "api_sports")
        self.assertEqual(rows[0]["match"]["payload"]["home_team_id"], 10)
        self.assertEqual(rows[0]["match"]["payload"]["league_id"], 39)

    def test_parse_basketball_live_game_does_not_make_history(self):
        payload = {"errors": [], "response": [{
            "id": 88, "date": "2026-11-20T18:00:00+00:00", "status": {"short": "Q2"},
            "teams": {"home": {"name": "Lakers"}, "away": {"name": "Celtics"}},
            "scores": {"home": {"total": 55}, "away": {"total": 50}},
            "league": {"name": "NBA"}
        }]}
        rows = parse_games(payload, "basketball", "2026-11-21T00:00:00+00:00")
        self.assertEqual(rows[0]["match"]["status"], "LIVE")
        self.assertIsNone(rows[0]["result"])

    def test_parse_baseball_finished_game(self):
        payload = {"errors": [], "response": [{
            "id": 99, "date": "2026-11-20T18:00:00+00:00", "status": {"short": "FT"},
            "teams": {"home": {"name": "Dodgers"}, "away": {"name": "Mets"}},
            "scores": {"home": {"total": 4}, "away": {"total": 3}},
            "league": {"name": "MLB"}
        }]}
        rows = parse_games(payload, "baseball", "2026-11-21T00:00:00+00:00")
        self.assertEqual(rows[0]["result"]["away_score"], 3)

    def test_provider_errors_and_missing_key(self):
        with self.assertRaises(APISportsError):
            parse_games({"errors": {"token": "invalid"}, "response": []}, "football")
        with self.assertRaises(APISportsError):
            fetch_day("football", "2026-11-20", "")

    @patch("app.providers.api_sports._request_json")
    def test_status_reports_plan_and_remaining_quota(self, request):
        request.return_value = ({"errors": [], "response": {
            "subscription": {"plan": "Free", "active": True, "end": "2026-12-01T00:00:00+00:00"},
            "requests": {"current": 12, "limit_day": 100}}}, {})
        status = fetch_status("basketball", "key")
        self.assertEqual(status["plan"], "Free")
        self.assertTrue(status["active"])
        self.assertEqual(status["daily_remaining"], 88)
        self.assertTrue(request.call_args.args[0].endswith("/status"))

    @patch("app.providers.api_sports._request_json")
    def test_fetch_day_sends_key_in_header_request_and_date_query(self, request):
        request.return_value = ({"errors": [], "response": []},
                                {"x-ratelimit-requests-remaining": "98"})
        response = fetch_day("football", "2026-11-20", "secret-key")
        self.assertEqual(response["quota"]["daily_remaining"], "98")
        self.assertIn("date=2026-11-20", request.call_args.args[0])
        self.assertNotIn("secret-key", request.call_args.args[0])

    @patch("app.providers.api_sports._request_json")
    def test_fetch_team_statistics_uses_previous_date_and_checks_identity(self, request):
        request.return_value = ({"errors": [], "response": {
            "team": {"id": 10, "name": "Home FC"}, "league": {"id": 39, "name": "Premier League"},
            "fixtures": {"played": {"total": 10}}, "goals": {"for": {"total": {"total": 20}}}}},
            {"x-ratelimit-requests-remaining": "90"})
        record = fetch_football_team_statistics(10, 39, 2026, "2026-11-21", "secret")
        self.assertEqual(record["valid_before"], "2026-11-21")
        self.assertIn("date=2026-11-21", request.call_args.args[0])
        self.assertEqual(record["statistics"]["fixtures"]["played"]["total"], 10)

    @patch("app.providers.api_sports._request_json")
    def test_fetch_team_statistics_rejects_wrong_team(self, request):
        request.return_value = ({"errors": [], "response": {"team": {"id": 99}, "league": {"id": 39}}}, {})
        with self.assertRaises(APISportsError):
            fetch_football_team_statistics(10, 39, 2026, "2026-11-21", "secret")


if __name__ == "__main__": unittest.main()
