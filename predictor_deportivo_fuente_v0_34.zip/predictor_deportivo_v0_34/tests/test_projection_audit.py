import json, os, sqlite3, tempfile, unittest
from app.storage.database import Database


class ProjectionAuditTests(unittest.TestCase):
    def test_migrates_legacy_projection_table(self):
        path = tempfile.mktemp()
        raw = sqlite3.connect(path)
        raw.execute("CREATE TABLE projections(id INTEGER PRIMARY KEY AUTOINCREMENT, match_id TEXT NOT NULL, created_at TEXT NOT NULL, simulations INTEGER NOT NULL, result_json TEXT NOT NULL)")
        raw.commit(); raw.close()
        db = Database(path)
        try:
            columns = {row["name"] for row in db.conn.execute("PRAGMA table_info(projections)")}
            self.assertTrue({"input_snapshot_json", "model_version", "seed"}.issubset(columns))
        finally:
            db.close()
            os.remove(path)

    def test_migrates_legacy_historical_table_with_competition(self):
        path = tempfile.mktemp()
        raw = sqlite3.connect(path)
        raw.execute("""CREATE TABLE historical_results(
            id TEXT PRIMARY KEY,sport TEXT NOT NULL,home_name TEXT NOT NULL,away_name TEXT NOT NULL,
            kickoff_utc TEXT NOT NULL,home_score REAL NOT NULL,away_score REAL NOT NULL,
            source TEXT NOT NULL,captured_at TEXT NOT NULL)""")
        raw.commit(); raw.close()
        db = Database(path)
        try:
            columns = {row["name"] for row in db.conn.execute("PRAGMA table_info(historical_results)")}
            self.assertIn("competition", columns)
        finally:
            db.close(); os.remove(path)

    def test_projection_persists_reproducibility_snapshot(self):
        path = tempfile.mktemp(); db = Database(path)
        try:
            db.upsert_match({"id": "m", "sport": "football", "home_name": "A", "away_name": "B",
                "kickoff_utc": "2026-12-01T20:00:00+00:00", "kickoff_local": "2026-12-01T20:00:00+00:00",
                "status": "SCHEDULED"})
            snapshot = {"generated_input_at": "2026-11-22T12:00:00+00:00",
                        "payload": {"observations": [{"observed_at": "2026-11-22T11:00:00+00:00"}]},
                        "lineup": {"status": "official", "source": "https://example.org/lineup",
                                   "confirmed_at": "2026-11-22T11:30:00+00:00"}}
            projection_id = db.save_projection("m", 10000,
                {"home_win": .5, "draw": .25, "away_win": .25}, snapshot,
                model_version="advanced_models_v1", seed=12345)
            record = db.get_projection_record(projection_id)
            self.assertEqual(record["seed"], 12345)
            self.assertEqual(record["model_version"], "advanced_models_v1")
            self.assertEqual(record["input_snapshot"]["lineup"]["status"], "official")
            self.assertEqual(record["result"]["home_win"], .5)
        finally:
            db.close()
            if os.path.exists(path): os.remove(path)


if __name__ == "__main__": unittest.main()
