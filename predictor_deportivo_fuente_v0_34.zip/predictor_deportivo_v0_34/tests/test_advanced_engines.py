import unittest
from app.engines.advanced_models import project_match

class AdvancedEngineTests(unittest.TestCase):
    def test_football_probabilities_sum_to_one(self):
        data={"home":{"expected_goals":1.6},"away":{"expected_goals":1.0}}
        r=project_match("football",data,5000,seed=7)
        self.assertAlmostEqual(r["home_win"]+r["draw"]+r["away_win"],1.0,places=8)
        self.assertEqual(r["model"],"dixon_coles_monte_carlo")

    def test_basketball_outputs_winner_probabilities(self):
        data={"home":{"expected_points":112},"away":{"expected_points":106},"pace":98}
        r=project_match("basketball",data,3000,seed=9)
        self.assertAlmostEqual(r["home_win"]+r["away_win"],1.0,places=8)

    def test_baseball_state_simulation(self):
        data={"home":{"expected_runs":4.6},"away":{"expected_runs":4.1}}
        r=project_match("baseball",data,1000,seed=11)
        self.assertAlmostEqual(r["home_win"]+r["away_win"],1.0,places=8)
        self.assertGreaterEqual(r["expected_home_runs"],0)

    def test_reject_invalid_pace(self):
        data={"home":{"expected_points":110},"away":{"expected_points":105},"pace":130}
        with self.assertRaises(ValueError): project_match("basketball",data,1000)

if __name__=="__main__": unittest.main()
