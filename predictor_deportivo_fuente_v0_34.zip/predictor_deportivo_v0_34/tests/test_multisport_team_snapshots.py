import unittest
from unittest.mock import patch
from app.storage.database import Database
from app.providers.api_sports import APISportsError, fetch_team_statistics_snapshot
from app.services.multisport_team_snapshots import MultiSportTeamSnapshotService


class MultiSportTeamSnapshotTests(unittest.TestCase):
    def setUp(self):
        self.db = Database(":memory:")
        self.kickoff = "2026-11-23T20:00:00+00:00"

    def tearDown(self):
        self.db.close()

    def payload(self):
        return {"errors": [], "response": {"team": {"id": 10, "name": "Home"},
            "league": {"id": 12, "name": "League"}, "statistics": {"points": 110}}}

    @patch("app.providers.api_sports._request_json")
    def test_basketball_uses_date_limited_team_statistics_endpoint(self, request):
        request.return_value = (self.payload(), {"x-ratelimit-requests-remaining": "98"})
        row = fetch_team_statistics_snapshot("basketball", 10, 12, 2026,
            "2026-11-22", "secret", captured_at="2026-11-23T18:00:00+00:00")
        self.assertEqual(row["sport"], "basketball")
        self.assertIn("/statistics?", request.call_args.args[0])
        self.assertIn("date=2026-11-22", request.call_args.args[0])

    @patch("app.providers.api_sports._request_json")
    def test_baseball_uses_date_limited_team_statistics_endpoint(self, request):
        request.return_value = (self.payload(), {})
        row = fetch_team_statistics_snapshot("baseball", 10, 12, 2026,
            "2026-11-22", "secret")
        self.assertEqual(row["sport"], "baseball")
        self.assertIn("/teams/statistics?", request.call_args.args[0])

    @patch("app.services.multisport_team_snapshots.fetch_team_statistics_snapshot")
    def test_service_uses_day_before_kickoff_and_persists(self, fetch):
        fetch.return_value = {"sport":"basketball", "team_id":"10", "team_name":"Home",
            "league_id":"12", "competition":"League", "season":"2026",
            "valid_before":"2026-11-22", "observed_at":"2026-11-23T18:00:00+00:00",
            "source":"test", "statistics":{"points":110}}
        service = MultiSportTeamSnapshotService(self.db)
        service.capture("basketball", 10, 12, 2026, self.kickoff, "secret",
            captured_at="2026-11-23T18:00:00+00:00")
        fetch.assert_called_once()
        self.assertEqual(fetch.call_args.args[4], "2026-11-22")
        stored = service.get_before_match("basketball", 10, 12, 2026, self.kickoff)
        self.assertEqual(stored["statistics"]["points"], 110)

    def test_rejects_capture_at_or_after_kickoff(self):
        service = MultiSportTeamSnapshotService(self.db)
        with self.assertRaises(ValueError):
            service.capture("baseball", 10, 12, 2026, self.kickoff, "secret",
                captured_at="2026-11-23T20:00:00+00:00")

    def test_rejects_unsupported_sport(self):
        with self.assertRaises(APISportsError):
            fetch_team_statistics_snapshot("football", 10, 12, 2026,
                "2026-11-22", "secret")


if __name__ == "__main__":
    unittest.main()
