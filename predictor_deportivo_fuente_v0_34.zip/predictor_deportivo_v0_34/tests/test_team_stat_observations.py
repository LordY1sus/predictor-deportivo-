import unittest
from app.storage.database import Database


class TeamStatObservationTests(unittest.TestCase):
    def setUp(self):
        self.db = Database(":memory:")

    def tearDown(self):
        self.db.close()

    def record(self, valid_before="2026-11-21", observed_at="2026-11-22T10:00:00+00:00"):
        return {"sport": "football", "team_id": "10", "team_name": "Home FC",
                "league_id": "39", "competition": "Premier League", "season": "2026",
                "valid_before": valid_before, "observed_at": observed_at,
                "source": "api_football_teams_statistics", "statistics": {"fixtures": {"played": {"total": 9}}}}

    def test_save_and_get_only_before_match_cutoff(self):
        self.db.save_team_stat_observation(self.record())
        found = self.db.get_team_stat_observation("football", 10, 39, 2026, "2026-11-23T20:00:00+00:00")
        self.assertEqual(found["statistics"]["fixtures"]["played"]["total"], 9)

    def test_excludes_same_day_or_future_valid_date(self):
        self.db.save_team_stat_observation(self.record(valid_before="2026-11-23"))
        self.assertIsNone(self.db.get_team_stat_observation("football", 10, 39, 2026, "2026-11-23T20:00:00+00:00"))

    def test_excludes_observation_captured_after_kickoff(self):
        self.db.save_team_stat_observation(self.record(observed_at="2026-11-24T10:00:00+00:00"))
        self.assertIsNone(self.db.get_team_stat_observation("football", 10, 39, 2026, "2026-11-23T20:00:00+00:00"))


if __name__ == "__main__": unittest.main()
