import os
import tempfile
import unittest
from datetime import datetime, timezone, timedelta
from app.storage.database import Database
from app.services.historical_quality import HistoricalQualityService
from app.services.historical_expectations import HistoricalExpectationService


class HistoricalQualityTests(unittest.TestCase):
    def setUp(self):
        self.path = tempfile.mktemp(suffix='.db')
        self.db = Database(self.path)
        self.service = HistoricalQualityService(self.db, minimum_games=2)
        self.now = datetime.now(timezone.utc)

    def tearDown(self):
        self.db.close()
        if os.path.exists(self.path): os.remove(self.path)

    def add(self, ident, home, away, hs=2, a_s=1, days=10):
        played = self.now - timedelta(days=days)
        self.db.save_historical_result({
            'id': ident, 'sport': 'football', 'home_name': home, 'away_name': away,
            'kickoff_utc': played.isoformat(), 'home_score': hs, 'away_score': a_s,
            'source': 'test_source', 'captured_at': (played + timedelta(hours=1)).isoformat()
        })

    def test_alias_merges_team_history_without_rewriting_source_rows(self):
        self.add('a1', 'Man United', 'Opponent 1')
        self.add('a2', 'Manchester United', 'Opponent 2')
        self.service.add_alias('football', 'Man United', 'Manchester United')
        history = self.db.historical_results_before('football', 'Manchester United', (self.now + timedelta(days=1)).isoformat())
        self.assertEqual(len(history), 2)
        self.assertEqual(self.db.canonical_team_name('football', 'Man United'), 'Manchester United')
        coverage = self.service.report('football')
        manchester = [x for x in coverage['teams'] if x['team'] == 'Manchester United']
        self.assertEqual(len(manchester), 1)
        self.assertEqual(manchester[0]['matches'], 2)
        self.assertTrue(manchester[0]['ready'])

    def test_alias_collision_is_rejected(self):
        self.service.add_alias('football', 'Man Utd', 'Manchester United')
        with self.assertRaises(ValueError):
            self.service.add_alias('football', 'Man Utd', 'United FC')

    def test_expectations_resolve_alias_for_home_away_classification(self):
        self.service.add_alias('football', 'Man United', 'Manchester United')
        self.service.add_alias('football', 'Man U', 'Manchester United')
        for i in range(5):
            self.add(f'm{i}', 'Man United', f'Rival{i}', hs=3, a_s=0, days=20+i)
            self.add(f'r{i}', f'Other{i}', 'Man U', hs=0, a_s=2, days=30+i)
        cutoff = (self.now + timedelta(days=2)).isoformat()
        sample = HistoricalExpectationService(self.db)._team_sample('football', 'Manchester United',
                                                                      datetime.fromisoformat(cutoff))
        self.assertEqual(len(sample), 10)
        self.assertEqual(sum(1 for item in sample if item['scored'] == 3), 5)
        self.assertEqual(sum(1 for item in sample if item['scored'] == 2), 5)

    def test_coverage_empty_database(self):
        report = self.service.report()
        self.assertEqual(report['total_matches'], 0)
        self.assertEqual(report['teams_below_minimum'], 0)


if __name__ == '__main__':
    unittest.main()
