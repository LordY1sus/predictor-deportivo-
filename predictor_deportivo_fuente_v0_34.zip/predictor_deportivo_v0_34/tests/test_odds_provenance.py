import tempfile, unittest
from pathlib import Path
from datetime import datetime,timezone
from app.storage.database import Database

class OddsProvenanceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.db=Database(str(Path(self.tmp.name)/"test.db"))
        self.db.upsert_match({"id":"m1","sport":"football","home_name":"A","away_name":"B",
            "kickoff_utc":"2030-01-01T20:00:00+00:00","kickoff_local":"2030-01-01T12:00:00-08:00",
            "status":"SCHEDULED","payload":{}})
    def tearDown(self):
        self.db.close(); self.tmp.cleanup()

    def test_quotes_keep_each_bookmaker(self):
        self.db.add_odds("m1","h2h","A",2.1,bookmaker="book_a",provider="odds_api")
        self.db.add_odds("m1","h2h","A",2.2,bookmaker="book_b",provider="odds_api")
        rows=self.db.latest_odds("m1")
        self.assertEqual({r["bookmaker"] for r in rows},{"book_a","book_b"})
        self.assertEqual(len(rows),2)

    def test_latest_quote_per_bookmaker(self):
        self.db.add_odds("m1","h2h","A",2.0,bookmaker="book_a")
        self.db.add_odds("m1","h2h","A",2.3,bookmaker="book_a")
        rows=self.db.latest_odds("m1")
        self.assertEqual(len(rows),1)
        self.assertEqual(rows[0]["decimal_odds"],2.3)

    def test_reject_timezone_naive_capture(self):
        with self.assertRaises(ValueError):
            self.db.add_odds("m1","h2h","A",2.0,captured_at="2030-01-01T12:00:00")

if __name__=="__main__": unittest.main()
