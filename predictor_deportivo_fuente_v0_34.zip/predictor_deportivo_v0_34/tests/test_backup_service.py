import json
import tempfile
import unittest
from pathlib import Path

from app.storage.database import Database
from app.services.backup_service import BackupService


class BackupServiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(str(Path(self.tmp.name) / "source.db"))
        self.service = BackupService(self.db)

    def tearDown(self):
        self.db.close()
        self.tmp.cleanup()

    def _match(self, match_id="m1"):
        self.db.upsert_match({"id": match_id, "sport": "football", "home_name": "A",
            "away_name": "B", "kickoff_utc": "2026-12-01T18:00:00+00:00",
            "kickoff_local": "2026-12-01T13:00:00-05:00", "status": "SCHEDULED"})

    def test_round_trip_preserves_match_and_historical_data(self):
        self._match()
        self.db.save_historical_result({"id": "h1", "sport": "football", "home_name": "A",
            "away_name": "B", "kickoff_utc": "2026-11-01T18:00:00+00:00",
            "home_score": 2, "away_score": 1, "source": "official", "competition": "League"})
        backup = Path(self.tmp.name) / "backup.json"
        result = self.service.export_file(backup)
        self.assertEqual(result["records"], 2)
        target = Database(str(Path(self.tmp.name) / "target.db"))
        try:
            restored = BackupService(target).import_file(backup)
            self.assertEqual(restored["total_inserted"], 2)
            self.assertEqual(target.get_match("m1")["home_name"], "A")
            self.assertEqual(target.historical_coverage()["total_matches"], 1)
        finally:
            target.close()

    def test_import_is_idempotent_and_skips_existing_primary_keys(self):
        self._match()
        backup = Path(self.tmp.name) / "backup.json"
        self.service.export_file(backup)
        result = self.service.import_file(backup)
        self.assertEqual(result["total_inserted"], 0)
        self.assertGreaterEqual(result["total_skipped"], 1)

    def test_rejects_wrong_format_before_writing(self):
        bad = Path(self.tmp.name) / "bad.json"
        bad.write_text(json.dumps({"format": "other", "format_version": 1, "tables": {}}))
        with self.assertRaises(ValueError):
            self.service.import_file(bad)
        self.assertEqual(self.db.conn.execute("SELECT COUNT(*) FROM matches").fetchone()[0], 0)

    def test_invalid_row_rolls_back_whole_import(self):
        backup = Path(self.tmp.name) / "bad-row.json"
        backup.write_text(json.dumps({"format": self.service.FORMAT, "format_version": 1,
            "tables": {"matches": [{"id": "bad", "unexpected": True}]}}))
        with self.assertRaises(ValueError):
            self.service.import_file(backup)
        self.assertEqual(self.db.conn.execute("SELECT COUNT(*) FROM matches").fetchone()[0], 0)


if __name__ == "__main__":
    unittest.main()
