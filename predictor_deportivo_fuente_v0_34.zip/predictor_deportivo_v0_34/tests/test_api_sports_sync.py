import os, tempfile, unittest
from unittest.mock import patch
from app.storage.database import Database
from app.services.sync_service import SyncService


class APISportsSyncTests(unittest.TestCase):
    def setUp(self):
        self.path = tempfile.mktemp(); self.db = Database(self.path)
        self.service = SyncService(self.db)

    def tearDown(self):
        self.db.close()
        if os.path.exists(self.path): os.remove(self.path)

    @patch("app.services.sync_service.fetch_api_sports_day")
    def test_sync_saves_match_and_finished_result(self, fetch):
        match = {"id": "api_sports:football:1", "sport": "football", "home_name": "A", "away_name": "B",
                 "kickoff_utc": "2026-11-20T18:00:00+00:00", "kickoff_local": "2026-11-20T18:00:00+00:00",
                 "status": "FINISHED", "payload": {"provider": "api_sports"}}
        result = {"id": match["id"], "sport": "football", "home_name": "A", "away_name": "B",
                  "kickoff_utc": match["kickoff_utc"], "home_score": 1, "away_score": 0,
                  "source": "api_sports", "captured_at": "2026-11-21T00:00:00+00:00"}
        fetch.return_value = {"events": [{"match": match, "result": result}],
                              "quota": {"daily_remaining": "99"}}
        report = self.service.sync_api_sports_range("football", "2026-11-20", "2026-11-20", "key")
        self.assertEqual(report["matches_updated"], 1)
        self.assertEqual(report["inserted"], 1)
        self.assertEqual(self.db.get_match(match["id"])["status"], "FINISHED")
        self.assertEqual(self.db.historical_coverage("football")["total_matches"], 1)

    @patch("app.services.sync_service.fetch_api_sports_day")
    def test_successful_dates_are_cached_and_can_be_forced(self, fetch):
        fetch.return_value = {"events": [], "quota": {"daily_remaining": "99"}}
        first = self.service.sync_api_sports_range("football", "2026-11-20", "2026-11-20", "key")
        second = self.service.sync_api_sports_range("football", "2026-11-20", "2026-11-20", "key")
        forced = self.service.sync_api_sports_range("football", "2026-11-20", "2026-11-20", "key", force=True)
        self.assertEqual(first["days_successful"], 1)
        self.assertEqual(second["days_skipped_cached"], 1)
        self.assertEqual(forced["days_successful"], 1)
        self.assertEqual(fetch.call_count, 2)
        self.assertTrue(self.db.has_provider_sync("api_sports", "football", "2026-11-20"))

    @patch("app.services.sync_service.fetch_api_sports_day")
    def test_incomplete_live_day_is_not_cached(self, fetch):
        live = {"id": "api_sports:basketball:live", "sport": "basketball", "home_name": "A", "away_name": "B",
                "kickoff_utc": "2026-11-20T18:00:00+00:00", "kickoff_local": "2026-11-20T18:00:00+00:00",
                "status": "LIVE", "payload": {"provider": "api_sports"}}
        fetch.return_value = {"events": [{"match": live, "result": None}], "quota": {}}
        report = self.service.sync_api_sports_range("basketball", "2026-11-20", "2026-11-20", "key")
        self.assertEqual(report["days_pending"], 1)
        self.assertFalse(self.db.has_provider_sync("api_sports", "basketball", "2026-11-20"))

    def test_range_is_limited_to_fourteen_days(self):
        with self.assertRaises(ValueError):
            self.service.sync_api_sports_range("football", "2026-01-01", "2026-01-16", "key")

    def test_requires_api_key(self):
        with self.assertRaises(ValueError):
            self.service.sync_api_sports_range("football", "2026-11-20", "2026-11-20", "")

    @patch("app.services.sync_service.fetch_football_team_statistics")
    def test_team_statistics_use_day_before_kickoff_and_cache(self, fetch):
        match = {"id": "api_sports:football:22", "sport": "football", "home_name": "A", "away_name": "B",
                 "kickoff_utc": "2026-11-23T18:00:00+00:00", "kickoff_local": "2026-11-22T22:00:00-08:00",
                 "status": "SCHEDULED", "payload": {"league_id": 39, "season": 2026,
                 "home_team_id": 10, "away_team_id": 20}}
        self.db.upsert_match(match)
        def stats(team_id, league_id, season, cutoff, api_key):
            return {"sport": "football", "team_id": str(team_id), "team_name": str(team_id),
                    "league_id": str(league_id), "season": str(season), "valid_before": cutoff,
                    "observed_at": "2026-11-22T12:00:00+00:00", "source": "test", "statistics": {}}
        fetch.side_effect = stats
        # El servicio filtra los encuentros del día local. Fijamos el resultado
        # para que esta prueba no dependa del huso horario ni de la fecha del runner.
        with patch.object(self.db, "get_today_matches", return_value=[self.db.get_match(match["id"]) ]):
            first = self.service.sync_api_sports_football_team_statistics("key")
            second = self.service.sync_api_sports_football_team_statistics("key")
        self.assertEqual(first["statistics_saved"], 2)
        self.assertEqual(fetch.call_count, 2)
        self.assertEqual(fetch.call_args_list[0].args[3], "2026-11-22")
        self.assertEqual(second["statistics_cached"], 2)


if __name__ == "__main__": unittest.main()
