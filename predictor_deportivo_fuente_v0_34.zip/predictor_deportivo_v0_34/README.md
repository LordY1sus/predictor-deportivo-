# Predictor Deportivo v0.34

Base reconstruida para Android ARM64 (POCO X3 NFC).

## Estado actual (v0.34)
- Aplicación Kivy/SQLite reconstruida para Android ARM64.
- Cartelera mediante ESPN y API-Sports; cuotas mediante The Odds API.
- Importación CSV y descarga histórica acotada, con procedencia, competición, caché y auditoría temporal.
- Motores de referencia para fútbol, baloncesto y béisbol; aún no calibrados con un conjunto de datos real.
- Validación de alineaciones; API-Sports puede importar automáticamente XI oficiales de fútbol cuando están disponibles, y la captura manual sigue disponible como alternativa.
- Ranking EV+/Kelly, snapshots reproducibles y backtesting de predicciones archivadas.
- Flujo CI preparado para ejecutar pruebas y compilar una APK debug en GitHub Actions.
- Copias de seguridad JSON versionadas de la base local: exportación de todas las tablas de datos y restauración transaccional; los registros con identificadores ya existentes se omiten sin sobrescribir información.
- No se ha ejecutado todavía una compilación Android ni una prueba en el POCO X3 NFC.

## Pruebas locales
`python -m unittest discover -s tests -v`

## APK
Compilar en Linux/WSL2 con Buildozer y Android SDK/NDK instalados:
`buildozer android debug`

Esta fuente aún no equivale a una APK instalada ni a un modelo validado para apuestas.

## v0.3 — proveedores iniciales
- Marcadores/horarios: ESPN scoreboard público para NBA, MLB y Premier League.
- Cuotas: The Odds API v4, requiere clave propia y puede tener límites de uso.
- Emparejamiento de cuotas por nombres de equipos y hora dentro de 30 minutos.
- No se emparejan automáticamente eventos ambiguos.
- La fuente ESPN no garantiza cobertura global de fútbol ni alineaciones oficiales.

## Integración de sincronización
- La pantalla incluye actualización manual de calendario.
- La consulta se ejecuta en un hilo separado.
- Los eventos se guardan con horario UTC y horario local.
- El workflow `.github/workflows/android-apk.yml` prepara una compilación debug al publicar un tag `v*` o ejecutar workflow_dispatch desde GitHub.
- Este workflow aún no ha sido ejecutado en una cuenta/repositorio remoto; no significa que exista ya un APK.

## v0.4 — contrato de datos y oportunidades
- Validador pre-partido: exige métricas base positivas y observaciones con fecha anterior al kickoff.
- Bloquea proyecciones si faltan datos estadísticos, incluso cuando hay alineación.
- Builder de oportunidades: compara selección/mercado exactos y descarta EV no positivo.
- Persistencia/lectura de última proyección y consulta de partidos proyectados.
- Las probabilidades siguen siendo prototipos y no están calibradas; el ranking aún requiere integración completa en UI y verificación de mercados por proveedor.

## v0.5 — motores de simulación mejorados
- Fútbol: distribución Poisson con corrección Dixon-Coles para marcadores bajos y Monte Carlo.
- Baloncesto: ajuste por ritmo (pace), factores de alineación/contexto/forma y simulación de marcadores correlacionados.
- Béisbol: simulación aproximada de estados de bases y outs por entrada.
- Los ajustes son explícitos y configurables por partido; no se inventan datos ausentes.
- Limitación: los motores aún requieren calibración con históricos y datos verificados. El modelo de béisbol es una aproximación y no sustituye un motor completo por bateador/pitcher/lineup.

## v0.6 — forma histórica y evaluación
- Nueva tabla SQLite de resultados históricos con fuente y fecha de captura.
- Consulta limitada estrictamente a resultados anteriores al kickoff.
- Cálculo de forma reciente: victorias/empates/derrotas y promedios anotados/permitidos.
- Métricas de backtesting: Brier score, log loss y accuracy para mercados multiclase y binarios.
- No se incluyen datos históricos ficticios ni resultados de ejemplo en la base de producción.
- Pendiente: conectar un proveedor real de resultados históricos y construir un proceso de evaluación walk-forward con predicciones archivadas.

## v0.7 — jugadores, disponibilidad y contexto físico
- Persistencia de observaciones estadísticas por jugador con fuente y fecha.
- Consultas de forma individual limitadas estrictamente a antes del kickoff.
- Persistencia de informes de disponibilidad/lesiones por equipo y partido.
- Validación reforzada de alineaciones: titulares identificados y únicos; el reporte de lesiones de basket requiere fuente y fecha anterior al inicio.
- Cálculo de descanso entre partidos y soporte de distancia de viaje solo si viene acompañada de fuente y timestamp.
- No se fabrican estadísticas de jugadores, lesiones ni distancias. Estos repositorios esperan ingestión de proveedores verificados.

## v0.8 — cuotas por casa y sincronización desde la app
- La base de datos conserva bookmaker, proveedor y hora de captura por cotización.
- Migración automática de bases existentes que no tenían columnas de procedencia.
- La consulta de cuotas conserva la última cotización de cada casa; no mezcla casas distintas.
- Nueva entrada temporal de API key y botón para sincronizar cuotas desde la pantalla.
- La clave no se escribe en la base de datos ni en un archivo; se borra del campo visual al iniciar la consulta y de memoria al terminar.
- La integración de cuotas sigue dependiendo de una clave válida de The Odds API y de la cobertura contratada para cada liga.

## Versión 0.9 — ranking de oportunidades EV+

- Añade un ranking global y una vista por partido para oportunidades con valor esperado positivo.
- Muestra selección, casa de apuestas, cuota decimal, probabilidad del modelo, probabilidad implícita, EV y Kelly fraccionado (¼).
- Conserva cada cotización por casa y ordena las oportunidades por EV descendente.
- Excluye cuotas sin marca temporal válida, futuras (más de 5 minutos) o con más de 6 horas de antigüedad.
- El ranking no inventa proyecciones: requiere una proyección guardada y cuotas reales asociadas al partido.
- El botón de proyección se oculta en partidos en directo; el servicio también rechaza estados distintos de `SCHEDULED`.

Validación de esta versión: `python -m compileall -q .` y 28 pruebas unitarias completadas correctamente. La interfaz Kivy no ha sido ejecutada en un dispositivo Android y todavía no se ha compilado una APK.

## Versión 0.10 — captura controlada de alineaciones

La pantalla de cada partido programado incluye **Alineación**. Permite introducir titulares (uno por línea), enlazar la fuente consultada y confirmar expresamente que se revisó esa fuente.

- Fútbol: exige 11 titulares únicos por equipo.
- Baloncesto: exige cinco titulares por equipo y enlace/fecha del informe oficial de lesiones.
- Béisbol: exige nueve titulares por equipo y pitcher abridor de ambos lados.
- Rechaza fuentes sin URL `http/https`, partidos no programados y confirmaciones posteriores al inicio.
- La app conserva el enlace y el método `user_attested_manual_entry`.

**Límite importante:** esta captura no es una verificación automática del sitio ni descarga alineaciones por sí sola. La persona debe comprobar que el enlace pertenece a la liga/equipo y que la alineación publicada es oficial. La app valida estructura, procedencia declarada y cronología; no certifica la autenticidad del contenido.

## Versión 0.11 — base estadística desde resultados históricos

- Añade `HistoricalExpectationService`, que calcula una expectativa base por equipo usando la media de anotación propia y la media permitida por el rival.
- Soporta goles, puntos y carreras según deporte.
- Exige al menos cinco resultados previos por equipo (ventana predeterminada de diez).
- Excluye partidos históricos futuros y datos capturados después del momento de cálculo.
- La proyección usa métricas explícitas válidas del proveedor cuando existen; si faltan, intenta construir una base desde el histórico local.
- Si no existe muestra suficiente, bloquea la proyección e informa cuántos partidos faltan.

**Advertencia metodológica:** esta base es un proxy calculado desde marcadores finales. No equivale a goles esperados (xG), ratings de eficiencia, estadísticas por jugador ni métricas oficiales avanzadas. No se añaden datos ficticios ni factores de localía arbitrarios. Para usarla se deben importar/recopilar resultados históricos reales y con fuente; esta versión todavía no automatiza una descarga histórica completa.

Validación de esta versión: compilación de sintaxis Python y 39 pruebas unitarias completadas correctamente. No se ha compilado ni probado una APK en dispositivo.

## Versión 0.12 — importación CSV de resultados históricos

Se incorpora `HistoricalImportService` para cargar resultados históricos reales desde CSV UTF-8. La importación valida el archivo completo antes de escribir: deporte admitido, equipos distintos, marcadores enteros no negativos, IDs únicos dentro del archivo y fechas ISO-8601 con zona horaria. Los IDs ya existentes se conservan y se cuentan como duplicados; no se sobrescriben. La inserción del lote es transaccional.

### Formato CSV

Se incluye `historical_results_template.csv`. Columnas obligatorias:

`id,sport,home_name,away_name,kickoff_utc,home_score,away_score,source,captured_at`

- `sport`: `football`, `basketball` o `baseball`.
- `kickoff_utc` y `captured_at`: ISO-8601 con zona horaria, por ejemplo `2026-11-01T18:00:00Z`.
- `source`: identificador o referencia verificable de la fuente del resultado.
- No se deben importar datos inventados ni resultados sin procedencia.

La importación está disponible como servicio de aplicación; todavía no se ha añadido un selector de archivos a la interfaz Kivy. Los resultados que se capturaron después del inicio del partido objetivo se excluyen del cálculo pre-partido, aunque estén almacenados.

Validación v0.12: `python -m compileall -q .` y 44 pruebas unitarias completadas correctamente. Sin APK: este entorno no dispone de Buildozer/Android SDK y el flujo de compilación remoto no ha sido ejecutado.

## Versión 0.13 — pantalla de importación de históricos

- Añade acciones visibles para importar históricos CSV y generar una copia de la plantilla en el almacenamiento privado de la aplicación.
- En Android intenta abrir el selector de archivos del sistema mediante Plyer; conserva un selector Kivy de respaldo para entornos donde no esté disponible.
- El archivo seleccionado se valida por extensión y tamaño (máximo 10 MB) y se procesa mediante `HistoricalImportService.import_file`.
- La interfaz informa cuántos registros se leyeron, insertaron y omitieron por duplicados; los errores no producen una importación parcial.
- Se incluye `plyer` en las dependencias Android y CSV en las extensiones empaquetadas.

Validación v0.13: `python -m compileall -q .` y 47 pruebas unitarias completadas correctamente. El selector nativo, los permisos de almacenamiento y la interfaz aún requieren una prueba real en Android; no se ha compilado APK en este entorno.


## Versión 0.14 — calidad y cobertura del histórico

- Añade un registro de equivalencias explícitas de nombres por deporte (alias → nombre canónico), sin modificar los nombres originales ni sobrescribir resultados importados.
- Las consultas de historial agrupan alias configurados; el cálculo de forma identifica correctamente si el equipo jugó como local o visitante incluso cuando las fuentes usan nombres diferentes.
- Impide reasignar un alias ya utilizado a otro equipo y evita equivalencias automáticas ambiguas.
- Añade en la interfaz el panel **Cobertura histórica**, con partidos, equipos, fuentes, periodo disponible y cantidad de resultados por equipo frente al mínimo de cinco.
- Añade el editor **Unificar equipos** para corregir manualmente diferencias como abreviaturas y nombres alternativos.
- El panel distingue equipos que alcanzan la muestra mínima de aquellos a los que aún les faltan partidos; no crea registros ni completa muestras con datos ficticios.

La cobertura mide cantidad de partidos almacenados, no calidad estadística de la competición ni exactitud de las fuentes. Las equivalencias solo se aplican después de que el usuario las configure.

Validación v0.14: `python -m compileall -q .` y 51 pruebas unitarias completadas correctamente. La interfaz Kivy y la base de datos migrada requieren validación en Android; no se ha compilado una APK en este entorno.


## Versión 0.15 — auditoría de integridad histórica

- Detecta grupos de posibles duplicados por deporte, equipos y proximidad temporal; no elimina registros automáticamente.
- Señala capturas futuras, capturas anteriores al inicio, partidos futuros y fechas inválidas.
- Resume la procedencia de resultados y cuantifica registros sin fuente.
- La auditoría es informativa y no certifica por sí sola la autenticidad de una fuente.

Validación v0.15: compilación Python y 56 pruebas automatizadas.

## Versión 0.16 — descarga acotada de resultados históricos

- Añade un adaptador ESPN para consultar un día específico mediante el parámetro `dates=YYYYMMDD`.
- Solo importa eventos marcados como finalizados y con marcadores numéricos enteros.
- Añade descarga desde la pantalla para un deporte y un rango de fechas, con máximo de 31 días por operación.
- Registra proveedor y hora real de captura; no sobrescribe IDs ya importados.
- Ejecuta la descarga en un hilo independiente y muestra días consultados, resultados encontrados, insertados, duplicados y errores.
- La cobertura del adaptador está limitada a NBA, MLB y Premier League; el endpoint público de ESPN no ofrece SLA y no se ha certificado su disponibilidad desde Android.
- Los datos históricos descargados hoy no se deben usar para simular pronósticos que supuestamente se emitieron antes de hoy: el control temporal de `captured_at` los excluye de esas evaluaciones.

Validación v0.16: `python -m compileall -q .` y 62 pruebas automatizadas completadas. Las respuestas del proveedor se probaron con fixtures simulados; no se ha ejecutado una descarga de producción ni una compilación APK.


## Versión 0.17 — evaluación cronológica de predicciones archivadas

- Añade un servicio de backtesting que empareja predicciones guardadas con resultados finales por deporte, equipos y hora de inicio (tolerancia máxima de cinco minutos).
- Solo utiliza la última predicción creada antes del kickoff; proyecciones posteriores quedan excluidas.
- Rechaza resultados con captura anterior al inicio, coincidencias ambiguas y probabilidades inválidas.
- Calcula Brier, log loss y exactitud para fútbol (tres resultados) y mercados binarios de ganador para baloncesto/béisbol.
- Incluye un panel de evaluación en la aplicación y explica las exclusiones.
- No genera pronósticos retrospectivos para completar la muestra; sin predicciones reales archivadas, no presenta métricas.

## Versión 0.18 — trazabilidad de proyecciones e integración API-Sports

- Las proyecciones nuevas guardan una semilla de simulación, versión del modelo y snapshot de entrada (métricas, observaciones, alineación, fuente y tiempos).
- La base de datos migra automáticamente las tablas de proyecciones antiguas; los registros previos se marcan como `legacy` y sin snapshot.
- El backtest excluye predicciones antiguas sin snapshot auditable y comprueba que observaciones y alineación sean anteriores al inicio.
- Incorpora un adaptador API-Sports para fixtures/resultados de fútbol, baloncesto y béisbol, con estados programado/en directo/finalizado.
- Añade sincronización diaria y descarga histórica acotada a 14 días por operación (una llamada por día), conservando proveedor, cuotas de uso y resultados sin sobrescribir IDs existentes.
- La clave API-Sports se introduce en la app, se usa en memoria y se borra al terminar; no se guarda en SQLite ni en archivos.
- Se conserva ESPN como alternativa. API-Sports requiere una clave y la suscripción/cobertura correspondiente para cada deporte; la disponibilidad de datos depende de liga, temporada y plan.

Validación v0.18: `python -m compileall -q .` y 78 pruebas automatizadas completadas. Las respuestas API-Sports se validaron con respuestas simuladas; no se ha probado una clave real ni una descarga de producción. La interfaz Kivy no se ha ejecutado en Android y todavía no se ha compilado APK.


## Versión 0.19 — aislamiento de históricos por competición

- Añade el campo opcional `competition` a resultados históricos con migración automática de bases SQLite anteriores.
- La plantilla CSV incluye la columna opcional `competition`; las importaciones antiguas sin esa columna siguen siendo compatibles.
- Las expectativas históricas de una cartelera se calculan solo con resultados de la misma competición cuando el partido objetivo identifica liga/copa.
- La auditoría de duplicados distingue competiciones diferentes para reducir falsos positivos.
- El panel de cobertura muestra partidos y equipos por competición.
- API-Sports y ESPN conservan el nombre de la competición en sus eventos/resultados cuando el proveedor lo facilita.
- El backtest filtra por competición cuando el evento la identifica; si no existe una coincidencia inequívoca, excluye el registro.
- El flujo Buildozer acepta automáticamente las licencias del SDK en CI y conserva `arm64-v8a` para el POCO X3 NFC.

Validación v0.19: `python -m compileall -q .` y 81 pruebas automatizadas completadas. No se ha ejecutado la compilación Android.


## Versión 0.20 — control de cuota y caché de sincronización

- Añade una bitácora SQLite de fechas consultadas por proveedor/deporte, con cantidad de eventos y hora de sincronización.
- Las descargas históricas API-Sports omiten fechas ya completadas para no consumir llamadas repetidas; se conserva la opción `force=True` para refrescar expresamente.
- Los días con partidos en directo, programados o finalizados sin marcador no se marcan como completos, para permitir reintentar cuando el proveedor actualice el resultado.
- La actualización del día actual fuerza la consulta para mantener actualizada la cartelera.
- Añade verificación de clave/suscripción API-Sports mediante `/status` y muestra plan, estado y cuota diaria restante.
- La clave se borra del campo y de memoria tras la consulta.

Validación v0.20: `python -m compileall -q .` y 85 pruebas automatizadas completadas. No se ha probado una clave real.


## Versión 0.21 — alineaciones oficiales y observaciones de ausencias (fútbol)

- Integra el endpoint API-Football `/fixtures/lineups` para descargar las alineaciones previas de partidos de hoy que ya estén en la base de datos con ID de API-Sports.
- Solo guarda una alineación como `official` cuando se identifican los dos equipos y cada uno tiene exactamente once titulares únicos. Las alineaciones incompletas, tardías o sin asociación inequívoca se rechazan.
- Conserva suplentes, formación, entrenador, proveedor y hora de observación. La validación exige que la consulta se haya realizado antes del inicio.
- Integra `/injuries` para guardar observaciones de ausencias por jugador, equipo y partido. El campo temporal se denomina `provider_observed_at`: no se confunde la hora de consulta con la fecha original de publicación del informe.
- Las observaciones posteriores al kickoff se excluyen de consultas pre-partido mediante corte temporal.
- Añade el botón **Alineaciones y ausencias oficiales (fútbol)**. La operación se ejecuta en segundo plano y revisa un máximo de 12 partidos por ejecución para limitar el consumo.
- Esta integración automática cubre fútbol mediante API-Football. No se ha supuesto que los endpoints o estructuras de lineup/lesiones sean iguales en baloncesto o béisbol; esos deportes mantienen sus validaciones manuales hasta verificar la documentación y cobertura específicas.

La documentación de API-Football indica que las alineaciones suelen estar disponibles entre 20 y 40 minutos antes del inicio cuando la competición ofrece esa cobertura; no todas las ligas las proporcionan. La cobertura debe comprobarse por competición y temporada.

Validación v0.21: `python -m compileall -q .` y 93 pruebas automatizadas completadas. Las respuestas del proveedor se probaron con fixtures simulados; no se ha probado una clave real ni una respuesta de producción. La interfaz Android y la compilación APK siguen pendientes.


## Versión 0.22 — estadísticas agregadas de equipos (fútbol)

- Enriquece los partidos API-Football con IDs de equipo, competición y temporada para enlazar estadísticas sin depender de coincidencias por nombre.
- Integra `/teams/statistics` para recuperar el rendimiento agregado de cada equipo en su liga y temporada.
- La consulta usa como fecha de corte el día anterior al kickoff; no incorpora el partido del día ni estadísticas posteriores.
- Persiste cada observación con deporte, IDs, competición, temporada, fecha de validez, hora de captura, proveedor y respuesta original.
- La lectura de estadísticas exige que tanto la fecha de validez como la captura sean anteriores al inicio del encuentro.
- Añade caché por equipo/liga/temporada/fecha de corte y limita cada ejecución a cinco partidos (hasta diez consultas de equipos).
- El botón nuevo **Estadísticas de equipos pre-partido (fútbol)** ejecuta las consultas en segundo plano.
- Esta fase cubre fútbol; no se han extrapolado endpoints de estadísticas a basket o béisbol sin validar sus contratos y cobertura.

La documentación oficial de API-Football describe `/teams/statistics` con los parámetros `league`, `season`, `team` y `date`, y explica que `date` limita el agregado hasta esa fecha. La cobertura varía por liga y temporada: [documentación oficial](https://www.api-football.com/documentation-v3).

Validación v0.22: `python -m compileall -q .` y 99 pruebas automatizadas completadas. Las respuestas del proveedor se validaron con fixtures simulados; no se ha usado una clave real. La pantalla Kivy no se ha ejecutado en Android y la APK todavía no se ha compilado.


## v0.22 — estadísticas de equipo pre-partido
- Se añadieron IDs de equipo, liga y temporada al evento de API-Sports.
- Descarga limitada de estadísticas de temporada para fútbol, con corte al día anterior al partido y caché por equipo/competición/temporada.
- Persistencia de estadísticas con fecha de validez, hora de captura y fuente.
- La ausencia de estadísticas no se rellena con valores inventados; el sistema conserva el proxy histórico o bloquea la proyección si no hay datos suficientes.

## v0.23 — integración de estadísticas en el motor de fútbol
- Las tasas oficiales de goles anotados y recibidos, separadas por localía/visita, ahora ajustan la expectativa histórica antes de la simulación Poisson/Dixon-Coles.
- Combinación conservadora: 65% tasas oficiales y 35% proxy histórico, con límite máximo del peso oficial en el servicio.
- Solo se combinan registros de ambos equipos con misma liga/temporada, fecha de validez anterior al partido y captura anterior al kickoff.
- Si falta una de las dos fuentes o las tasas están incompletas, se conserva el baseline sin ajuste.
- El snapshot de proyección conserva el origen, tasas y método de ajuste para auditoría.
- Esta integración cubre fútbol; no se atribuye aún a baloncesto ni béisbol.
- Pruebas automatizadas: 102 superadas. La APK todavía no se ha compilado ni probado en dispositivo.

## v0.24 — snapshots de estadísticas individuales (fútbol)
- Añade consulta paginada de API-Football `/players` por equipo, liga, temporada y página (20 jugadores por página según la documentación del proveedor).
- Normaliza ID/nombre del jugador, equipo, posición y estadísticas de temporada, conservando la hora exacta de captura y la procedencia.
- Rechaza snapshots cuya captura sea igual o posterior al inicio del partido.
- Persiste las observaciones y permite asociarlas a los titulares de la alineación por nombre, aplicando de nuevo el corte temporal antes del kickoff.
- Incorpora las observaciones individuales disponibles al snapshot auditable de la proyección. En esta versión todavía no alteran numéricamente las probabilidades: se evita introducir ponderaciones arbitrarias sin validación histórica.
- El endpoint de jugadores no ofrece un parámetro de fecha de corte; por tanto, el flujo solo es válido para capturas realizadas antes de partidos futuros. No debe utilizarse para reconstruir estadísticas conocidas antes de partidos pasados.
- La captura es paginada y consume cuota de API; el usuario debe seleccionar equipo/liga/temporada y controlar las páginas necesarias. La cobertura depende de la competición.

Validación v0.24: 107 pruebas automatizadas superadas. Las respuestas del proveedor se probaron con datos simulados; no se ha usado una clave real. La interfaz Android no se ha ejecutado y la APK sigue pendiente.


## Versión 0.25.0 — snapshots multideporte con fecha de corte

- Añade captura de estadísticas de equipo de baloncesto y béisbol mediante endpoints API-Sports con parámetro `date`.
- La captura exige realizarse antes del inicio del partido y solicita datos hasta el día anterior al encuentro.
- Persiste las observaciones con deporte, equipo, liga, temporada, corte válido y hora de observación; permite recuperar únicamente observaciones anteriores al inicio.
- No se usan estadísticas de jugadores obtenidas del propio partido como predictores previos. La cobertura depende de la competición y del plan contratado.
- Los snapshots quedan almacenados y auditables; todavía no modifican automáticamente las probabilidades del motor hasta disponer de validación histórica por deporte.

### v0.26.0 — auditoría de estadísticas multideporte
- Las proyecciones de baloncesto y béisbol adjuntan snapshots pre-partido de ambos equipos al registro de entradas, si están disponibles y cumplen el corte temporal.
- Se exige correspondencia de deporte, equipo, liga y temporada; se rechazan observaciones capturadas después del inicio o con fecha de validez del mismo día del partido.
- Estos agregados se conservan para auditoría y análisis; todavía no alteran las expectativas del modelo. No se aplican pesos numéricos sin normalizar las distintas estructuras de API y validar su mejora con backtesting walk-forward.


## Versión 0.27.0 — calibración del backtesting

El informe de backtesting ahora incluye error de calibración esperado (ECE) y
frecuencias observadas por intervalos de confianza. En fútbol se calcula sobre
la confianza de la clase elegida; en baloncesto y béisbol sobre la probabilidad
de victoria local. El ECE depende del tamaño de muestra y de los intervalos,
por lo que debe interpretarse junto con Brier Score y Log Loss, nunca como
garantía de rendimiento futuro. También se rechazan probabilidades no finitas.

## Versión 0.28.0 — seguimiento temporal del backtesting

- El informe histórico desglosa las métricas por mes UTC además del total por deporte.
- Cada período muestra muestras, Brier Score, Log Loss, Accuracy, ECE y los intervalos de calibración disponibles.
- El desglose ayuda a detectar variaciones temporales y períodos con resultados débiles que el promedio global podría ocultar.
- El agrupamiento mensual es descriptivo: no reentrena modelos, no crea pronósticos retrospectivos y no demuestra por sí solo estabilidad ni rentabilidad.
- Se mantiene la selección de la última proyección archivada estrictamente anterior al kickoff y el emparejamiento inequívoco con el resultado final.


## v0.29.0 — Integridad temporal de cuotas prepartido

El ranking de oportunidades ahora exige `kickoff_utc` con zona horaria, rechaza cuotas capturadas al inicio o después del partido, descarta cuotas con captura futura respecto al momento de evaluación y no genera oportunidades cuando el encuentro ya comenzó. Esto evita que cuotas live o posteriores contaminen el análisis prepartido. La validación no demuestra rentabilidad; requiere cuotas archivadas y resultados reales para un backtest fuera de muestra.

## v0.30 — calculadora de riesgo y banca
- Incorpora `calculate_stake`: calcula Kelly fraccionado y aplica un límite estricto configurable (1% de banca por defecto).
- Si el EV estimado no es positivo, el stake calculado es cero.
- Incorpora `simulate_bankroll` para reproducir resultados explícitos (ganada, perdida o nula), saldo final y drawdown máximo; no inventa resultados.
- Añade a la interfaz una calculadora de riesgo que no ejecuta apuestas ni guarda credenciales.
- Estas herramientas son simulaciones matemáticas; no prueban rentabilidad ni calibración del modelo.

Validación v0.30: pruebas unitarias del módulo de riesgo y suite completa ejecutadas; la compilación Android todavía requiere el workflow remoto y no se ha generado una APK.

## Versión 0.31 — publicación verificable de APK en GitHub Releases

- Corrige el flujo Android: las compilaciones manuales producen un artefacto descargable de GitHub Actions; las compilaciones disparadas por una etiqueta `v*` publican además ese mismo APK como adjunto de un GitHub Release.
- El job de publicación depende del job de compilación, y este depende de las pruebas automatizadas; una compilación que no supera los tests no puede publicar el APK.
- Declara explícitamente `contents: write` para que el job de release pueda adjuntar el archivo.
- Excluye pruebas, metadatos GitHub y cachés `__pycache__`/`.pyc` del paquete Android para reducir tamaño y evitar bytecode local.
- Mantiene `arm64-v8a`, API mínima 23 y Kivy 2.3.1 para el objetivo Android indicado.

Validación v0.31: las pruebas unitarias se ejecutan localmente en Python; el workflow YAML se valida sintácticamente y sus dependencias entre jobs y condiciones de publicación se comprueban con pruebas de regresión. Esto no equivale a ejecutar Buildozer ni a probar la APK en un teléfono. La publicación real requiere subir el proyecto a un repositorio GitHub y ejecutar el workflow allí.

## Versión 0.32 — verificación del APK y huella SHA-256

El workflow de Android ahora comprueba que se genere exactamente un APK, valida la integridad del contenedor ZIP y verifica que incluya bibliotecas nativas `arm64-v8a`, arquitectura objetivo del dispositivo. También calcula y publica un archivo `SHA256SUMS.txt` junto al APK. El nombre del artefacto es dinámico y coincide entre los jobs de compilación y publicación, evitando desajustes al cambiar de versión o ejecutar manualmente el flujo.

La comprobación de arquitectura y la huella se realizan después de compilar y antes de subir el artefacto. Una ejecución manual deja el APK descargable en Actions; una etiqueta `v*` además adjunta el APK y su checksum a GitHub Releases. Esta modificación del workflow aún necesita ejecutarse en un repositorio GitHub para comprobar la compilación real; las pruebas locales solo validan la configuración y el código.


## Versión 0.33 — copias de seguridad y restauración

- Añade exportación JSON versionada de partidos, alineaciones, cuotas, proyecciones, históricos, alias, observaciones, informes y bitácoras de sincronización.
- La restauración valida formato, versión, tablas y columnas antes de importar; aplica una transacción completa y revierte todo el lote ante un registro inválido.
- Los identificadores existentes se omiten (`INSERT OR IGNORE`); la restauración no reemplaza registros locales.
- La copia se crea en el almacenamiento privado de la app. El usuario debe copiarla a un lugar externo antes de desinstalar o cambiar de dispositivo.
- Validación v0.33: 4 pruebas nuevas de exportación/restauración, idempotencia, formato inválido y rollback.


## Versión 0.34 — compilación remota alternativa

- Se estabiliza una prueba de sincronización de estadísticas para que no dependa de la fecha local ni del huso horario del runner de CI.
- Se incorpora una vía de compilación remota desde un ZIP mediante GitHub Actions, sin requerir que la integración de ChatGPT tenga permisos de escritura.
