[app]
title = Predictor Deportivo
package.name = predictordeportivo
package.domain = org.personal
source.dir = .
source.include_exts = py,kv,png,jpg,txt,json,csv
source.exclude_dirs = tests,.git,.github,__pycache__
source.exclude_patterns = *.pyc,*/__pycache__/*
version = 0.34.0
requirements = python3,kivy==2.3.1,plyer
orientation = portrait
fullscreen = 0
android.permissions = INTERNET
android.api = 35
android.minapi = 23
android.ndk_api = 23
android.archs = arm64-v8a
android.allow_backup = False
android.accept_sdk_license = True
android.private_storage = True

[buildozer]
log_level = 2
warn_on_root = 1
