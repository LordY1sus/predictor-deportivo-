from datetime import datetime, timezone, timedelta
from pathlib import Path
from kivy.app import App
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView
from kivy.uix.popup import Popup
from kivy.uix.checkbox import CheckBox
from kivy.uix.filechooser import FileChooserListView
from kivy.metrics import dp

from app.storage.database import Database
from app.services.projection_service import ProjectionService
from app.services.sync_service import SyncService
from app.services.opportunity_service import OpportunityService
from app.services.lineup_intake import LineupIntakeService
from app.services.historical_import import HistoricalImportService
from app.services.historical_quality import HistoricalQualityService
from app.services.historical_integrity import HistoricalIntegrityService
from app.services.historical_backtest import HistoricalBacktestService
from app.analytics.risk_management import calculate_stake
from app.services.backup_service import BackupService

KV = """
<RootView>:
    orientation: "vertical"
    padding: "12dp"
    spacing: "8dp"
    BoxLayout:
        size_hint_y: None
        height: "48dp"
        Label:
            text: "PREDICTOR DEPORTIVO"
            bold: True
            halign: "left"
            text_size: self.size
        Spinner:
            id: sport
            text: "Todos"
            values: ["Todos", "Fútbol", "Baloncesto", "Béisbol"]
            size_hint_x: .42
            on_text: app.refresh_matches()
    BoxLayout:
        size_hint_y: None
        height: "40dp"
        Button:
            text: "Actualizar partidos"
            size_hint_x: .55
            on_release: app.sync_scoreboard()
        Label:
            text: "Simulaciones"
            size_hint_x: .45
        Spinner:
            id: sims
            text: "10000"
            values: ["1000", "5000", "10000", "25000", "50000"]
            size_hint_x: .55
    BoxLayout:
        size_hint_y: None
        height: "42dp"
        TextInput:
            id: api_sports_key
            hint_text: "Clave API-Sports (solo esta sesión)"
            password: True
            multiline: False
            size_hint_x: .55
        Button:
            text: "Verificar"
            size_hint_x: .2
            on_release: app.check_api_sports_key()
        Button:
            text: "Actualizar"
            size_hint_x: .25
            on_release: app.sync_api_sports()
    BoxLayout:
        size_hint_y: None
        height: "42dp"
        TextInput:
            id: odds_key
            hint_text: "Clave The Odds API (solo esta sesión)"
            password: True
            multiline: False
            size_hint_x: .72
        Button:
            text: "Actualizar cuotas"
            size_hint_x: .28
            on_release: app.sync_odds()
    BoxLayout:
        size_hint_y: None
        height: "42dp"
        Button:
            text: "Importar históricos CSV"
            on_release: app.open_historical_import()
        Button:
            text: "Plantilla CSV"
            on_release: app.create_csv_template()
    BoxLayout:
        size_hint_y: None
        height: "42dp"
        Button:
            text: "Cobertura histórica"
            on_release: app.show_historical_coverage()
        Button:
            text: "Unificar equipos"
            on_release: app.open_team_alias_editor()
    BoxLayout:
        size_hint_y: None
        height: "42dp"
        TextInput:
            id: history_start
            text: ""
            hint_text: "Desde AAAA-MM-DD"
            multiline: False
        TextInput:
            id: history_end
            text: ""
            hint_text: "Hasta AAAA-MM-DD"
            multiline: False
        Button:
            text: "Históricos ESPN"
            size_hint_x: .9
            on_release: app.sync_historical()
    Button:
        text: "Históricos API-Sports"
        size_hint_y: None
        height: "40dp"
        on_release: app.sync_api_sports_history()
    Button:
        text: "Alineaciones y ausencias oficiales (fútbol)"
        size_hint_y: None
        height: "40dp"
        on_release: app.sync_api_sports_football_pre_match()
    Button:
        text: "Estadísticas de equipos pre-partido (fútbol)"
        size_hint_y: None
        height: "40dp"
        on_release: app.sync_api_sports_football_team_statistics()
    BoxLayout:
        size_hint_y: None
        height: "42dp"
        Button:
            text: "Crear copia de seguridad"
            on_release: app.create_data_backup()
        Button:
            text: "Restaurar copia JSON"
            on_release: app.open_backup_import()
    Button:
        text: "Evaluar pronósticos archivados"
        size_hint_y: None
        height: "40dp"
        on_release: app.show_historical_backtest()
    Button:
        text: "Auditar calidad de históricos"
        size_hint_y: None
        height: "40dp"
        on_release: app.show_historical_integrity()
    Button:
        text: "Ranking de oportunidades EV+"
        size_hint_y: None
        height: "42dp"
        on_release: app.show_opportunities()
    Button:
        text: "Calculadora de riesgo y banca"
        size_hint_y: None
        height: "42dp"
        on_release: app.show_risk_calculator()
    Label:
        id: status
        text: "Esperando datos deportivos. No se muestran partidos ficticios."
        size_hint_y: None
        height: "42dp"
        text_size: self.width, None
    ScrollView:
        do_scroll_x: False
        GridLayout:
            id: matches
            cols: 1
            spacing: "8dp"
            size_hint_y: None
            height: self.minimum_height
"""

class RootView(BoxLayout):
    pass

class PredictorApp(App):
    def build(self):
        self.db = Database(str(Path(self.user_data_dir) / "predictor.db"))
        self.service = ProjectionService(self.db)
        self.sync_service = SyncService(self.db)
        self.opportunity_service = OpportunityService(self.db)
        self.lineup_service = LineupIntakeService(self.db)
        self.historical_import_service = HistoricalImportService(self.db)
        self.historical_quality_service = HistoricalQualityService(self.db, minimum_games=5)
        self.historical_integrity_service = HistoricalIntegrityService(self.db)
        self.historical_backtest_service = HistoricalBacktestService(self.db)
        self.backup_service = BackupService(self.db)
        self._sync_thread = None
        self._odds_thread = None
        self._historical_thread = None
        self._api_sports_thread = None
        self._api_sports_key = ""
        self._odds_api_key = ""
        Builder.load_string(KV)
        self.root_view = RootView()
        today = datetime.now().date()
        self.root_view.ids.history_start.text = (today - timedelta(days=6)).isoformat()
        self.root_view.ids.history_end.text = today.isoformat()
        Clock.schedule_once(lambda *_: self.refresh_matches(), 0)
        return self.root_view

    def refresh_matches(self):
        if not hasattr(self, "root_view"):
            return
        container = self.root_view.ids.matches
        container.clear_widgets()
        sport_map = {"Fútbol": "football", "Baloncesto": "basketball", "Béisbol": "baseball"}
        selected = self.root_view.ids.sport.text
        sport = sport_map.get(selected)
        matches = self.db.get_today_matches(sport=sport)
        if not matches:
            container.add_widget(Label(
                text="No hay partidos disponibles para mostrar. Conecta un proveedor de datos para cargar la cartelera.",
                size_hint_y=None, height=dp(90), halign="center", valign="middle"
            ))
            self.root_view.ids.status.text = "Cartelera vacía: no se inventan eventos ni cuotas."
            return
        for match in matches:
            row = BoxLayout(orientation="vertical", size_hint_y=None, height=dp(112), padding=dp(8), spacing=dp(4))
            row.add_widget(Label(text=f"{match['home_name']} vs {match['away_name']}  ·  {match['status']}", size_hint_y=None, height=dp(32)))
            row.add_widget(Label(text=f"{match['sport']}  |  {match['kickoff_local']}", size_hint_y=None, height=dp(26)))
            actions = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(6))
            if match["status"] == "SCHEDULED":
                btn = Button(text="Proyectar")
                btn.bind(on_release=lambda _btn, mid=match["id"]: self.project_match(mid))
                actions.add_widget(btn)
            else:
                actions.add_widget(Label(text="En directo · proyección previa deshabilitada"))
            lineup_btn = Button(text="Alineación", size_hint_x=.42)
            lineup_btn.bind(on_release=lambda _btn, m=dict(match): self.open_lineup_editor(m))
            actions.add_widget(lineup_btn)
            ev_btn = Button(text="Ver EV+", size_hint_x=.42)
            ev_btn.bind(on_release=lambda _btn, mid=match["id"]: self.show_opportunities(mid))
            actions.add_widget(ev_btn)
            row.add_widget(actions)
            container.add_widget(row)

    def sync_scoreboard(self):
        import threading
        if self._sync_thread and self._sync_thread.is_alive():
            self.root_view.ids.status.text = "La actualización ya está en curso."
            return
        self.root_view.ids.status.text = "Consultando calendario deportivo..."
        def work():
            result = self.sync_service.sync_scoreboard()
            Clock.schedule_once(lambda *_: self._sync_done(result), 0)
        self._sync_thread = threading.Thread(target=work, daemon=True)
        self._sync_thread.start()

    def sync_odds(self):
        import threading
        key=self.root_view.ids.odds_key.text.strip()
        if not key:
            self.root_view.ids.status.text = "Introduce tu clave de The Odds API para consultar cuotas."
            return
        selected=self.root_view.ids.sport.text
        sport_map={"Fútbol":"football","Baloncesto":"basketball","Béisbol":"baseball"}
        sports=[sport_map[selected]] if selected in sport_map else ["football","basketball","baseball"]
        if self._odds_thread and self._odds_thread.is_alive():
            self.root_view.ids.status.text = "La actualización de cuotas ya está en curso."
            return
        self._odds_api_key=key
        self.root_view.ids.status.text = "Consultando cuotas y asociándolas a partidos..."
        def work():
            totals={"odds_saved":0,"unmatched":0,"errors":[]}
            for sport in sports:
                try:
                    result=self.sync_service.sync_odds(sport,self._odds_api_key)
                    totals["odds_saved"]+=result["odds_saved"]
                    totals["unmatched"]+=result["unmatched"]
                except Exception as exc:
                    totals["errors"].append(f"{sport}: {exc}")
            self._odds_api_key=""
            Clock.schedule_once(lambda *_: self._odds_done(totals),0)
        self._odds_thread=threading.Thread(target=work,daemon=True)
        self._odds_thread.start()
        self.root_view.ids.odds_key.text=""

    def _odds_done(self,result):
        self.root_view.ids.odds_key.text=""
        self.root_view.ids.status.text=(
            f"Cuotas guardadas: {result['odds_saved']} | Sin partido asociado: {result['unmatched']} "
            + (" | ".join(result["errors"]) if result["errors"] else "")
        )

    def _sync_done(self, result):
        self.root_view.ids.status.text = (
            f"Partidos actualizados: {result['matches_updated']}. "
            + (" | ".join(result["errors"]) if result["errors"] else "Fuentes consultadas.")
        )
        self.refresh_matches()



    def _selected_sport_code(self):
        return {"Fútbol": "football", "Baloncesto": "basketball", "Béisbol": "baseball"}.get(self.root_view.ids.sport.text)


    def check_api_sports_key(self):
        import threading
        sport = self._selected_sport_code()
        key = self.root_view.ids.api_sports_key.text.strip()
        if not sport:
            self._show_error("Selecciona un deporte para verificar la suscripción API-Sports.")
            return
        if not key:
            self._show_error("Introduce tu clave API-Sports.")
            return
        if self._api_sports_thread and self._api_sports_thread.is_alive():
            self.root_view.ids.status.text = "Hay una consulta API-Sports en curso."
            return
        self._api_sports_key = key
        self.root_view.ids.api_sports_key.text = ""
        self.root_view.ids.status.text = "Verificando clave y cuota API-Sports..."
        def work():
            try:
                result = self.sync_service.check_api_sports_account(sport, self._api_sports_key)
            except Exception as exc:
                result = {"error": str(exc)}
            finally:
                self._api_sports_key = ""
            Clock.schedule_once(lambda *_: self._api_sports_status_done(result), 0)
        self._api_sports_thread = threading.Thread(target=work, daemon=True)
        self._api_sports_thread.start()

    def _api_sports_status_done(self, result):
        self.root_view.ids.api_sports_key.text = ""
        if "error" in result:
            self.root_view.ids.status.text = "API-Sports: " + result["error"]
            return
        self.root_view.ids.status.text = (
            f"API-Sports · plan {result.get('plan') or 'no identificado'} · "
            f"suscripción activa: {result.get('active')} · "
            f"peticiones hoy: {result.get('requests_used')} / {result.get('daily_limit')} · "
            f"restantes: {result.get('daily_remaining')}"
        )

    def sync_api_sports(self):
        import threading
        sport = self._selected_sport_code()
        key = self.root_view.ids.api_sports_key.text.strip()
        if not sport:
            self._show_error("Selecciona un deporte concreto para usar API-Sports.")
            return
        if not key:
            self._show_error("Introduce tu clave API-Sports. La app no la guarda.")
            return
        if self._api_sports_thread and self._api_sports_thread.is_alive():
            self.root_view.ids.status.text = "La sincronización API-Sports ya está en curso."
            return
        self._api_sports_key = key
        self.root_view.ids.api_sports_key.text = ""
        day = datetime.now(timezone.utc).date().isoformat()
        self.root_view.ids.status.text = "Consultando cartelera API-Sports..."
        def work():
            try:
                result = self.sync_service.sync_api_sports_range(sport, day, day, self._api_sports_key, force=True)
            except Exception as exc:
                result = {"error": str(exc)}
            finally:
                self._api_sports_key = ""
            Clock.schedule_once(lambda *_: self._api_sports_done(result), 0)
        self._api_sports_thread = threading.Thread(target=work, daemon=True)
        self._api_sports_thread.start()

    def sync_api_sports_history(self):
        import threading
        sport = self._selected_sport_code()
        key = self.root_view.ids.api_sports_key.text.strip() or self._api_sports_key
        if not sport:
            self._show_error("Selecciona un deporte concreto para descargar históricos API-Sports.")
            return
        if not key:
            self._show_error("Introduce tu clave API-Sports antes de descargar históricos.")
            return
        if self._api_sports_thread and self._api_sports_thread.is_alive():
            self.root_view.ids.status.text = "La sincronización API-Sports ya está en curso."
            return
        start = self.root_view.ids.history_start.text.strip()
        end = self.root_view.ids.history_end.text.strip()
        self._api_sports_key = key
        self.root_view.ids.api_sports_key.text = ""
        self.root_view.ids.status.text = "Descargando históricos API-Sports; se hará una petición por día..."
        def work():
            try:
                result = self.sync_service.sync_api_sports_range(sport, start, end, self._api_sports_key)
            except Exception as exc:
                result = {"error": str(exc)}
            finally:
                self._api_sports_key = ""
            Clock.schedule_once(lambda *_: self._api_sports_done(result), 0)
        self._api_sports_thread = threading.Thread(target=work, daemon=True)
        self._api_sports_thread.start()

    def sync_api_sports_football_pre_match(self):
        import threading
        key = self.root_view.ids.api_sports_key.text.strip()
        if not key:
            self._show_error("Introduce tu clave API-Sports. Se consultarán alineaciones de fútbol y ausencias disponibles.")
            return
        if self._api_sports_thread and self._api_sports_thread.is_alive():
            self.root_view.ids.status.text = "La consulta API-Sports ya está en curso."
            return
        self._api_sports_key = key
        self.root_view.ids.api_sports_key.text = ""
        self.root_view.ids.status.text = "Consultando alineaciones y ausencias de partidos de fútbol de hoy..."
        def work():
            try:
                result = self.sync_service.sync_api_sports_football_pre_match(self._api_sports_key)
            except Exception as exc:
                result = {"error": str(exc)}
            finally:
                self._api_sports_key = ""
            Clock.schedule_once(lambda *_: self._api_sports_pre_match_done(result), 0)
        self._api_sports_thread = threading.Thread(target=work, daemon=True)
        self._api_sports_thread.start()

    def sync_api_sports_football_team_statistics(self):
        import threading
        key = self.root_view.ids.api_sports_key.text.strip()
        if not key:
            self._show_error("Introduce tu clave API-Sports. Se consultarán estadísticas de fútbol hasta el día anterior a cada partido.")
            return
        if self._api_sports_thread and self._api_sports_thread.is_alive():
            self.root_view.ids.status.text = "La consulta API-Sports ya está en curso."
            return
        self._api_sports_key = key
        self.root_view.ids.api_sports_key.text = ""
        self.root_view.ids.status.text = "Descargando estadísticas de equipos con corte pre-partido..."
        def work():
            try:
                result = self.sync_service.sync_api_sports_football_team_statistics(self._api_sports_key)
            except Exception as exc:
                result = {"error": str(exc)}
            finally:
                self._api_sports_key = ""
            Clock.schedule_once(lambda *_: self._api_sports_team_stats_done(result), 0)
        self._api_sports_thread = threading.Thread(target=work, daemon=True)
        self._api_sports_thread.start()

    def _api_sports_team_stats_done(self, result):
        self.root_view.ids.api_sports_key.text = ""
        if "error" in result:
            self.root_view.ids.status.text = "API-Sports: " + result["error"]
            return
        self.root_view.ids.status.text = (
            f"Partidos revisados: {result['matches_checked']} · estadísticas guardadas: "
            f"{result['statistics_saved']} · caché reutilizada: {result['statistics_cached']}"
            + (" · avisos: " + " | ".join(result["errors"][:2]) if result["errors"] else "")
        )
        self.refresh_matches()

    def _api_sports_pre_match_done(self, result):
        self.root_view.ids.api_sports_key.text = ""
        if "error" in result:
            self.root_view.ids.status.text = "API-Sports: " + result["error"]
            return
        self.root_view.ids.status.text = (
            f"Partidos revisados: {result['matches_checked']} · alineaciones oficiales completas: "
            f"{result['lineups_saved']} · observaciones de ausencias: {result['injury_observations']}"
            + (" · avisos: " + " | ".join(result["errors"][:2]) if result["errors"] else "")
        )
        self.refresh_matches()

    def _api_sports_done(self, result):
        self.root_view.ids.api_sports_key.text = ""
        if "error" in result:
            self.root_view.ids.status.text = "API-Sports: " + result["error"]
            return
        quota = result.get("quota") or {}
        remaining = quota.get("daily_remaining")
        quota_text = f" · cuota diaria restante: {remaining}" if remaining is not None else ""
        message = (f"API-Sports {result['sport']} · días {result['days_successful']}/"
                   f"{result['days_requested']} · omitidos por caché {result.get('days_skipped_cached', 0)} · "
                   f"partidos {result['matches_updated']} · "
                   f"resultados nuevos {result['inserted']} · duplicados {result['duplicates']}" + quota_text)
        if result["errors"]:
            message += " · errores: " + " | ".join(result["errors"][:2])
        self.root_view.ids.status.text = message
        self.refresh_matches()

    def sync_historical(self):
        """Descarga una ventana acotada de resultados finalizados ESPN."""
        import threading
        sport_map = {"Fútbol": "football", "Baloncesto": "basketball", "Béisbol": "baseball"}
        selected = self.root_view.ids.sport.text
        if selected not in sport_map:
            self._show_error("Selecciona un deporte concreto para descargar históricos.")
            return
        if self._historical_thread and self._historical_thread.is_alive():
            self.root_view.ids.status.text = "La descarga histórica ya está en curso."
            return
        start = self.root_view.ids.history_start.text.strip()
        end = self.root_view.ids.history_end.text.strip()
        self.root_view.ids.status.text = "Descargando resultados históricos de ESPN..."
        def work():
            try:
                result = self.sync_service.sync_historical_range(sport_map[selected], start, end)
            except Exception as exc:
                result = {"error": str(exc)}
            Clock.schedule_once(lambda *_: self._historical_done(result), 0)
        self._historical_thread = threading.Thread(target=work, daemon=True)
        self._historical_thread.start()

    def _historical_done(self, result):
        if "error" in result:
            self.root_view.ids.status.text = "Descarga histórica fallida: " + result["error"]
            return
        message = (f"ESPN · {result['sport']} · días consultados {result['days_successful']}/"
                   f"{result['days_requested']} · encontrados {result['records_found']} · "
                   f"nuevos {result['inserted']} · duplicados {result['duplicates']}")
        if result["errors"]:
            message += " · errores: " + " | ".join(result["errors"][:3])
        self.root_view.ids.status.text = message
        self.show_historical_coverage()

    def create_csv_template(self):
        """Escribe la plantilla en el almacenamiento privado de la aplicación."""
        from pathlib import Path
        template = Path(__file__).with_name("historical_results_template.csv")
        destination = Path(self.user_data_dir) / "historical_results_template.csv"
        destination.write_bytes(template.read_bytes())
        self.root_view.ids.status.text = f"Plantilla creada en: {destination}"
        self._show_info("Plantilla CSV", f"Se creó la plantilla en el almacenamiento de la app:\n{destination}\n\nCompleta los resultados reales con su fuente y luego selecciónala con Importar históricos CSV.")

    def open_historical_import(self):
        """Abre el selector nativo Android cuando Plyer está disponible."""
        try:
            from plyer import filechooser
            filechooser.open_file(on_selection=self._on_historical_file_selected,
                                  filters=["*.csv"])
            self.root_view.ids.status.text = "Selecciona el CSV en el selector del dispositivo."
            return
        except Exception:
            # Fallback para escritorio/pruebas o dispositivos sin backend Plyer.
            pass
        from pathlib import Path
        layout = BoxLayout(orientation="vertical", padding=dp(8), spacing=dp(6))
        chooser = FileChooserListView(path="/storage/emulated/0/Download", filters=["*.csv"],
                                      dirselect=False, multiselect=False)
        layout.add_widget(Label(text="Selecciona un CSV UTF-8 con resultados históricos verificables.",
                                size_hint_y=None, height=dp(42)))
        layout.add_widget(chooser)
        buttons = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        import_btn = Button(text="Importar CSV")
        cancel_btn = Button(text="Cancelar")
        buttons.add_widget(import_btn); buttons.add_widget(cancel_btn)
        layout.add_widget(buttons)
        popup = Popup(title="Importar resultados históricos", content=layout, size_hint=(.96, .92))

        def do_import(*_):
            if not chooser.selection:
                self._show_error("Selecciona primero un archivo CSV.")
                return
            selected = Path(chooser.selection[0])
            try:
                if selected.suffix.lower() != ".csv":
                    raise ValueError("Solo se admiten archivos .csv")
                if selected.stat().st_size > 10 * 1024 * 1024:
                    raise ValueError("El CSV supera el límite de 10 MB")
                content = selected.read_bytes()
                result = self.historical_import_service.import_csv(content)
                popup.dismiss()
                message = (f"CSV procesado: {result['read']}\nInsertados: {result['inserted']}\n"
                           f"Duplicados omitidos: {result['duplicates']}")
                self.root_view.ids.status.text = message.replace("\n", " | ")
                self._show_info("Importación terminada", message)
            except Exception as exc:
                self._show_error(f"Importación cancelada: {exc}")

        import_btn.bind(on_release=do_import)
        cancel_btn.bind(on_release=lambda *_: popup.dismiss())
        popup.open()

    def _on_historical_file_selected(self, selection):
        """Procesa la ruta devuelta por el selector del sistema."""
        if not selection:
            self.root_view.ids.status.text = "Importación cancelada por el usuario."
            return
        from pathlib import Path
        try:
            selected = Path(selection[0])
            result = self.historical_import_service.import_file(selected)
            message = (f"CSV procesado: {result['read']}\nInsertados: {result['inserted']}\n"
                       f"Duplicados omitidos: {result['duplicates']}")
            self.root_view.ids.status.text = message.replace("\n", " | ")
            self._show_info("Importación terminada", message)
        except Exception as exc:
            self._show_error(f"Importación cancelada: {exc}")

    def create_data_backup(self):
        """Crea una copia íntegra en el espacio privado de la aplicación."""
        from pathlib import Path
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        destination = Path(self.user_data_dir) / f"predictor_backup_{stamp}.json"
        try:
            result = self.backup_service.export_file(destination)
            message = (f"Copia creada correctamente.\nRegistros incluidos: {result['records']}\n"
                       f"Archivo: {result['path']}\n\nLa copia queda en el almacenamiento privado de Predictor Deportivo. "
                       "Guárdala fuera del dispositivo antes de cambiar o desinstalar la aplicación.")
            self.root_view.ids.status.text = f"Copia creada: {result['records']} registros."
            self._show_info("Copia de seguridad", message)
        except Exception as exc:
            self._show_error(f"No se pudo crear la copia: {exc}")

    def open_backup_import(self):
        """Importa una copia JSON; conserva datos existentes y omite claves duplicadas."""
        try:
            from plyer import filechooser
            filechooser.open_file(on_selection=self._on_backup_file_selected, filters=["*.json"])
            self.root_view.ids.status.text = "Selecciona una copia JSON de Predictor Deportivo."
            return
        except Exception:
            pass
        chooser = FileChooserListView(path="/storage/emulated/0/Download", filters=["*.json"],
                                      dirselect=False, multiselect=False)
        layout = BoxLayout(orientation="vertical", padding=dp(8), spacing=dp(6))
        layout.add_widget(Label(text="La restauración agrega registros y omite identificadores que ya existan.",
                                size_hint_y=None, height=dp(48)))
        layout.add_widget(chooser)
        buttons = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        restore = Button(text="Restaurar")
        cancel = Button(text="Cancelar")
        buttons.add_widget(restore); buttons.add_widget(cancel); layout.add_widget(buttons)
        popup = Popup(title="Restaurar copia de seguridad", content=layout, size_hint=(.96, .92))
        def do_restore(*_):
            if not chooser.selection:
                self._show_error("Selecciona primero un archivo JSON.")
                return
            try:
                result = self.backup_service.import_file(chooser.selection[0])
                popup.dismiss()
                self._show_info("Restauración terminada",
                    f"Registros agregados: {result['total_inserted']}\n"
                    f"Registros omitidos por duplicados: {result['total_skipped']}\n\n"
                    "Los datos existentes no fueron reemplazados.")
                self.root_view.ids.status.text = f"Copia restaurada: {result['total_inserted']} registros nuevos."
                self.refresh_matches()
            except Exception as exc:
                self._show_error(f"No se pudo restaurar la copia: {exc}")
        restore.bind(on_release=do_restore)
        cancel.bind(on_release=lambda *_: popup.dismiss())
        popup.open()

    def _on_backup_file_selected(self, selection):
        if not selection:
            self.root_view.ids.status.text = "Restauración cancelada."
            return
        try:
            result = self.backup_service.import_file(selection[0])
            self.root_view.ids.status.text = f"Copia restaurada: {result['total_inserted']} registros nuevos."
            self._show_info("Restauración terminada",
                f"Registros agregados: {result['total_inserted']}\n"
                f"Registros omitidos por duplicados: {result['total_skipped']}\n\n"
                "Los datos existentes no fueron reemplazados.")
            self.refresh_matches()
        except Exception as exc:
            self._show_error(f"No se pudo restaurar la copia: {exc}")

    def show_historical_coverage(self):
        selected = self.root_view.ids.sport.text
        sport_map = {"Fútbol": "football", "Baloncesto": "basketball", "Béisbol": "baseball"}
        report = self.historical_quality_service.report(sport_map.get(selected))
        if not report["total_matches"]:
            self._show_info("Cobertura histórica", "Todavía no hay resultados históricos importados. La app no genera datos de ejemplo.")
            return
        lines = [f"Partidos históricos: {report['total_matches']}",
                 f"Equipos identificados: {report['total_teams']}",
                 f"Equipos con al menos 5 partidos: {report['ready_teams']}",
                 f"Equipos por debajo del mínimo: {report['teams_below_minimum']}", ""]
        for sport, item in sorted(report["sports"].items()):
            lines.append(f"{sport.upper()}: {item['matches']} partidos · {item['teams']} equipos")
            lines.append(f"Periodo: {item['from'][:10]} a {item['to'][:10]}")
            lines.append("Fuentes: " + ", ".join(item["sources"][:5]))
            for comp in report.get("competitions", {}).get(sport, [])[:8]:
                lines.append(f"  {comp['competition']}: {comp['matches']} partidos · {comp['teams']} equipos")
        lines.append("\nMUESTRA POR EQUIPO")
        for team in report["teams"][:30]:
            status = "LISTO" if team["ready"] else f"FALTAN {team['missing']}"
            lines.append(f"{team['sport']} · {team['team']}: {team['matches']} partidos · {status}")
        aliases = self.db.list_team_aliases(sport_map.get(selected))
        lines.append(f"\nAlias configurados: {len(aliases)}")
        content = BoxLayout(orientation="vertical", spacing=dp(6), padding=dp(8))
        label = Label(text="\n".join(lines), halign="left", valign="top", size_hint_y=None)
        label.bind(texture_size=lambda widget, size: setattr(widget, "height", size[1] + dp(16)))
        scroll = ScrollView(do_scroll_x=False)
        scroll.add_widget(label)
        content.add_widget(scroll)
        close = Button(text="Cerrar", size_hint_y=None, height=dp(42))
        content.add_widget(close)
        popup = Popup(title="Cobertura histórica", content=content, size_hint=(.94, .86))
        close.bind(on_release=lambda *_: popup.dismiss())
        popup.open()


    def show_historical_backtest(self):
        selected = self.root_view.ids.sport.text
        sport_map = {"Fútbol": "football", "Baloncesto": "basketball", "Béisbol": "baseball"}
        report = self.historical_backtest_service.evaluate(sport_map.get(selected))
        if not report["samples"]:
            exclusions = report["exclusions"]
            self._show_info("Evaluación histórica",
                "Todavía no hay suficientes pronósticos archivados antes del inicio y resultados finales inequívocos.\n\n"
                f"Sin resultado asociado: {exclusions['without_result']}\n"
                f"Sin proyección previa: {exclusions['without_pre_match_projection']}\n"
                f"Resultados ambiguos: {exclusions['ambiguous_result']}\n"
                f"Pronósticos inválidos: {exclusions['invalid_prediction']}\n\n"
                "La aplicación no genera predicciones retrospectivas para rellenar la muestra.")
            return
        lines = [f"Pronósticos evaluados: {report['samples']}",
                 "Método: última proyección guardada antes del inicio", ""]
        for sport, metrics in report["by_sport"].items():
            lines.append(sport.upper())
            lines.append(f"Muestra: {metrics['samples']}")
            lines.append(f"Brier: {metrics['brier_score']:.4f}" if metrics['brier_score'] is not None else "Brier: n/d")
            lines.append(f"Log loss: {metrics['log_loss']:.4f}" if metrics['log_loss'] is not None else "Log loss: n/d")
            lines.append(f"Exactitud: {metrics['accuracy']:.1%}" if metrics['accuracy'] is not None else "Exactitud: n/d")
            lines.append("")
        lines.append("EXCLUSIONES")
        for key, value in report["exclusions"].items():
            lines.append(f"{key}: {value}")
        lines.append("\nEstas métricas describen solo las predicciones archivadas disponibles; no demuestran rentabilidad ni capacidad predictiva futura.")
        self._show_info("Evaluación histórica", "\n".join(lines))

    def show_historical_integrity(self):
        selected = self.root_view.ids.sport.text
        sport_map = {"Fútbol": "football", "Baloncesto": "basketball", "Béisbol": "baseball"}
        report = self.historical_integrity_service.audit(sport_map.get(selected))
        lines = [
            f"Registros revisados: {report['total_records']}",
            f"Problemas temporales: {report['temporal_issue_count']}",
            f"Grupos de posibles duplicados: {len(report['possible_duplicate_groups'])}",
            f"Registros en esos grupos: {report['possible_duplicate_records']}",
            f"Registros sin fuente: {report['missing_source_records']}",
            "Cambios automáticos realizados: 0", "",
            "REGISTROS POR FUENTE"
        ]
        for source, count in report["sources"].items():
            lines.append(f"{source}: {count}")
        if report["temporal_issues"]:
            lines.append("\nALERTAS TEMPORALES (máximo 20)")
            for issue in report["temporal_issues"][:20]:
                lines.append(f"{issue['id']}: {issue['issue']}")
        if report["possible_duplicate_groups"]:
            lines.append("\nPOSIBLES DUPLICADOS (máximo 15 grupos)")
            for group in report["possible_duplicate_groups"][:15]:
                lines.append(f"{group['sport']} · {group.get('competition') or 'sin competición'}: {', '.join(group['ids'])}")
                lines.append("Fuentes: " + ", ".join(group["sources"]))
        lines.append("\nLas alertas son orientativas. No se borran ni fusionan partidos automáticamente.")
        self._show_info("Auditoría de históricos", "\n".join(lines))

    def open_team_alias_editor(self):
        layout = BoxLayout(orientation="vertical", padding=dp(10), spacing=dp(8))
        sport = Spinner(text="Fútbol", values=["Fútbol", "Baloncesto", "Béisbol"], size_hint_y=None, height=dp(44))
        alias = TextInput(hint_text="Nombre alternativo tal como aparece en el CSV", multiline=False, size_hint_y=None, height=dp(44))
        canonical = TextInput(hint_text="Nombre canónico que debe agruparlo", multiline=False, size_hint_y=None, height=dp(44))
        note = Label(text="Ejemplo: Man United → Manchester United. La app no deduce equivalencias automáticamente.", size_hint_y=None, height=dp(54))
        layout.add_widget(sport); layout.add_widget(alias); layout.add_widget(canonical); layout.add_widget(note)
        buttons = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        save = Button(text="Guardar equivalencia"); cancel = Button(text="Cancelar")
        buttons.add_widget(save); buttons.add_widget(cancel); layout.add_widget(buttons)
        popup = Popup(title="Unificar nombres de equipos", content=layout, size_hint=(.94, .55))
        def save_alias(*_):
            try:
                sport_code = {"Fútbol": "football", "Baloncesto": "basketball", "Béisbol": "baseball"}[sport.text]
                created = self.historical_quality_service.add_alias(sport_code, alias.text, canonical.text)
                popup.dismiss()
                self._show_info("Equivalencia guardada", "Se creó la equivalencia." if created else "La equivalencia ya existía.")
            except Exception as exc:
                self._show_error(str(exc))
        save.bind(on_release=save_alias); cancel.bind(on_release=lambda *_: popup.dismiss())
        popup.open()

    def _show_info(self, title, message):
        content = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(10))
        label = Label(text=message, halign="left", valign="middle")
        label.bind(size=lambda w, size: setattr(w, "text_size", size))
        content.add_widget(label)
        close = Button(text="Cerrar", size_hint_y=None, height=dp(42))
        content.add_widget(close)
        popup = Popup(title=title, content=content, size_hint=(.92, .55))
        close.bind(on_release=lambda *_: popup.dismiss())
        popup.open()

    def show_opportunities(self, match_id=None):
        selected = self.root_view.ids.sport.text
        sport_map = {"Fútbol": "football", "Baloncesto": "basketball", "Béisbol": "baseball"}
        try:
            rows = (self.opportunity_service.opportunities_for_match(match_id)
                    if match_id else self.opportunity_service.opportunities_today(sport=sport_map.get(selected)))
        except Exception as exc:
            self._show_error(f"No se pudo calcular el ranking EV: {exc}")
            return
        if not rows:
            message = ("No hay oportunidades EV+ verificables. Se necesita una proyección válida y cuotas h2h "
                       "de menos de 6 horas. No se muestran cuotas ni probabilidades inventadas.")
        else:
            lines = ["RANKING · EV POSITIVO · Kelly ¼", ""]
            for index, item in enumerate(rows, 1):
                match = self.db.get_match(item["match_id"])
                matchup = f"{match['home_name']} vs {match['away_name']}" if match else item["match_id"]
                lines.append(
                    f"{index}. {matchup}\n{item['selection']} · {item.get('bookmaker') or 'Casa no indicada'}\n"
                    f"Cuota {item['decimal_odds']:.2f} | P modelo {item['model_probability']:.1%} | "
                    f"P implícita {item['implied_probability']:.1%}\nEV {item['expected_value']:+.1%} | "
                    f"Kelly ¼ {item['kelly_fractional']:.1%} | cuota hace {item['age_minutes']:.0f} min"
                )
            message = "\n\n".join(lines)
        content = Label(text=message, halign="left", valign="top", size_hint_y=None)
        content.bind(texture_size=lambda widget, size: setattr(widget, "height", size[1] + dp(24)))
        scroll = ScrollView(do_scroll_x=False)
        scroll.add_widget(content)
        popup = Popup(title="Oportunidades de valor", content=scroll, size_hint=(.94, .82))
        popup.open()

    def show_risk_calculator(self):
        """Calculadora informativa con Kelly fraccionado y límite estricto del 1%."""
        layout = BoxLayout(orientation="vertical", padding=dp(12), spacing=dp(8))
        bankroll = TextInput(text="1000", hint_text="Banca disponible", multiline=False, input_filter="float", size_hint_y=None, height=dp(44))
        probability = TextInput(text="0.55", hint_text="Probabilidad estimada (0 a 1)", multiline=False, input_filter="float", size_hint_y=None, height=dp(44))
        odds = TextInput(text="2.00", hint_text="Cuota decimal", multiline=False, input_filter="float", size_hint_y=None, height=dp(44))
        result = Label(text="Introduce los datos para calcular el límite teórico.", halign="left", valign="middle")
        for widget in (bankroll, probability, odds, result):
            layout.add_widget(widget)
        buttons = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        calculate = Button(text="Calcular")
        close = Button(text="Cerrar")
        buttons.add_widget(calculate); buttons.add_widget(close); layout.add_widget(buttons)
        popup = Popup(title="Riesgo y gestión de banca", content=layout, size_hint=(.92, .62))

        def run_calculation(*_):
            try:
                data = calculate_stake(float(bankroll.text), float(probability.text), float(odds.text))
                if not data["eligible"]:
                    result.text = (f"EV: {data['expected_value']:.2%}\nSin ventaja matemática estimada: stake calculado = 0.")
                else:
                    result.text = (f"EV estimado: {data['expected_value']:.2%}\n"
                                   f"Kelly ¼: {data['kelly_fractional_pct']:.2%} de banca\n"
                                   f"Límite máximo (1%): {data['cap']:.2f}\n"
                                   f"Stake teórico limitado: {data['stake']:.2f}\n"
                                   "Es un cálculo hipotético, no una recomendación ni garantía.")
            except (TypeError, ValueError) as exc:
                result.text = f"Datos no válidos: {exc}"
        calculate.bind(on_release=run_calculation)
        close.bind(on_release=lambda *_: popup.dismiss())
        popup.open()

    def open_lineup_editor(self, match):
        """Formulario manual; deja claro que la comprobación de la fuente es del usuario."""
        sport = match["sport"]
        count = {"football": 11, "basketball": 5, "baseball": 9}[sport]
        layout = BoxLayout(orientation="vertical", padding=dp(10), spacing=dp(6))
        layout.add_widget(Label(
            text=f"{match['home_name']} vs {match['away_name']}\nIntroduce {count} titulares por equipo, uno por línea.",
            size_hint_y=None, height=dp(54)))
        home = TextInput(hint_text=f"Titulares {match['home_name']} (uno por línea)", multiline=True, size_hint_y=None, height=dp(118))
        away = TextInput(hint_text=f"Titulares {match['away_name']} (uno por línea)", multiline=True, size_hint_y=None, height=dp(118))
        source = TextInput(hint_text="URL de la fuente oficial (https://...)", multiline=False, size_hint_y=None, height=dp(44))
        layout.add_widget(home); layout.add_widget(away); layout.add_widget(source)
        extras = {}
        if sport == "baseball":
            extras["home_pitcher"] = TextInput(hint_text=f"Pitcher abridor · {match['home_name']}", multiline=False, size_hint_y=None, height=dp(42))
            extras["away_pitcher"] = TextInput(hint_text=f"Pitcher abridor · {match['away_name']}", multiline=False, size_hint_y=None, height=dp(42))
            layout.add_widget(extras["home_pitcher"]); layout.add_widget(extras["away_pitcher"])
        if sport == "basketball":
            extras["injury_source"] = TextInput(hint_text="URL del informe oficial de lesiones", multiline=False, size_hint_y=None, height=dp(42))
            extras["injury_date"] = TextInput(
                hint_text="Fecha/hora del informe ISO-8601 (ej. 2026-11-22T20:00:00+00:00)",
                text=datetime.now(timezone.utc).isoformat(), multiline=False, size_hint_y=None, height=dp(42))
            layout.add_widget(extras["injury_source"]); layout.add_widget(extras["injury_date"])
        attestation_row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(6))
        attested = CheckBox(size_hint_x=None, width=dp(42))
        attestation_row.add_widget(attested)
        attestation_row.add_widget(Label(text="Confirmo que revisé la alineación en la fuente oficial indicada.", halign="left"))
        layout.add_widget(attestation_row)
        buttons = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        save = Button(text="Validar y guardar")
        cancel = Button(text="Cancelar")
        buttons.add_widget(save); buttons.add_widget(cancel); layout.add_widget(buttons)
        popup = Popup(title="Registrar alineación oficial", content=layout, size_hint=(.96, .94))

        def save_record(*_):
            try:
                teams = {
                    "home": {"starters": [x.strip() for x in home.text.splitlines() if x.strip()]},
                    "away": {"starters": [x.strip() for x in away.text.splitlines() if x.strip()]},
                }
                if sport == "baseball":
                    teams["home"]["starting_pitcher"] = extras["home_pitcher"].text.strip()
                    teams["away"]["starting_pitcher"] = extras["away_pitcher"].text.strip()
                injury = None
                if sport == "basketball":
                    injury = {"source": extras["injury_source"].text.strip(),
                              "published_at": extras["injury_date"].text.strip()}
                self.lineup_service.save_user_confirmed_official(
                    match["id"], teams, source.text, injury_report=injury,
                    user_attested=bool(attested.active))
                popup.dismiss()
                self.root_view.ids.status.text = "Alineación guardada. La app validó estructura y fechas; la fuente fue declarada por el usuario."
            except Exception as exc:
                self._show_error(str(exc))
        save.bind(on_release=save_record)
        cancel.bind(on_release=lambda *_: popup.dismiss())
        popup.open()

    def project_match(self, match_id):
        match = self.db.get_match(match_id)
        if not match:
            return
        self.root_view.ids.status.text = "Validando datos y alineaciones oficiales..."
        try:
            self.service.project_async(
                match_id,
                int(self.root_view.ids.sims.text),
                on_success=lambda result: self._show_result(result),
                on_error=lambda error: self._show_error(error)
            )
        except Exception as exc:
            self._show_error(str(exc))

    def _show_result(self, result):
        self.root_view.ids.status.text = f"Proyección guardada: {result.get('summary', 'consulta el detalle del partido')}"

    def _show_error(self, error):
        self.root_view.ids.status.text = f"No se pudo proyectar: {error}"

    def on_stop(self):
        if hasattr(self, "service"):
            self.service.shutdown()
        if getattr(self, "_sync_thread", None) and self._sync_thread.is_alive():
            self._sync_thread.join(timeout=2)
        if getattr(self, "_odds_thread", None) and self._odds_thread.is_alive():
            self._odds_thread.join(timeout=2)
        if hasattr(self, "db"):
            self.db.close()

if __name__ == "__main__":
    PredictorApp().run()
