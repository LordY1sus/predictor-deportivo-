"""Cliente de fixtures/resultados de API-Sports para los tres deportes.

Usa únicamente GET y la cabecera oficial x-apisports-key. No persiste la clave.
La cobertura depende del plan, liga y temporada contratados.
"""
from datetime import datetime, timezone
from urllib.parse import urlencode
import json
import urllib.error
import urllib.request

API_ROOTS = {
    "football": "https://v3.football.api-sports.io",
    "basketball": "https://v1.basketball.api-sports.io",
    "baseball": "https://v1.baseball.api-sports.io",
}
ENDPOINTS = {sport: root + ("/fixtures" if sport == "football" else "/games")
             for sport, root in API_ROOTS.items()}
FINISHED = {
    "football": {"FT", "AET", "PEN"},
    "basketball": {"FT", "AOT"},
    "baseball": {"FT"},
}
LIVE = {
    "football": {"1H", "HT", "2H", "ET", "BT", "P", "LIVE"},
    "basketball": {"Q1", "Q2", "Q3", "Q4", "OT", "HT", "BT"},
    "baseball": {f"IN{i}" for i in range(1, 10)} | {"INNING", "LIVE"},
}
IGNORED = {"PST", "POST", "CANC", "SUSP", "ABD", "AWD", "WO", "TBD"}


class APISportsError(RuntimeError):
    pass


def _request_json(url, api_key, timeout=15):
    request = urllib.request.Request(url, headers={
        "x-apisports-key": api_key,
        "User-Agent": "PredictorDeportivo/0.20",
        "Accept": "application/json",
    })
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
            headers = {key.lower(): value for key, value in response.headers.items()}
            return payload, headers
    except (urllib.error.URLError, TimeoutError, ValueError) as exc:
        raise APISportsError(f"No se pudo consultar API-Sports: {exc}") from exc


def _extract(event, sport):
    if sport == "football":
        fixture = event.get("fixture") or {}
        teams = event.get("teams") or {}
        home = teams.get("home") or {}
        away = teams.get("away") or {}
        score = event.get("goals") or {}
        league = event.get("league") or {}
        metadata = {"home_id": home.get("id"), "away_id": away.get("id"),
                    "league_id": league.get("id"), "season": league.get("season")}
        return (fixture.get("id"), fixture.get("date"),
                (fixture.get("status") or {}).get("short"), home.get("name"), away.get("name"),
                score.get("home"), score.get("away"), league, metadata)
    game = event.get("game") or event
    teams = event.get("teams") or {}
    home = teams.get("home") or {}
    away = teams.get("away") or {}
    scores = event.get("scores") or {}
    home_score = scores.get("home") or {}
    away_score = scores.get("away") or {}
    league = event.get("league") or {}
    metadata = {"home_id": home.get("id"), "away_id": away.get("id"),
                "league_id": league.get("id"), "season": league.get("season")}
    return (game.get("id"), game.get("date"),
            (game.get("status") or {}).get("short"), home.get("name"), away.get("name"),
            home_score.get("total"), away_score.get("total"), league, metadata)


def parse_games(payload, sport, captured_at=None):
    if sport not in ENDPOINTS:
        raise APISportsError(f"Deporte no soportado: {sport}")
    errors = payload.get("errors")
    if errors:
        raise APISportsError(f"API-Sports devolvió errores: {errors}")
    response = payload.get("response")
    if not isinstance(response, list):
        raise APISportsError("La respuesta de API-Sports no contiene una lista de partidos")
    captured_at = captured_at or datetime.now(timezone.utc).isoformat()
    rows = []
    for event in response:
        try:
            event_id, date_text, short, home, away, hs, aws, league, metadata = _extract(event, sport)
            if not event_id or not date_text or not home or not away or not short:
                continue
            kickoff = datetime.fromisoformat(str(date_text).replace("Z", "+00:00"))
            if kickoff.tzinfo is None or kickoff.utcoffset() is None:
                continue
            kickoff = kickoff.astimezone(timezone.utc)
            if short in FINISHED[sport]:
                status = "FINISHED"
            elif short in LIVE[sport]:
                status = "LIVE"
            elif short in IGNORED:
                continue
            else:
                status = "SCHEDULED"
            local = kickoff.astimezone()
            league_name = league.get("name") if isinstance(league, dict) else None
            match = {
                "id": f"api_sports:{sport}:{event_id}", "sport": sport,
                "home_name": str(home), "away_name": str(away),
                "kickoff_utc": kickoff.isoformat(), "kickoff_local": local.isoformat(),
                "status": status,
                "payload": {"provider": "api_sports", "provider_event_id": str(event_id),
                            "league": league_name, "competition": league_name, "status_short": short,
                            "home_team_id": metadata.get("home_id"),
                            "away_team_id": metadata.get("away_id"),
                            "league_id": metadata.get("league_id"),
                            "season": metadata.get("season"),
                            "score": {"home": hs, "away": aws}},
            }
            result = None
            if status == "FINISHED" and hs is not None and aws is not None:
                try:
                    home_value, away_value = float(hs), float(aws)
                    if home_value >= 0 and away_value >= 0 and home_value.is_integer() and away_value.is_integer():
                        result = {
                            "id": match["id"], "sport": sport,
                            "home_name": str(home), "away_name": str(away),
                            "kickoff_utc": kickoff.isoformat(),
                            "home_score": int(home_value), "away_score": int(away_value),
                            "source": "api_sports", "captured_at": captured_at,
                            "competition": league_name or "",
                        }
                except (TypeError, ValueError):
                    pass
            rows.append({"match": match, "result": result})
        except (TypeError, ValueError, AttributeError):
            # Un registro mal formado no invalida los demás eventos del día.
            continue
    return rows


def fetch_day(sport, day, api_key, timeout=15, captured_at=None):
    if sport not in ENDPOINTS:
        raise APISportsError(f"Deporte no soportado: {sport}")
    api_key = (api_key or "").strip()
    if not api_key:
        raise APISportsError("Falta la clave API-Sports")
    if hasattr(day, "isoformat"):
        day = day.isoformat()
    try:
        parsed_day = datetime.strptime(str(day), "%Y-%m-%d").date()
    except ValueError as exc:
        raise APISportsError("La fecha debe tener formato AAAA-MM-DD") from exc
    url = ENDPOINTS[sport] + "?" + urlencode({"date": parsed_day.isoformat(), "timezone": "UTC"})
    payload, headers = _request_json(url, api_key, timeout=timeout)
    rows = parse_games(payload, sport, captured_at=captured_at)
    return {
        "events": rows,
        "quota": {
            "daily_limit": headers.get("x-ratelimit-requests-limit"),
            "daily_remaining": headers.get("x-ratelimit-requests-remaining"),
            "minute_remaining": headers.get("x-ratelimit-remaining"),
        },
    }


def fetch_status(sport, api_key, timeout=15):
    """Consulta el estado de cuenta; API-Sports indica que status no consume cuota diaria."""
    if sport not in API_ROOTS:
        raise APISportsError(f"Deporte no soportado: {sport}")
    api_key = (api_key or "").strip()
    if not api_key:
        raise APISportsError("Falta la clave API-Sports")
    payload, _headers = _request_json(API_ROOTS[sport] + "/status", api_key, timeout=timeout)
    if payload.get("errors"):
        raise APISportsError(f"API-Sports devolvió errores: {payload['errors']}")
    response = payload.get("response") or {}
    subscription = response.get("subscription") or {}
    requests = response.get("requests") or {}
    return {
        "plan": subscription.get("plan"),
        "active": subscription.get("active"),
        "subscription_end": subscription.get("end"),
        "requests_used": requests.get("current"),
        "daily_limit": requests.get("limit_day"),
        "daily_remaining": (max(0, int(requests["limit_day"]) - int(requests["current"]))
                            if requests.get("limit_day") is not None and requests.get("current") is not None else None),
    }


def _normalise_team_name(value):
    import re
    import unicodedata
    value = unicodedata.normalize("NFKD", str(value or "")).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]", "", value)


def parse_football_lineups(payload, home_name, away_name, captured_at=None):
    """Convierte la respuesta /fixtures/lineups en dos XI iniciales verificables.

    Solo declara status=official si ambos equipos están presentes y tienen
    exactamente once titulares identificados, sin duplicados.
    """
    if payload.get("errors"):
        raise APISportsError(f"API-Sports devolvió errores: {payload['errors']}")
    response = payload.get("response")
    if not isinstance(response, list) or len(response) < 2:
        raise APISportsError("API-Sports aún no proporciona las alineaciones de ambos equipos")
    expected = {
        _normalise_team_name(home_name): "home",
        _normalise_team_name(away_name): "away",
    }
    teams = {"home": None, "away": None}
    raw_teams = []
    for item in response:
        team = item.get("team") or {}
        side = expected.get(_normalise_team_name(team.get("name")))
        if side is None:
            continue
        starters = []
        for entry in item.get("startXI") or []:
            player = entry.get("player") or {}
            name = str(player.get("name") or "").strip()
            if name:
                starters.append(name)
        if len(starters) != 11 or len({name.casefold() for name in starters}) != 11:
            raise APISportsError(f"La alineación de {side} no contiene once titulares únicos")
        teams[side] = {
            "team_id": team.get("id"),
            "team_name": team.get("name"),
            "starters": starters,
            "substitutes": [str(((x.get("player") or {}).get("name") or "")).strip()
                            for x in (item.get("substitutes") or [])
                            if ((x.get("player") or {}).get("name"))],
            "formation": item.get("formation"),
            "coach": (item.get("coach") or {}).get("name"),
        }
        raw_teams.append(item)
    if not teams["home"] or not teams["away"]:
        raise APISportsError("No fue posible asociar ambas alineaciones con los equipos del partido")
    confirmed_at = captured_at or datetime.now(timezone.utc).isoformat()
    return {
        "status": "official",
        "source": "api_sports_official_lineups",
        "confirmed_at": confirmed_at,
        "teams": teams,
        "provider": "api_sports",
        "raw_team_count": len(raw_teams),
    }


def fetch_football_lineups(fixture_id, home_name, away_name, api_key, timeout=15, captured_at=None):
    api_key = (api_key or "").strip()
    if not api_key:
        raise APISportsError("Falta la clave API-Sports")
    if not str(fixture_id).isdigit():
        raise APISportsError("El identificador del partido API-Sports no es válido")
    url = API_ROOTS["football"] + "/fixtures/lineups?" + urlencode({"fixture": str(fixture_id)})
    payload, headers = _request_json(url, api_key, timeout=timeout)
    record = parse_football_lineups(payload, home_name, away_name, captured_at=captured_at)
    return {"lineup": record, "quota": {
        "daily_limit": headers.get("x-ratelimit-requests-limit"),
        "daily_remaining": headers.get("x-ratelimit-requests-remaining"),
    }}


def fetch_football_injuries(fixture_id, api_key, timeout=15, captured_at=None):
    """Consulta ausencias del fixture; captured_at es observación del proveedor, no publicación original."""
    api_key = (api_key or "").strip()
    if not api_key:
        raise APISportsError("Falta la clave API-Sports")
    if not str(fixture_id).isdigit():
        raise APISportsError("El identificador del partido API-Sports no es válido")
    url = API_ROOTS["football"] + "/injuries?" + urlencode({"fixture": str(fixture_id)})
    payload, headers = _request_json(url, api_key, timeout=timeout)
    if payload.get("errors"):
        raise APISportsError(f"API-Sports devolvió errores: {payload['errors']}")
    response = payload.get("response")
    if not isinstance(response, list):
        raise APISportsError("La respuesta de lesiones no contiene una lista")
    observed_at = captured_at or datetime.now(timezone.utc).isoformat()
    reports = []
    for item in response:
        team = item.get("team") or {}
        player = item.get("player") or {}
        fixture = item.get("fixture") or {}
        if not team.get("name") or not player.get("name"):
            continue
        reports.append({
            "fixture_id": str(fixture.get("id") or fixture_id),
            "team_name": str(team["name"]),
            "player_id": str(player.get("id") or ""),
            "player_name": str(player["name"]),
            "type": str(player.get("type") or "unknown"),
            "reason": str(player.get("reason") or ""),
            "provider_observed_at": observed_at,
            "source": "api_sports",
        })
    return {"reports": reports, "observed_at": observed_at, "quota": {
        "daily_limit": headers.get("x-ratelimit-requests-limit"),
        "daily_remaining": headers.get("x-ratelimit-requests-remaining"),
    }}


def fetch_football_team_statistics(team_id, league_id, season, cutoff_date, api_key, timeout=15, captured_at=None):
    """Obtiene agregados de temporada de un equipo hasta una fecha de corte."""
    api_key = (api_key or "").strip()
    if not api_key:
        raise APISportsError("Falta la clave API-Sports")
    if not all(str(v).isdigit() for v in (team_id, league_id, season)):
        raise APISportsError("Faltan IDs válidos de equipo, liga o temporada")
    try:
        cutoff = datetime.strptime(str(cutoff_date), "%Y-%m-%d").date()
    except ValueError as exc:
        raise APISportsError("La fecha de corte debe respetar AAAA-MM-DD") from exc
    params = {"team": str(team_id), "league": str(league_id),
              "season": str(season), "date": cutoff.isoformat()}
    url = API_ROOTS["football"] + "/teams/statistics?" + urlencode(params)
    payload, headers = _request_json(url, api_key, timeout=timeout)
    if payload.get("errors"):
        raise APISportsError(f"API-Sports devolvió errores: {payload['errors']}")
    response = payload.get("response")
    if not isinstance(response, dict) or not response:
        raise APISportsError("API-Football no devolvió estadísticas de equipo para esa liga/temporada")
    team = response.get("team") or {}
    league = response.get("league") or {}
    if team.get("id") is not None and str(team.get("id")) != str(team_id):
        raise APISportsError("La respuesta estadística corresponde a otro equipo")
    if league.get("id") is not None and str(league.get("id")) != str(league_id):
        raise APISportsError("La respuesta estadística corresponde a otra competición")
    return {"sport": "football", "team_id": str(team_id), "team_name": team.get("name"),
            "league_id": str(league_id), "competition": league.get("name"),
            "season": str(season), "valid_before": cutoff.isoformat(),
            "observed_at": captured_at or datetime.now(timezone.utc).isoformat(),
            "source": "api_football_teams_statistics", "statistics": response,
            "quota": {"daily_limit": headers.get("x-ratelimit-requests-limit"),
                      "daily_remaining": headers.get("x-ratelimit-requests-remaining")}}


def parse_football_player_statistics(payload, captured_at=None, kickoff_utc=None):
    """Normaliza una página de estadísticas de temporada de jugadores.

    API-Football no ofrece un corte histórico por fecha en este endpoint. Por eso
    cada respuesta se conserva como snapshot inmutable y solo se acepta si se
    capturó antes del kickoff objetivo. No sirve para reconstruir partidos pasados.
    """
    if payload.get("errors"):
        raise APISportsError(f"API-Sports devolvió errores: {payload['errors']}")
    response = payload.get("response")
    if not isinstance(response, list):
        raise APISportsError("La respuesta de jugadores no contiene una lista")
    captured_at = captured_at or datetime.now(timezone.utc).isoformat()
    captured = datetime.fromisoformat(str(captured_at).replace("Z", "+00:00"))
    if captured.tzinfo is None:
        raise APISportsError("captured_at debe incluir zona horaria")
    if kickoff_utc:
        kickoff = datetime.fromisoformat(str(kickoff_utc).replace("Z", "+00:00"))
        if kickoff.tzinfo is None or captured >= kickoff:
            raise APISportsError("El snapshot de jugadores debe capturarse antes del kickoff")
    records = []
    for item in response:
        player = item.get("player") or {}
        stats_rows = item.get("statistics") or []
        if not player.get("id") or not player.get("name") or not stats_rows:
            continue
        for stats in stats_rows:
            team = stats.get("team") or {}
            records.append({
                "id": str(player["id"]), "player_id": str(player["id"]),
                "player_name": str(player["name"]),
                "team_id": str(team.get("id") or ""),
                "team_name": str(team.get("name") or ""),
                "position": str((stats.get("games") or {}).get("position") or ""),
                "observed_at": captured.astimezone(timezone.utc).isoformat(),
                "source": "api_football_players_snapshot",
                "stats": stats,
            })
    return records


def fetch_football_player_statistics(team_id, league_id, season, api_key, page=1,
                                     kickoff_utc=None, timeout=15, captured_at=None):
    """Obtiene una página (20 jugadores) de estadísticas de temporada pre-partido."""
    api_key = (api_key or "").strip()
    if not api_key:
        raise APISportsError("Falta la clave API-Sports")
    if not str(team_id).isdigit() or not str(league_id).isdigit():
        raise APISportsError("team_id y league_id deben ser numéricos")
    try:
        season_value = int(season)
        page_value = int(page)
    except (TypeError, ValueError) as exc:
        raise APISportsError("season y page deben ser números") from exc
    if not 1900 <= season_value <= 2200 or page_value < 1:
        raise APISportsError("season o page fuera de rango")
    captured_at = captured_at or datetime.now(timezone.utc).isoformat()
    if kickoff_utc:
        captured = datetime.fromisoformat(str(captured_at).replace("Z", "+00:00"))
        kickoff = datetime.fromisoformat(str(kickoff_utc).replace("Z", "+00:00"))
        if captured.tzinfo is None or kickoff.tzinfo is None or captured >= kickoff:
            raise APISportsError("No se pueden usar estadísticas capturadas después del inicio")
    query = urlencode({"team": str(team_id), "league": str(league_id),
                       "season": season_value, "page": page_value})
    payload, headers = _request_json(API_ROOTS["football"] + "/players?" + query,
                                     api_key, timeout=timeout)
    records = parse_football_player_statistics(payload, captured_at, kickoff_utc)
    return {"players": records, "page": page_value,
            "results": payload.get("results"), "paging": payload.get("paging") or {},
            "quota": {"daily_limit": headers.get("x-ratelimit-requests-limit"),
                      "daily_remaining": headers.get("x-ratelimit-requests-remaining"),
                      "minute_remaining": headers.get("x-ratelimit-remaining")}}


def fetch_team_statistics_snapshot(sport, team_id, league_id, season, cutoff_date, api_key, timeout=15, captured_at=None):
    """Obtiene estadísticas de equipo con corte explícito para basket/baseball.

    La fecha se fija como máximo al día anterior al partido en el servicio llamador.
    """
    if sport not in ("basketball", "baseball"):
        raise APISportsError("Este método está reservado para basketball y baseball")
    api_key = (api_key or "").strip()
    if not api_key:
        raise APISportsError("Falta la clave API-Sports")
    if not all(str(v).isdigit() for v in (team_id, league_id, season)):
        raise APISportsError("Faltan IDs válidos de equipo, liga o temporada")
    try:
        cutoff = datetime.strptime(str(cutoff_date), "%Y-%m-%d").date()
    except ValueError as exc:
        raise APISportsError("La fecha de corte debe respetar AAAA-MM-DD") from exc
    endpoint = "/statistics" if sport == "basketball" else "/teams/statistics"
    params = {"team": str(team_id), "league": str(league_id),
              "season": str(season), "date": cutoff.isoformat()}
    url = API_ROOTS[sport] + endpoint + "?" + urlencode(params)
    payload, headers = _request_json(url, api_key, timeout=timeout)
    if payload.get("errors"):
        raise APISportsError(f"API-Sports devolvió errores: {payload['errors']}")
    response = payload.get("response")
    if not isinstance(response, dict) or not response:
        raise APISportsError(f"API-Sports no devolvió estadísticas de {sport} para ese corte")
    team = response.get("team") or {}
    league = response.get("league") or {}
    if team.get("id") is not None and str(team.get("id")) != str(team_id):
        raise APISportsError("La respuesta estadística corresponde a otro equipo")
    if league.get("id") is not None and str(league.get("id")) != str(league_id):
        raise APISportsError("La respuesta estadística corresponde a otra competición")
    return {"sport": sport, "team_id": str(team_id), "team_name": team.get("name"),
            "league_id": str(league_id), "competition": league.get("name"),
            "season": str(season), "valid_before": cutoff.isoformat(),
            "observed_at": captured_at or datetime.now(timezone.utc).isoformat(),
            "source": f"api_sports_{sport}_team_statistics", "statistics": response,
            "quota": {"daily_limit": headers.get("x-ratelimit-requests-limit"),
                      "daily_remaining": headers.get("x-ratelimit-requests-remaining")}}
