"""Adaptador The Odds API v4. Requiere una clave aportada por el usuario."""
import json
import urllib.parse
import urllib.request
import urllib.error
from datetime import datetime, timezone
from .espn_scoreboard import ProviderError

SPORT_KEYS = {"football": "soccer_epl", "basketball": "basketball_nba", "baseball": "baseball_mlb"}

def fetch_odds(sport, api_key, regions="us", markets="h2h,totals", timeout=12):
    if not api_key or not api_key.strip():
        raise ProviderError("Configura una clave de The Odds API para consultar cuotas.")
    if sport not in SPORT_KEYS:
        raise ProviderError("Deporte no soportado para cuotas.")
    params = urllib.parse.urlencode({
        "apiKey": api_key.strip(), "regions": regions, "markets": markets,
        "oddsFormat": "decimal", "dateFormat": "iso"
    })
    url = f"https://api.the-odds-api.com/v4/sports/{SPORT_KEYS[sport]}/odds/?{params}"
    req = urllib.request.Request(url, headers={"User-Agent": "PredictorDeportivo/0.3"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, ValueError) as exc:
        raise ProviderError(f"No se pudieron consultar las cuotas: {exc}") from exc
    result = []
    for event in payload:
        commence = event.get("commence_time")
        if not commence:
            continue
        for bookmaker in event.get("bookmakers", []):
            for market in bookmaker.get("markets", []):
                for outcome in market.get("outcomes", []):
                    price = outcome.get("price")
                    if isinstance(price, (int, float)) and price > 1:
                        result.append({
                            "provider_event_id": event.get("id"),
                            "home_name": event.get("home_team"),
                            "away_name": event.get("away_team"),
                            "kickoff_utc": datetime.fromisoformat(commence.replace("Z","+00:00")).astimezone(timezone.utc).isoformat(),
                            "market": market.get("key"),
                            "selection": outcome.get("name"),
                            "line": outcome.get("point"),
                            "decimal_odds": float(price),
                            "bookmaker": bookmaker.get("key")
                        })
    return result
