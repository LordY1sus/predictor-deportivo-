"""Adaptador de marcadores ESPN. La API es pública, pero no constituye un SLA oficial."""
from datetime import datetime, timezone
from urllib.parse import urlencode
import json
import urllib.request
import urllib.error

ENDPOINTS = {
    "basketball": "https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard",
    "baseball": "https://site.api.espn.com/apis/site/v2/sports/baseball/mlb/scoreboard",
    # Este identificador cubre Premier League, no todo el fútbol mundial.
    "football": "https://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/scoreboard",
}

class ProviderError(RuntimeError):
    pass

def _fetch_json(url, timeout=12):
    req = urllib.request.Request(url, headers={"User-Agent": "PredictorDeportivo/0.3"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, ValueError) as exc:
        raise ProviderError(f"No se pudo consultar el proveedor de partidos: {exc}") from exc

def parse_scoreboard(payload, sport, local_tz=None):
    events = []
    for event in payload.get("events", []):
        competitions = event.get("competitions") or []
        if not competitions:
            continue
        competition = competitions[0]
        competitors = competition.get("competitors") or []
        home = next((x for x in competitors if x.get("homeAway") == "home"), None)
        away = next((x for x in competitors if x.get("homeAway") == "away"), None)
        if not home or not away:
            continue
        kickoff = datetime.fromisoformat(event["date"].replace("Z", "+00:00"))
        if kickoff.tzinfo is None:
            kickoff = kickoff.replace(tzinfo=timezone.utc)
        local = kickoff.astimezone(local_tz) if local_tz else kickoff.astimezone()
        status_type = (event.get("status") or {}).get("type") or {}
        state = status_type.get("state", "pre")
        completed = bool(status_type.get("completed"))
        status = "FINISHED" if completed else ("LIVE" if state == "in" else "SCHEDULED")
        events.append({
            "id": f"espn:{sport}:{event['id']}",
            "sport": sport,
            "home_name": home.get("team", {}).get("displayName", "Unknown"),
            "away_name": away.get("team", {}).get("displayName", "Unknown"),
            "kickoff_utc": kickoff.astimezone(timezone.utc).isoformat(),
            "kickoff_local": local.isoformat(),
            "status": status,
            "payload": {"provider": "espn", "provider_event_id": str(event["id"]),
                        "league": competition.get("name") or ((competition.get("competitions") or [{}])[0].get("name")
                                  if competition.get("competitions") else None),
                        "score": {"home": home.get("score"), "away": away.get("score")}}
        })
    return events

def fetch_today(sport, local_tz=None):
    if sport not in ENDPOINTS:
        raise ProviderError(f"Deporte no soportado: {sport}")
    return parse_scoreboard(_fetch_json(ENDPOINTS[sport]), sport, local_tz)


def fetch_historical_day(sport, day, captured_at=None):
    """Descarga los resultados FINALIZADOS de un día concreto desde ESPN.

    Cobertura limitada a NBA, MLB y Premier League según ENDPOINTS. No se
    interpreta un evento sin marcador numérico como resultado histórico.
    """
    if sport not in ENDPOINTS:
        raise ProviderError(f"Deporte no soportado: {sport}")
    if not isinstance(day, datetime):
        from datetime import date
        if isinstance(day, date):
            day = datetime(day.year, day.month, day.day, tzinfo=timezone.utc)
        else:
            raise ProviderError("day debe ser datetime o date")
    day_key = day.strftime("%Y%m%d")
    separator = "&" if "?" in ENDPOINTS[sport] else "?"
    payload = _fetch_json(f"{ENDPOINTS[sport]}{separator}dates={day_key}")
    events = parse_scoreboard(payload, sport)
    captured = captured_at or datetime.now(timezone.utc).isoformat()
    records = []
    for event in events:
        if event["status"] != "FINISHED":
            continue
        score = event.get("payload", {}).get("score", {})
        try:
            home_score = float(score.get("home"))
            away_score = float(score.get("away"))
        except (TypeError, ValueError):
            continue
        if home_score < 0 or away_score < 0 or not home_score.is_integer() or not away_score.is_integer():
            continue
        records.append({
            "id": event["id"], "sport": sport,
            "home_name": event["home_name"], "away_name": event["away_name"],
            "kickoff_utc": event["kickoff_utc"],
            "home_score": int(home_score), "away_score": int(away_score),
            "source": "espn_scoreboard", "captured_at": captured,
            "competition": event.get("payload", {}).get("league") or "",
        })
    return records
