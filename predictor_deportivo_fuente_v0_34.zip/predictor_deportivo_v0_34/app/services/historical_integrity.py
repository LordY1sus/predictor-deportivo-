"""Auditoría de integridad temporal y posibles duplicados del histórico.

No elimina ni fusiona registros automáticamente: las coincidencias son alertas
para revisión humana porque dos fuentes pueden describir el mismo evento.
"""
from collections import Counter, defaultdict
from datetime import datetime, timezone


class HistoricalIntegrityService:
    def __init__(self, db, duplicate_window_minutes=180):
        self.db = db
        self.duplicate_window_minutes = max(1, int(duplicate_window_minutes))

    @staticmethod
    def _parse(value):
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if dt.tzinfo is None or dt.utcoffset() is None:
            raise ValueError("timestamp sin zona horaria")
        return dt.astimezone(timezone.utc)

    def audit(self, sport=None, now=None):
        now = now or datetime.now(timezone.utc)
        if now.tzinfo is None:
            raise ValueError("now debe incluir zona horaria")
        with self.db.lock:
            sql = "SELECT * FROM historical_results"
            args = []
            if sport:
                sql += " WHERE sport=?"
                args.append(sport)
            rows = [dict(r) for r in self.db.conn.execute(sql, args).fetchall()]
            aliases = [dict(r) for r in self.db.conn.execute(
                "SELECT sport,alias_name,canonical_name FROM team_aliases").fetchall()]

        alias_map = {(a["sport"], self.db._norm_team(a["alias_name"])): a["canonical_name"]
                     for a in aliases}

        def canonical(sp, name):
            return alias_map.get((sp, self.db._norm_team(name)), name.strip())

        source_counts = Counter()
        temporal_issues = []
        groups = defaultdict(list)
        for row in rows:
            source = (row.get("source") or "").strip()
            source_counts[source or "(sin fuente)"] += 1
            try:
                kickoff = self._parse(row["kickoff_utc"])
                captured = self._parse(row["captured_at"])
                if kickoff > now:
                    temporal_issues.append({"id": row["id"], "issue": "kickoff_futuro"})
                if captured < kickoff:
                    temporal_issues.append({"id": row["id"], "issue": "captura_anterior_al_inicio"})
                if captured > now:
                    temporal_issues.append({"id": row["id"], "issue": "captura_futura"})
                key = (row["sport"], (row.get("competition") or "").strip().casefold(),
                       self.db._norm_team(canonical(row["sport"], row["home_name"])),
                       self.db._norm_team(canonical(row["sport"], row["away_name"])))
                groups[key].append((kickoff, row["id"], source))
            except (ValueError, TypeError, KeyError):
                temporal_issues.append({"id": row.get("id", "?"), "issue": "fecha_invalida"})

        duplicate_groups = []
        window = self.duplicate_window_minutes * 60
        for key, items in groups.items():
            items.sort(key=lambda x: x[0])
            cluster = []
            for item in items:
                if cluster and (item[0] - cluster[0][0]).total_seconds() > window:
                    if len(cluster) > 1:
                        duplicate_groups.append(self._duplicate_summary(key, cluster))
                    cluster = []
                cluster.append(item)
            if len(cluster) > 1:
                duplicate_groups.append(self._duplicate_summary(key, cluster))

        return {
            "total_records": len(rows),
            "sources": dict(sorted(source_counts.items())),
            "missing_source_records": source_counts.get("(sin fuente)", 0),
            "temporal_issue_count": len(temporal_issues),
            "temporal_issues": temporal_issues,
            "possible_duplicate_groups": duplicate_groups,
            "possible_duplicate_records": sum(len(g["ids"]) for g in duplicate_groups),
            "duplicate_window_minutes": self.duplicate_window_minutes,
            "automatic_changes": 0,
        }

    @staticmethod
    def _duplicate_summary(key, cluster):
        return {
            "sport": key[0],
            "competition": key[1],
            "ids": [item[1] for item in cluster],
            "sources": sorted({item[2] or "(sin fuente)" for item in cluster}),
            "kickoff_range": [cluster[0][0].isoformat(), cluster[-1][0].isoformat()],
        }
