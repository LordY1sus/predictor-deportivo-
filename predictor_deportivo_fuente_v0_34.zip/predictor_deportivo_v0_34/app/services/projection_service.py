import threading
import secrets
from datetime import datetime, timezone
from kivy.clock import Clock
from app.engines import project_match
from app.services.lineup_validator import validate_lineup
from app.services.pre_match_validator import validate_pre_match_payload
from app.services.historical_expectations import HistoricalExpectationService
from app.services.team_statistics_expectations import TeamStatisticsExpectationService
from app.services.player_statistics import PlayerStatisticsSnapshotService
from app.services.multisport_statistics_context import MultiSportStatisticsContextService

class ProjectionService:
    def __init__(self, db):
        self.db=db
        self.lock=threading.Lock()
        self.workers={}

    def project_async(self, match_id, simulations, on_success, on_error):
        with self.lock:
            if match_id in self.workers and self.workers[match_id].is_alive():
                raise RuntimeError("Este partido ya se está proyectando")
            thread=threading.Thread(target=self._run,args=(match_id,simulations,on_success,on_error),daemon=True)
            self.workers[match_id]=thread
            thread.start()

    def _run(self, match_id, simulations, on_success, on_error):
        try:
            match=self.db.get_match(match_id)
            if not match or match["status"] != "SCHEDULED":
                raise ValueError("Solo se proyectan partidos programados")
            lineup=self.db.get_lineup(match_id)
            validate_lineup(match["sport"],lineup,match["kickoff_utc"])
            payload=__import__("json").loads(match["payload_json"])
            # Prioriza métricas explícitas válidas del proveedor. Si no existen,
            # construye una base transparente desde resultados históricos previos.
            try:
                validate_pre_match_payload(match,payload,lineup)
            except ValueError:
                payload=HistoricalExpectationService(self.db).build_payload(match)
            # Agrega tasas oficiales de temporada por sede cuando existen para
            # ambos equipos. Si falta una fuente válida, mantiene el baseline.
            payload=TeamStatisticsExpectationService(self.db).apply(match,payload)
            validate_pre_match_payload(match,payload,lineup)
            seed = secrets.randbelow(2**31)
            result=project_match(match["sport"],payload,simulations,seed=seed)
            player_snapshot = (PlayerStatisticsSnapshotService(self.db).lineup_snapshot(lineup, match["kickoff_utc"])
                               if match["sport"] == "football" else {})
            multisport_snapshot = (MultiSportStatisticsContextService(self.db).snapshot_for_match(match)
                                   if match["sport"] in ("basketball", "baseball") else {})
            snapshot = {
                "sport": match["sport"],
                "match_id": match_id,
                "kickoff_utc": match["kickoff_utc"],
                "generated_input_at": datetime.now(timezone.utc).isoformat(),
                "payload": payload,
                "lineup": lineup,
                "player_statistics_snapshot": player_snapshot,
                "multisport_team_statistics_snapshot": multisport_snapshot,
            }
            self.db.save_projection(match_id,simulations,result,input_snapshot=snapshot,
                                    model_version="advanced_models_v1",seed=seed)
            Clock.schedule_once(lambda *_: on_success(result),0)
        except Exception as exc:
            message = str(exc)
            Clock.schedule_once(lambda *_: on_error(message),0)
        finally:
            with self.lock:
                self.workers.pop(match_id,None)

    def shutdown(self):
        with self.lock:
            workers=list(self.workers.values())
        for worker in workers:
            worker.join(timeout=2)
