"""Portable, versioned JSON backup for the local sports-prediction database."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class BackupService:
    FORMAT = "predictor-deportivo-backup"
    VERSION = 1
    MAX_IMPORT_BYTES = 25 * 1024 * 1024
    # Parent tables precede dependent tables so foreign-key checks remain active.
    TABLES = (
        "matches", "historical_results", "team_aliases", "provider_sync_log",
        "player_observations", "lineups", "odds", "projections",
        "availability_reports", "injury_observations", "team_stat_observations",
    )

    def __init__(self, database):
        self.db = database

    def export_file(self, path: str | Path) -> dict[str, Any]:
        destination = Path(path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        with self.db.lock:
            tables: dict[str, list[dict[str, Any]]] = {}
            for table in self.TABLES:
                rows = self.db.conn.execute(f'SELECT * FROM "{table}"').fetchall()
                tables[table] = [dict(row) for row in rows]
        document = {
            "format": self.FORMAT,
            "format_version": self.VERSION,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "tables": tables,
        }
        temporary = destination.with_suffix(destination.suffix + ".tmp")
        try:
            temporary.write_text(json.dumps(document, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
            temporary.replace(destination)
        finally:
            if temporary.exists():
                temporary.unlink()
        return {"path": str(destination), "records": sum(map(len, tables.values())),
                "tables": {name: len(rows) for name, rows in tables.items()}}

    def import_file(self, path: str | Path) -> dict[str, Any]:
        source = Path(path)
        if not source.is_file():
            raise ValueError("No se encontró el archivo de copia de seguridad")
        if source.stat().st_size > self.MAX_IMPORT_BYTES:
            raise ValueError("La copia supera el límite de 25 MB")
        try:
            document = json.loads(source.read_text(encoding="utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("El archivo no contiene una copia JSON válida") from exc
        if not isinstance(document, dict) or document.get("format") != self.FORMAT:
            raise ValueError("El archivo no pertenece a Predictor Deportivo")
        if document.get("format_version") != self.VERSION:
            raise ValueError("Versión de copia no compatible")
        tables = document.get("tables")
        if not isinstance(tables, dict) or set(tables) - set(self.TABLES):
            raise ValueError("La copia contiene tablas desconocidas o una estructura inválida")

        inserted: dict[str, int] = {}
        skipped: dict[str, int] = {}
        with self.db.lock:
            conn = self.db.conn
            schemas = {}
            for table in self.TABLES:
                schemas[table] = {row["name"] for row in conn.execute(f'PRAGMA table_info("{table}")')}
            conn.execute("BEGIN IMMEDIATE")
            try:
                for table in self.TABLES:
                    rows = tables.get(table, [])
                    if not isinstance(rows, list):
                        raise ValueError(f"La tabla {table} tiene un formato inválido")
                    inserted[table] = skipped[table] = 0
                    columns = schemas[table]
                    for row in rows:
                        if not isinstance(row, dict) or not row or set(row) - columns:
                            raise ValueError(f"Hay un registro inválido en {table}")
                        names = list(row)
                        quoted = ",".join('"' + name + '"' for name in names)
                        placeholders = ",".join("?" for _ in names)
                        cursor = conn.execute(
                            f'INSERT OR IGNORE INTO "{table}" ({quoted}) VALUES ({placeholders})',
                            [row[name] for name in names],
                        )
                        if cursor.rowcount == 1:
                            inserted[table] += 1
                        else:
                            skipped[table] += 1
                conn.commit()
            except Exception:
                conn.rollback()
                raise
        return {"inserted": inserted, "skipped": skipped,
                "total_inserted": sum(inserted.values()), "total_skipped": sum(skipped.values())}
