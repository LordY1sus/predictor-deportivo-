"""Ajuste de expectativas de fútbol con agregados oficiales pre-partido.

Solo usa estadísticas de ambos equipos, misma competición/temporada y fecha de
validez anterior al kickoff. Si falta algún agregado, conserva la estimación base.
"""
from datetime import datetime, timezone
import json


def _number(value):
    try:
        number = float(value)
        return number if number >= 0 else None
    except (TypeError, ValueError):
        return None


def _venue_rates(record, venue):
    stats = record.get("statistics") or {}
    goals = stats.get("goals") or {}
    fixtures = stats.get("fixtures") or {}
    played = ((fixtures.get("played") or {}).get(venue))
    played = _number(played)
    scored = _number((((goals.get("for") or {}).get("total") or {}).get(venue)))
    conceded = _number((((goals.get("against") or {}).get("total") or {}).get(venue)))
    if not played or played <= 0 or scored is None or conceded is None:
        return None
    return scored / played, conceded / played


class TeamStatisticsExpectationService:
    """Combina el proxy histórico y los rates oficiales con peso conservador."""
    def __init__(self, db, official_weight=0.65):
        self.db = db
        self.official_weight = min(0.8, max(0.0, float(official_weight)))

    def apply(self, match, payload):
        if match.get("sport") != "football":
            return payload
        try:
            meta = json.loads(match.get("payload_json") or "{}")
        except (TypeError, ValueError):
            meta = match.get("payload") or {}
        ids = (meta.get("home_team_id"), meta.get("away_team_id"))
        league_id, season = meta.get("league_id"), meta.get("season")
        if not all(value is not None for value in (*ids, league_id, season)):
            return payload
        kickoff = datetime.fromisoformat(match["kickoff_utc"].replace("Z", "+00:00"))
        if kickoff.tzinfo is None:
            return payload
        home = self.db.get_team_stat_observation("football", ids[0], league_id, season, kickoff.isoformat())
        away = self.db.get_team_stat_observation("football", ids[1], league_id, season, kickoff.isoformat())
        if not home or not away:
            return payload
        # Evita usar agregados capturados después del comienzo, incluso si una
        # base de datos externa devolviera un registro temporalmente inválido.
        for record in (home, away):
            observed = datetime.fromisoformat(record["observed_at"].replace("Z", "+00:00"))
            valid = datetime.strptime(record["valid_before"], "%Y-%m-%d").date()
            if observed.tzinfo is None or observed >= kickoff or valid >= kickoff.date():
                return payload
        home_rates = _venue_rates(home, "home")
        away_rates = _venue_rates(away, "away")
        if not home_rates or not away_rates:
            return payload
        official_home = (home_rates[0] + away_rates[1]) / 2
        official_away = (away_rates[0] + home_rates[1]) / 2
        weight = self.official_weight
        for side, official in (("home", official_home), ("away", official_away)):
            historical = _number((payload.get(side) or {}).get("expected_goals"))
            if historical is None or historical <= 0:
                return payload
            payload[side]["expected_goals"] = max(0.05, (1-weight)*historical + weight*official)
        observations = payload.setdefault("observations", [])
        for record in (home, away):
            stamp = record["observed_at"]
            if not any(item.get("observed_at") == stamp for item in observations):
                observations.append({"observed_at": stamp, "source": record.get("source", "api_football_teams_statistics")})
        payload["team_statistics_adjustment"] = {
            "method": "venue_specific_goals_rates_blend",
            "official_weight": weight,
            "home_scoring_rate": home_rates[0], "home_conceding_rate": home_rates[1],
            "away_scoring_rate": away_rates[0], "away_conceding_rate": away_rates[1],
            "source": "api_football_teams_statistics",
        }
        return payload
