"""Captura y consulta snapshots de rendimiento individual sin fuga temporal."""
from datetime import datetime, timezone
from app.providers.api_sports import fetch_football_player_statistics


class PlayerStatisticsSnapshotService:
    def __init__(self, db):
        self.db = db

    def capture_football_team(self, team_id, league_id, season, api_key, kickoff_utc,
                             page=1, captured_at=None):
        captured_at = captured_at or datetime.now(timezone.utc).isoformat()
        result = fetch_football_player_statistics(
            team_id, league_id, season, api_key, page=page,
            kickoff_utc=kickoff_utc, captured_at=captured_at)
        for player in result["players"]:
            self.db.save_player_observation({
                "id": f"api_football:{player['player_id']}:{player['team_id']}:{player['observed_at']}",
                "sport": "football", "player_id": player["player_id"],
                "team_name": player["team_name"], "observed_at": player["observed_at"],
                "source": player["source"], "stats": {
                    "player_name": player["player_name"], "team_id": player["team_id"],
                    "position": player["position"], "season_stats": player["stats"],
                    "snapshot_scope": {"league_id": str(league_id), "season": str(season),
                                       "team_id": str(team_id), "page": page}}})
        return result

    def lineup_snapshot(self, lineup, kickoff_utc, limit=1):
        """Devuelve observaciones previas para titulares; nunca rellena con datos futuros."""
        kickoff = datetime.fromisoformat(kickoff_utc.replace("Z", "+00:00"))
        if kickoff.tzinfo is None:
            raise ValueError("kickoff debe incluir zona horaria")
        captured = {}
        for side in ("home", "away"):
            team = (lineup or {}).get("teams", {}).get(side, {})
            for name in team.get("starters", []):
                rows = self.db.player_observations_for_name_before("football", str(name), kickoff_utc, limit)
                safe = []
                for row in rows:
                    observed = datetime.fromisoformat(row["observed_at"].replace("Z", "+00:00"))
                    if observed.tzinfo is not None and observed < kickoff:
                        safe.append(row)
                captured[f"{side}:{name}"] = safe
        return captured
