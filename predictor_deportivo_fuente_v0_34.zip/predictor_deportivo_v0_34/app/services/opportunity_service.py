from app.analytics.opportunity_builder import build_opportunities

class OpportunityService:
    def __init__(self, db):
        self.db = db

    def opportunities_for_match(self, match_id, **kwargs):
        match = self.db.get_match(match_id)
        projection = self.db.get_latest_projection(match_id)
        if not match or not projection or match["status"] != "SCHEDULED":
            return []
        return build_opportunities(match, projection, self.db.latest_odds(match_id), **kwargs)

    def opportunities_today(self, sport=None, **kwargs):
        ranked = []
        for match in self.db.get_matches_with_latest_projection(sport=sport):
            ranked.extend(self.opportunities_for_match(match["id"], **kwargs))
        return sorted(ranked, key=lambda x: (x["expected_value"], x["kelly_fractional"]), reverse=True)
