"""Forma reciente calculada exclusivamente con resultados anteriores al kickoff."""
from datetime import datetime

def summarize_team_form(results, team_name, sport, cutoff_utc, window=10):
    cutoff=datetime.fromisoformat(cutoff_utc.replace("Z","+00:00"))
    selected=[]
    for row in results:
        if row.get("sport") != sport or team_name not in (row.get("home_name"),row.get("away_name")):
            continue
        dt=datetime.fromisoformat(row["kickoff_utc"].replace("Z","+00:00"))
        if dt.tzinfo is None or cutoff.tzinfo is None:
            raise ValueError("Las fechas históricas deben incluir zona horaria")
        if dt < cutoff:
            selected.append((dt,row))
    selected.sort(key=lambda x:x[0],reverse=True)
    selected=selected[:window]
    if not selected:
        return {"games":0,"win_rate":None,"draw_rate":None,"loss_rate":None,
                "scoring_average":None,"conceded_average":None}
    wins=draws=losses=0
    scored=conceded=0.0
    for _,r in selected:
        home=r["home_name"]==team_name
        own=float(r["home_score"] if home else r["away_score"])
        opp=float(r["away_score"] if home else r["home_score"])
        scored+=own; conceded+=opp
        if own>opp: wins+=1
        elif own==opp: draws+=1
        else: losses+=1
    n=len(selected)
    return {"games":n,"win_rate":wins/n,"draw_rate":draws/n,"loss_rate":losses/n,
            "scoring_average":scored/n,"conceded_average":conceded/n}

class HistoricalFormService:
    def __init__(self,db): self.db=db
    def team_form(self,sport,team_name,kickoff_utc,window=10):
        rows=self.db.historical_results_before(sport,team_name,kickoff_utc,limit=max(window,1))
        return summarize_team_form(rows,team_name,sport,kickoff_utc,window)
