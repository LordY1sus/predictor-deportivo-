"""Herramientas transparentes para auditar y unificar identidades de equipos."""


class HistoricalQualityService:
    def __init__(self, db, minimum_games=5):
        self.db = db
        self.minimum_games = max(1, int(minimum_games))

    def add_alias(self, sport, alias_name, canonical_name):
        return self.db.save_team_alias(sport, alias_name, canonical_name)

    def report(self, sport=None):
        report = self.db.historical_coverage(sport)
        for team in report["teams"]:
            team["ready"] = team["matches"] >= self.minimum_games
            team["missing"] = max(0, self.minimum_games - team["matches"])
        report["minimum_games"] = self.minimum_games
        report["ready_teams"] = sum(1 for team in report["teams"] if team["ready"])
        report["teams_below_minimum"] = sum(1 for team in report["teams"] if not team["ready"])
        return report
