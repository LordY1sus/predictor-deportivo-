"""Backtest cronológico de pronósticos realmente archivados.

Solo evalúa predicciones creadas antes del kickoff y resultados históricos
con identidad de partido inequívoca. No fabrica predicciones retrospectivas.
"""
from collections import defaultdict
from datetime import datetime, timezone

from app.analytics.backtesting import evaluate_binary, evaluate_multiclass


class HistoricalBacktestService:
    def __init__(self, db, kickoff_tolerance_seconds=300):
        self.db = db
        self.kickoff_tolerance_seconds = max(0, int(kickoff_tolerance_seconds))

    @staticmethod
    def _dt(value):
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if parsed.tzinfo is None or parsed.utcoffset() is None:
            raise ValueError("timestamp sin zona horaria")
        return parsed.astimezone(timezone.utc)

    def evaluate(self, sport=None):
        with self.db.lock:
            matches = [dict(r) for r in self.db.conn.execute(
                "SELECT * FROM matches" + (" WHERE sport=?" if sport else ""),
                (sport,) if sport else ()).fetchall()]
            projections = [dict(r) for r in self.db.conn.execute(
                "SELECT * FROM projections ORDER BY created_at,id").fetchall()]
            results = [dict(r) for r in self.db.conn.execute(
                "SELECT * FROM historical_results" + (" WHERE sport=?" if sport else ""),
                (sport,) if sport else ()).fetchall()]
            aliases = [dict(r) for r in self.db.conn.execute(
                "SELECT sport,alias_name,canonical_name FROM team_aliases").fetchall()]

        alias_map = {(a["sport"], self.db._norm_team(a["alias_name"])):
                     self.db._norm_team(a["canonical_name"]) for a in aliases}

        def canon(sp, name):
            norm = self.db._norm_team(name)
            return alias_map.get((sp, norm), norm)

        results_by_identity = defaultdict(list)
        invalid_results = 0
        for row in results:
            try:
                kickoff = self._dt(row["kickoff_utc"])
                captured = self._dt(row["captured_at"])
                if captured < kickoff:
                    raise ValueError("resultado capturado antes del inicio")
                key = (row["sport"], canon(row["sport"], row["home_name"]),
                       canon(row["sport"], row["away_name"]))
                results_by_identity[key].append((kickoff, row))
            except (ValueError, TypeError, KeyError):
                invalid_results += 1

        projections_by_match = defaultdict(list)
        for row in projections:
            projections_by_match[row["match_id"]].append(row)

        rows_by_sport = defaultdict(list)
        rows_by_period = defaultdict(lambda: defaultdict(list))
        exclusions = {"without_result": 0, "without_pre_match_projection": 0,
                      "ambiguous_result": 0, "competition_mismatch": 0,
                      "invalid_prediction": 0, "invalid_snapshot": 0,
                      "invalid_result": invalid_results}
        used = 0
        for match in matches:
            try:
                kickoff = self._dt(match["kickoff_utc"])
                key = (match["sport"], canon(match["sport"], match["home_name"]),
                       canon(match["sport"], match["away_name"]))
                import json
                match_payload = json.loads(match.get("payload_json") or "{}")
                match_competition = (match_payload or {}).get("competition") or (match_payload or {}).get("league") or ""
            except (ValueError, TypeError, KeyError):
                exclusions["without_result"] += 1
                continue

            identity_rows = results_by_identity.get(key, [])
            if match_competition:
                candidates = [(abs((result_kickoff - kickoff).total_seconds()), row)
                              for result_kickoff, row in identity_rows
                              if (row.get("competition") or "").strip().casefold() == match_competition.strip().casefold()
                              and abs((result_kickoff - kickoff).total_seconds()) <= self.kickoff_tolerance_seconds]
                if not candidates and any(abs((result_kickoff - kickoff).total_seconds()) <= self.kickoff_tolerance_seconds
                                          for result_kickoff, _ in identity_rows):
                    exclusions["competition_mismatch"] += 1
                    continue
            else:
                candidates = [(abs((result_kickoff - kickoff).total_seconds()), row)
                              for result_kickoff, row in identity_rows
                              if abs((result_kickoff - kickoff).total_seconds()) <= self.kickoff_tolerance_seconds]
            candidates.sort(key=lambda item: item[0])
            if not candidates:
                exclusions["without_result"] += 1
                continue
            if len(candidates) > 1 and candidates[0][0] == candidates[1][0]:
                exclusions["ambiguous_result"] += 1
                continue
            result = candidates[0][1]

            eligible = []
            for projection in projections_by_match.get(match["id"], []):
                try:
                    created = self._dt(projection["created_at"])
                    if created < kickoff:
                        eligible.append((created, projection))
                except (ValueError, TypeError, KeyError):
                    continue
            if not eligible:
                exclusions["without_pre_match_projection"] += 1
                continue
            # Última estimación disponible antes del comienzo.
            eligible.sort(key=lambda item: item[0])
            prediction = eligible[-1][1]
            try:
                import json
                snapshot = json.loads(prediction.get("input_snapshot_json") or "{}")
                snapshot_payload = snapshot.get("payload") or {}
                snapshot_lineup = snapshot.get("lineup") or {}
                generated_at = self._dt(snapshot.get("generated_input_at"))
                confirmed_at = self._dt(snapshot_lineup.get("confirmed_at"))
                observations = snapshot_payload.get("observations")
                if (generated_at >= kickoff or snapshot_lineup.get("status") != "official"
                        or not snapshot_lineup.get("source") or confirmed_at >= kickoff
                        or not isinstance(observations, list) or not observations):
                    raise ValueError("snapshot pre-partido incompleto")
                if any(self._dt(item["observed_at"]) >= kickoff for item in observations):
                    raise ValueError("snapshot contiene observaciones posteriores al inicio")
                probs = json.loads(prediction["result_json"])
                home_score, away_score = float(result["home_score"]), float(result["away_score"])
                if match["sport"] == "football":
                    outcome = "home_win" if home_score > away_score else (
                        "draw" if home_score == away_score else "away_win")
                    # evaluate_multiclass realiza validación de suma y rango.
                    row = {"probabilities": {k: float(probs[k]) for k in
                           ("home_win", "draw", "away_win")}, "outcome": outcome}
                else:
                    outcome = 1 if home_score > away_score else 0
                    row = {"probability": float(probs["home_win"]), "outcome": outcome}
                    if abs(float(probs["home_win"]) + float(probs["away_win"]) - 1.0) > 1e-6:
                        raise ValueError("Las probabilidades de victoria no suman 1")
                rows_by_sport[match["sport"]].append(row)
                rows_by_period[match["sport"]][kickoff.strftime("%Y-%m")].append(row)
                used += 1
            except (KeyError, TypeError, ValueError, OverflowError):
                if not (prediction.get("input_snapshot_json") or "{}").strip() or prediction.get("input_snapshot_json") == "{}":
                    exclusions["invalid_snapshot"] += 1
                else:
                    exclusions["invalid_prediction"] += 1

        metrics = {}
        for current_sport, rows in sorted(rows_by_sport.items()):
            if current_sport == "football":
                metrics[current_sport] = evaluate_multiclass(rows)
            else:
                metrics[current_sport] = evaluate_binary(rows)
        period_metrics = {}
        for current_sport, periods in sorted(rows_by_period.items()):
            period_metrics[current_sport] = {}
            for period, rows in sorted(periods.items()):
                period_metrics[current_sport][period] = (
                    evaluate_multiclass(rows) if current_sport == "football"
                    else evaluate_binary(rows)
                )
        return {"samples": used, "by_sport": metrics, "by_period": period_metrics,
                "exclusions": exclusions,
                "method": "latest_pre_kickoff_projection_vs_matched_final_result",
                "period_grouping": "UTC calendar month; descriptive only, not model retraining",
                "kickoff_tolerance_seconds": self.kickoff_tolerance_seconds}
