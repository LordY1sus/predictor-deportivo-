"""Captura de estadísticas de equipo con corte pre-partido para basket y baseball."""
from datetime import datetime, timedelta, timezone
from app.providers.api_sports import fetch_team_statistics_snapshot


class MultiSportTeamSnapshotService:
    def __init__(self, db):
        self.db = db

    def capture(self, sport, team_id, league_id, season, kickoff_utc, api_key,
                captured_at=None):
        if sport not in ("basketball", "baseball"):
            raise ValueError("Deporte no soportado para esta captura")
        kickoff = datetime.fromisoformat(kickoff_utc.replace("Z", "+00:00"))
        if kickoff.tzinfo is None:
            raise ValueError("kickoff_utc debe incluir zona horaria")
        observed = datetime.fromisoformat((captured_at or datetime.now(timezone.utc).isoformat()).replace("Z", "+00:00"))
        if observed.tzinfo is None or observed >= kickoff:
            raise ValueError("La captura debe ocurrir antes del inicio del partido")
        # El proveedor documenta un parámetro date inclusivo; se usa el día previo
        # para no incorporar estadísticas del propio día del encuentro.
        cutoff = (kickoff.date() - timedelta(days=1)).isoformat()
        record = fetch_team_statistics_snapshot(
            sport, team_id, league_id, season, cutoff, api_key,
            captured_at=observed.isoformat())
        self.db.save_team_stat_observation(record)
        return record

    def get_before_match(self, sport, team_id, league_id, season, kickoff_utc):
        return self.db.get_team_stat_observation(
            sport, team_id, league_id, season, kickoff_utc)
