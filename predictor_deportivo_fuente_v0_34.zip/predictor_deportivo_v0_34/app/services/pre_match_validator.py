"""Validación estricta de los datos de entrada de una proyección pre-partido."""
from datetime import datetime, timezone

SPORT_FIELDS = {
    "football": ("expected_goals",),
    "basketball": ("expected_points",),
    "baseball": ("expected_runs",),
}

def _aware(value, field):
    if not value:
        raise ValueError(f"Falta {field}")
    dt = datetime.fromisoformat(value.replace("Z","+00:00"))
    if dt.tzinfo is None:
        raise ValueError(f"{field} debe incluir zona horaria")
    return dt.astimezone(timezone.utc)

def validate_pre_match_payload(match, payload, lineup, now=None):
    sport = match["sport"]
    if sport not in SPORT_FIELDS:
        raise ValueError("Deporte no soportado")
    kickoff = _aware(match["kickoff_utc"], "kickoff_utc")
    now = now or datetime.now(timezone.utc)
    if kickoff <= now:
        raise ValueError("La proyección pre-partido solo se permite antes del inicio")
    if not isinstance(payload, dict):
        raise ValueError("Faltan datos estadísticos del partido")
    for side in ("home","away"):
        team = payload.get(side)
        if not isinstance(team, dict):
            raise ValueError(f"Faltan estadísticas del equipo {side}")
        for field in SPORT_FIELDS[sport]:
            value = team.get(field)
            if not isinstance(value,(int,float)) or value <= 0:
                raise ValueError(f"{side}.{field} debe ser un número positivo")
    observations = payload.get("observations")
    if not isinstance(observations,list) or not observations:
        raise ValueError("No hay observaciones estadísticas con fecha de captura")
    for item in observations:
        observed = _aware(item.get("observed_at"), "observed_at")
        if observed >= kickoff:
            raise ValueError("Se detectaron datos observados después del inicio")
    if not lineup or lineup.get("status") != "official":
        raise ValueError("Se requiere alineación oficial")
    return True
