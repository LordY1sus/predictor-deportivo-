"""Registro explícito de alineaciones revisadas por el usuario en una fuente oficial.

No realiza scraping ni certifica la autenticidad de una URL: conserva la procedencia
aportada y exige confirmación expresa. La validación temporal y estructural sí es automática.
"""
from datetime import datetime, timezone
from app.services.lineup_validator import validate_lineup


class LineupIntakeService:
    def __init__(self, db):
        self.db = db

    def save_user_confirmed_official(self, match_id, teams, source_url,
                                     injury_report=None, confirmed_at=None,
                                     user_attested=False):
        match = self.db.get_match(match_id)
        if not match:
            raise ValueError("Partido no encontrado")
        if match["status"] != "SCHEDULED":
            raise ValueError("Solo se registran alineaciones para partidos programados")
        if not user_attested:
            raise ValueError("Debes confirmar que contrastaste los datos con la fuente oficial")
        source_url = (source_url or "").strip()
        if not (source_url.startswith("https://") or source_url.startswith("http://")):
            raise ValueError("Indica el enlace de la fuente oficial (http/https)")
        record = {
            "status": "official",
            "source": source_url,
            "confirmed_at": confirmed_at or datetime.now(timezone.utc).isoformat(),
            "teams": teams,
            "verification_method": "user_attested_manual_entry",
        }
        if injury_report is not None:
            record["official_injury_report"] = injury_report
        validate_lineup(match["sport"], record, match["kickoff_utc"])
        self.db.save_lineup(match_id, record)
        return record
