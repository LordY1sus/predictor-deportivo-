from app.providers.espn_scoreboard import fetch_today, fetch_historical_day, ProviderError
from datetime import date, datetime, timezone, timedelta
from app.providers.the_odds_api import fetch_odds
from app.providers.api_sports import (fetch_day as fetch_api_sports_day, fetch_status as fetch_api_sports_status,
    fetch_football_lineups, fetch_football_injuries, fetch_football_team_statistics, APISportsError)
from app.services.lineup_validator import validate_lineup

class SyncService:
    def __init__(self, db):
        self.db = db

    def sync_scoreboard(self, sports=("football","basketball","baseball")):
        total = 0
        errors = []
        for sport in sports:
            try:
                for match in fetch_today(sport):
                    self.db.upsert_match(match)
                    total += 1
            except ProviderError as exc:
                errors.append(f"{sport}: {exc}")
        return {"matches_updated": total, "errors": errors}

    def sync_odds(self, sport, api_key):
        quotes = fetch_odds(sport, api_key)
        saved = 0
        unmatched = 0
        for quote in quotes:
            match_id = self.db.find_match_for_odds(
                sport, quote["home_name"], quote["away_name"], quote["kickoff_utc"]
            )
            if not match_id:
                unmatched += 1
                continue
            self.db.add_odds(match_id, quote["market"], quote["selection"],
                             quote["decimal_odds"], quote["line"],
                             bookmaker=quote.get("bookmaker") or "unknown",
                             provider="the_odds_api")
            saved += 1
        return {"odds_saved": saved, "unmatched": unmatched}

    def sync_historical_range(self, sport, start_date, end_date, max_days=31):
        """Importe les résultats terminés ESPN sur une plage inclusive limitée."""
        if sport not in ("football", "basketball", "baseball"):
            raise ValueError("Sport non pris en charge")
        try:
            start = date.fromisoformat(str(start_date))
            end = date.fromisoformat(str(end_date))
        except ValueError as exc:
            raise ValueError("Les dates doivent respecter AAAA-MM-JJ") from exc
        if end < start:
            raise ValueError("La date de fin doit être égale ou postérieure à la date de début")
        days = (end - start).days + 1
        if days > max_days:
            raise ValueError(f"La plage ne peut pas dépasser {max_days} jours")
        today = datetime.now(timezone.utc).date()
        if end > today:
            raise ValueError("La date de fin ne peut pas être dans le futur")

        records = []
        errors = []
        successful_days = 0
        current = start
        while current <= end:
            try:
                day_records = fetch_historical_day(
                    sport, current, captured_at=datetime.now(timezone.utc).isoformat()
                )
                records.extend(day_records)
                successful_days += 1
            except ProviderError as exc:
                errors.append(f"{current.isoformat()}: {exc}")
            current += timedelta(days=1)
        if records:
            inserted, duplicates = self.db.import_historical_results(records)
        else:
            inserted, duplicates = 0, 0
        return {
            "sport": sport, "days_requested": days, "days_successful": successful_days,
            "records_found": len(records), "inserted": inserted,
            "duplicates": duplicates, "errors": errors,
            "source": "espn_scoreboard",
        }

    def sync_api_sports_range(self, sport, start_date, end_date, api_key, max_days=14, force=False):
        """Sincroniza calendario y resultados API-Sports, una petición por día."""
        if sport not in ("football", "basketball", "baseball"):
            raise ValueError("Deporte no soportado")
        try:
            start = date.fromisoformat(str(start_date))
            end = date.fromisoformat(str(end_date))
        except ValueError as exc:
            raise ValueError("Las fechas deben respetar AAAA-MM-DD") from exc
        if end < start:
            raise ValueError("La fecha final debe ser igual o posterior a la inicial")
        days = (end - start).days + 1
        if days > max_days:
            raise ValueError(f"El rango no puede superar {max_days} días para controlar la cuota API")
        if end > datetime.now(timezone.utc).date():
            raise ValueError("No se pueden descargar fechas futuras como histórico")
        if not (api_key or "").strip():
            raise ValueError("Falta la clave API-Sports")

        matches_updated = 0
        results = []
        errors = []
        successful_days = 0
        skipped_cached = 0
        successful_day_logs = []
        quota = {}
        current = start
        while current <= end:
            day_key = current.isoformat()
            if not force and self.db.has_provider_sync("api_sports", sport, day_key):
                skipped_cached += 1
                current += timedelta(days=1)
                continue
            try:
                response = fetch_api_sports_day(sport, day_key, api_key)
                successful_days += 1
                quota = response.get("quota") or quota
                day_events = response["events"]
                day_is_complete = True
                for item in day_events:
                    self.db.upsert_match(item["match"])
                    matches_updated += 1
                    if item.get("result"):
                        results.append(item["result"])
                    elif item["match"].get("status") == "FINISHED":
                        day_is_complete = False
                    elif item["match"].get("status") != "FINISHED":
                        day_is_complete = False
                if day_is_complete:
                    successful_day_logs.append((day_key, len(day_events)))
            except APISportsError as exc:
                errors.append(f"{day_key}: {exc}")
            current += timedelta(days=1)
        if results:
            inserted, duplicates = self.db.import_historical_results(results)
        else:
            inserted, duplicates = 0, 0
        # Marca fechas como sincronizadas solo después de persistir los resultados.
        for day_key, count in successful_day_logs:
            self.db.record_provider_sync("api_sports", sport, day_key, count, "success")
        return {"sport": sport, "days_requested": days, "days_successful": successful_days,
                "matches_updated": matches_updated, "results_found": len(results),
                "inserted": inserted, "duplicates": duplicates, "errors": errors,
                "days_skipped_cached": skipped_cached,
                "days_pending": successful_days - len(successful_day_logs),
                "quota": quota, "source": "api_sports"}

    def check_api_sports_account(self, sport, api_key):
        return fetch_api_sports_status(sport, api_key)


    def sync_api_sports_football_pre_match(self, api_key, max_matches=12):
        """Importa alineaciones y ausencias de partidos API-Sports de hoy.

        Solo guarda como oficial un XI completo de ambos equipos recibido por
        el endpoint de lineups antes del kickoff. Ausencias se guardan como
        observaciones del proveedor, sin fingir que son fecha de publicación.
        """
        if not (api_key or "").strip():
            raise ValueError("Falta la clave API-Sports")
        matches = [m for m in self.db.get_today_matches(sport="football")
                   if str(m.get("id", "")).startswith("api_sports:football:")
                   and m.get("status") == "SCHEDULED"]
        matches = matches[:max_matches]
        lineups_saved = 0
        injury_observations = 0
        errors = []
        quota = {}
        for match in matches:
            fixture_id = match["id"].rsplit(":", 1)[-1]
            try:
                response = fetch_football_lineups(
                    fixture_id, match["home_name"], match["away_name"], api_key)
                lineup = response["lineup"]
                validate_lineup("football", lineup, match["kickoff_utc"])
                self.db.save_lineup(match["id"], lineup)
                lineups_saved += 1
                quota = response.get("quota") or quota
            except (APISportsError, ValueError) as exc:
                errors.append(f"{match['home_name']} - {match['away_name']} alineación: {exc}")
            try:
                injury_response = fetch_football_injuries(fixture_id, api_key)
                saved = self.db.save_injury_observations(match["id"], injury_response["reports"])
                injury_observations += saved
                quota = injury_response.get("quota") or quota
            except APISportsError as exc:
                errors.append(f"{match['home_name']} - {match['away_name']} ausencias: {exc}")
        return {"matches_checked": len(matches), "lineups_saved": lineups_saved,
                "injury_observations": injury_observations, "errors": errors,
                "quota": quota, "source": "api_sports"}

    def sync_api_sports_football_team_statistics(self, api_key, max_matches=5):
        """Descarga estadísticas agregadas hasta el día anterior al partido.

        Máximo cinco encuentros (hasta diez equipos) por ejecución. La caché
        evita repetir consultas para el mismo equipo/liga/temporada/corte.
        """
        if not (api_key or "").strip():
            raise ValueError("Falta la clave API-Sports")
        matches = [m for m in self.db.get_today_matches(sport="football")
                   if str(m.get("id", "")).startswith("api_sports:football:")
                   and m.get("status") == "SCHEDULED"][:max_matches]
        saved = skipped = 0
        errors = []
        quota = {}
        for match in matches:
            try:
                payload = __import__("json").loads(match.get("payload_json") or "{}")
                league_id, season = payload.get("league_id"), payload.get("season")
                if not league_id or not season:
                    errors.append(f"{match['home_name']} - {match['away_name']}: faltan IDs de liga/temporada")
                    continue
                kickoff = datetime.fromisoformat(match["kickoff_utc"].replace("Z", "+00:00"))
                cutoff = (kickoff.date() - timedelta(days=1)).isoformat()
                for side, team_key, name_key in (("home", "home_team_id", "home_name"),
                                                  ("away", "away_team_id", "away_name")):
                    team_id = payload.get(team_key)
                    if not team_id:
                        errors.append(f"{match[name_key]}: falta ID de equipo API-Sports")
                        continue
                    existing = self.db.get_team_stat_observation("football", team_id, league_id, season,
                                                                  match["kickoff_utc"])
                    if existing:
                        skipped += 1
                        continue
                    try:
                        record = fetch_football_team_statistics(team_id, league_id, season, cutoff, api_key)
                        record["team_name"] = record.get("team_name") or match[name_key]
                        self.db.save_team_stat_observation(record)
                        saved += 1
                        quota = record.get("quota") or quota
                    except APISportsError as exc:
                        errors.append(f"{match[name_key]}: {exc}")
            except (TypeError, ValueError, KeyError) as exc:
                errors.append(f"{match.get('home_name', 'Partido')}: {exc}")
        return {"matches_checked": len(matches), "statistics_saved": saved,
                "statistics_cached": skipped, "errors": errors, "quota": quota,
                "source": "api_football_teams_statistics"}
