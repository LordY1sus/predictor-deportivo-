"""Contexto auditable de estadísticas pre-partido para basket y béisbol.

No modifica las expectativas numéricas: los esquemas estadísticos del proveedor
varían por competición y requieren calibración específica antes de ponderarlos.
"""
from datetime import datetime
import json


class MultiSportStatisticsContextService:
    def __init__(self, db):
        self.db = db

    def snapshot_for_match(self, match):
        sport = match.get("sport")
        if sport not in ("basketball", "baseball"):
            return {}
        try:
            meta = json.loads(match.get("payload_json") or "{}")
        except (TypeError, ValueError):
            meta = match.get("payload") or {}
        ids = {"home": meta.get("home_team_id"), "away": meta.get("away_team_id")}
        league, season = meta.get("league_id"), meta.get("season")
        if not all((ids["home"], ids["away"], league, season)):
            return {}
        kickoff = datetime.fromisoformat(match["kickoff_utc"].replace("Z", "+00:00"))
        if kickoff.tzinfo is None:
            return {}
        records = {}
        for side, team_id in ids.items():
            record = self.db.get_team_stat_observation(
                sport, team_id, league, season, kickoff.isoformat())
            if not record:
                return {}
            observed = datetime.fromisoformat(record["observed_at"].replace("Z", "+00:00"))
            valid_before = datetime.strptime(record["valid_before"], "%Y-%m-%d").date()
            if observed.tzinfo is None or observed >= kickoff or valid_before >= kickoff.date():
                return {}
            records[side] = {
                "team_id": str(team_id), "valid_before": record["valid_before"],
                "observed_at": record["observed_at"], "source": record["source"],
                "statistics": record["statistics"],
            }
        return {"sport": sport, "league_id": str(league), "season": str(season),
                "method": "pre_match_team_snapshot_audit_only", "teams": records}
