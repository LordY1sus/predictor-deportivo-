from datetime import datetime, timezone

COUNTS = {"football":11, "basketball":5, "baseball":9}

def validate_lineup(sport, record, kickoff_utc):
    if sport not in COUNTS:
        raise ValueError("Deporte no soportado")
    if not record or record.get("status") != "official":
        raise ValueError("Se requiere alineación oficial confirmada")
    if not record.get("source") or not record.get("confirmed_at"):
        raise ValueError("La alineación debe incluir fuente y hora de confirmación")
    confirmed = datetime.fromisoformat(record["confirmed_at"].replace("Z","+00:00"))
    kickoff = datetime.fromisoformat(kickoff_utc.replace("Z","+00:00"))
    if confirmed.tzinfo is None or kickoff.tzinfo is None:
        raise ValueError("Las fechas deben incluir zona horaria")
    if confirmed >= kickoff:
        raise ValueError("La alineación debe confirmarse antes del inicio")
    teams = record.get("teams", {})
    for side in ("home","away"):
        players = teams.get(side,{}).get("starters",[])
        if (len(players) != COUNTS[sport] or
            any(not isinstance(x,str) or not x.strip() for x in players) or
            len({x.strip().casefold() for x in players}) != COUNTS[sport]):
            raise ValueError(f"Alineación {side}: se requieren {COUNTS[sport]} titulares identificados y únicos")
    if sport == "basketball":
        report=record.get("official_injury_report")
        if not isinstance(report,dict) or not report.get("source") or not report.get("published_at"):
            raise ValueError("Falta el informe oficial de lesiones con fuente y fecha")
        published=datetime.fromisoformat(report["published_at"].replace("Z","+00:00"))
        if published.tzinfo is None or published >= kickoff:
            raise ValueError("El informe de lesiones debe estar fechado antes del inicio")
    if sport == "baseball":
        for side in ("home","away"):
            if not teams[side].get("starting_pitcher"):
                raise ValueError(f"Falta el pitcher abridor oficial: {side}")
    return True
