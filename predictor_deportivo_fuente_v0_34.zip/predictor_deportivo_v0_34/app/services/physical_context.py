"""Contexto físico pre-partido: descanso y desplazamiento si hay datos verificados."""
from datetime import datetime

def calculate_rest_context(previous_kickoff_utc, kickoff_utc, travel_km=None,
                           observed_at=None, source=None):
    kickoff=datetime.fromisoformat(kickoff_utc.replace("Z","+00:00"))
    if kickoff.tzinfo is None: raise ValueError("kickoff debe incluir zona horaria")
    if previous_kickoff_utc:
        previous=datetime.fromisoformat(previous_kickoff_utc.replace("Z","+00:00"))
        if previous.tzinfo is None or previous >= kickoff:
            raise ValueError("El partido anterior debe ser anterior al kickoff")
        rest_hours=(kickoff-previous).total_seconds()/3600
    else:
        rest_hours=None
    if travel_km is not None:
        if travel_km < 0 or not observed_at or not source:
            raise ValueError("El viaje requiere distancia, fecha y fuente")
        observed=datetime.fromisoformat(observed_at.replace("Z","+00:00"))
        if observed.tzinfo is None or observed >= kickoff:
            raise ValueError("El dato de viaje debe ser previo al partido")
    return {"rest_hours":rest_hours,"travel_km":travel_km,
            "rest_short":rest_hours is not None and rest_hours < 72,
            "travel_data_verified":travel_km is not None}

class PlayerFormService:
    def __init__(self,db): self.db=db
    def recent_observations(self,sport,player_id,kickoff_utc,limit=10):
        return self.db.player_observations_before(sport,player_id,kickoff_utc,limit)
