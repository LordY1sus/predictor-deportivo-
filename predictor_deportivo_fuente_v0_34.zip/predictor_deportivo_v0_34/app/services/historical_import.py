"""Importación validada de resultados históricos desde CSV UTF-8."""
import csv
import io
from pathlib import Path
from datetime import datetime, timezone


REQUIRED_COLUMNS = {
    "id", "sport", "home_name", "away_name", "kickoff_utc",
    "home_score", "away_score", "source", "captured_at"
}
SUPPORTED_SPORTS = {"football", "basketball", "baseball"}


class HistoricalImportError(ValueError):
    pass


def _aware_iso(value, field, row_number):
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        raise HistoricalImportError(f"Fila {row_number}: {field} no es una fecha ISO válida")
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise HistoricalImportError(f"Fila {row_number}: {field} debe incluir zona horaria")
    return parsed.astimezone(timezone.utc).isoformat()


def parse_historical_csv(content):
    if isinstance(content, bytes):
        try:
            content = content.decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise HistoricalImportError("El CSV debe estar codificado en UTF-8") from exc
    if not isinstance(content, str) or not content.strip():
        raise HistoricalImportError("El archivo CSV está vacío")
    reader = csv.DictReader(io.StringIO(content))
    if not reader.fieldnames:
        raise HistoricalImportError("El CSV no contiene encabezados")
    headers = {h.strip() for h in reader.fieldnames if h}
    missing = REQUIRED_COLUMNS - headers
    if missing:
        raise HistoricalImportError("Faltan columnas obligatorias: " + ", ".join(sorted(missing)))

    records = []
    seen_ids = set()
    for row_number, raw in enumerate(reader, start=2):
        row = {(k or "").strip(): (v or "").strip() for k, v in raw.items()}
        if not any(row.values()):
            continue
        required_text = ("id", "sport", "home_name", "away_name", "source")
        if any(not row.get(key) for key in required_text):
            raise HistoricalImportError(f"Fila {row_number}: hay campos de texto obligatorios vacíos")
        if row["sport"] not in SUPPORTED_SPORTS:
            raise HistoricalImportError(f"Fila {row_number}: deporte no soportado")
        if row["id"] in seen_ids:
            raise HistoricalImportError(f"Fila {row_number}: ID duplicado dentro del CSV ({row['id']})")
        seen_ids.add(row["id"])
        if row["home_name"].casefold() == row["away_name"].casefold():
            raise HistoricalImportError(f"Fila {row_number}: los equipos no pueden ser iguales")
        try:
            home_score = float(row["home_score"])
            away_score = float(row["away_score"])
        except (ValueError, TypeError):
            raise HistoricalImportError(f"Fila {row_number}: los marcadores deben ser numéricos")
        if home_score < 0 or away_score < 0:
            raise HistoricalImportError(f"Fila {row_number}: los marcadores no pueden ser negativos")
        if not home_score.is_integer() or not away_score.is_integer():
            raise HistoricalImportError(f"Fila {row_number}: los marcadores deben ser números enteros")
        kickoff = _aware_iso(row.get("kickoff_utc"), "kickoff_utc", row_number)
        captured = _aware_iso(row.get("captured_at"), "captured_at", row_number)
        kickoff_dt = datetime.fromisoformat(kickoff)
        captured_dt = datetime.fromisoformat(captured)
        now = datetime.now(timezone.utc)
        if kickoff_dt >= now:
            raise HistoricalImportError(f"Fila {row_number}: un resultado histórico no puede corresponder a un partido futuro o aún no iniciado")
        if captured_dt < kickoff_dt:
            raise HistoricalImportError(f"Fila {row_number}: captured_at no puede ser anterior al inicio del partido")
        if captured_dt > now:
            raise HistoricalImportError(f"Fila {row_number}: captured_at no puede estar en el futuro")
        records.append({
            "id": row["id"], "sport": row["sport"],
            "home_name": row["home_name"], "away_name": row["away_name"],
            "kickoff_utc": kickoff, "home_score": home_score,
            "away_score": away_score, "source": row["source"],
            "captured_at": captured,
            "competition": row.get("competition", "").strip(),
        })
    if not records:
        raise HistoricalImportError("El CSV no contiene resultados para importar")
    return records


class HistoricalImportService:
    def __init__(self, db):
        self.db = db

    def import_csv(self, content):
        # Primero se valida el archivo completo; un error no deja una importación parcial.
        records = parse_historical_csv(content)
        inserted, duplicates = self.db.import_historical_results(records)
        return {"read": len(records), "inserted": inserted, "duplicates": duplicates}

    def import_file(self, file_path, max_bytes=10 * 1024 * 1024):
        path = Path(file_path)
        if path.suffix.lower() != ".csv":
            raise HistoricalImportError("Solo se admiten archivos .csv")
        if not path.is_file():
            raise HistoricalImportError("No se encontró el archivo seleccionado")
        size = path.stat().st_size
        if size > max_bytes:
            raise HistoricalImportError("El CSV supera el límite permitido de 10 MB")
        return self.import_csv(path.read_bytes())
