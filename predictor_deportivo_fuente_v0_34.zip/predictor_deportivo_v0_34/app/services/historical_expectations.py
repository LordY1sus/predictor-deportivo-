"""Estimaciones base desde resultados históricos anteriores al kickoff.

Estas cifras son proxies basados en marcadores, no xG, ORtg/DRtg ni métricas
avanzadas oficiales. Se exige una muestra mínima y se conserva procedencia.
"""
from datetime import datetime, timezone
import math


class InsufficientHistoryError(ValueError):
    pass


class HistoricalExpectationService:
    FIELD_BY_SPORT = {
        "football": "expected_goals",
        "basketball": "expected_points",
        "baseball": "expected_runs",
    }

    def __init__(self, db, window=10, minimum_games=5):
        self.db = db
        self.window = max(1, int(window))
        self.minimum_games = max(1, int(minimum_games))

    @staticmethod
    def _utc(value):
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            raise ValueError("Las fechas históricas deben incluir zona horaria")
        return dt.astimezone(timezone.utc)

    def _team_sample(self, sport, team, cutoff, competition=None):
        now = datetime.now(timezone.utc)
        rows = self.db.historical_results_before(
            sport, team, cutoff.isoformat(), limit=self.window * 3,
            competition=competition
        )
        sample = []
        for row in rows:
            played = self._utc(row["kickoff_utc"])
            captured = self._utc(row["captured_at"])
            # Un resultado histórico debe haber ocurrido y haber sido capturado
            # antes del momento actual, además de antes del partido objetivo.
            if played >= min(cutoff, now) or captured >= min(cutoff, now):
                continue
            canonical_team = self.db.canonical_team_name(sport, team)
            is_home = self.db.canonical_team_name(sport, row["home_name"]) == canonical_team
            scored = float(row["home_score"] if is_home else row["away_score"])
            conceded = float(row["away_score"] if is_home else row["home_score"])
            if scored < 0 or conceded < 0:
                continue
            sample.append({"scored": scored, "conceded": conceded,
                           "source": row["source"], "captured_at": row["captured_at"]})
        return sample

    def build_payload(self, match):
        if match.get("status") != "SCHEDULED":
            raise ValueError("Solo se generan métricas para partidos programados")
        kickoff = self._utc(match["kickoff_utc"])
        now = datetime.now(timezone.utc)
        if kickoff <= now:
            raise ValueError("El partido ya comenzó; no se generan métricas pre-partido")
        sport = match["sport"]
        field = self.FIELD_BY_SPORT.get(sport)
        if not field:
            raise ValueError("Deporte no soportado")
        import json
        match_payload = match.get("payload_json") or match.get("payload") or "{}"
        if isinstance(match_payload, str):
            match_payload = json.loads(match_payload)
        competition = (match_payload or {}).get("competition") or (match_payload or {}).get("league")
        home = self._team_sample(sport, match["home_name"], kickoff, competition)
        away = self._team_sample(sport, match["away_name"], kickoff, competition)
        if len(home) < self.minimum_games or len(away) < self.minimum_games:
            raise InsufficientHistoryError(
                f"Historial insuficiente: se requieren {self.minimum_games} partidos previos por equipo; "
                f"hay {len(home)} de {match['home_name']} y {len(away)} de {match['away_name']}"
            )

        def mean(rows, key):
            return sum(item[key] for item in rows) / len(rows)

        # Media entre capacidad anotadora propia y puntos/carreras/goles concedidos
        # por el rival. Sin factor de localía inventado ni ajustes sin fuente.
        home_expected = (mean(home, "scored") + mean(away, "conceded")) / 2.0
        away_expected = (mean(away, "scored") + mean(home, "conceded")) / 2.0
        floor = 0.05 if sport == "football" else 0.5
        home_expected = max(floor, home_expected)
        away_expected = max(floor, away_expected)
        observations = []
        seen = set()
        for item in home + away:
            stamp = item["captured_at"]
            if stamp not in seen:
                observations.append({"observed_at": stamp, "source": item["source"]})
                seen.add(stamp)
        return {
            "home": {field: home_expected},
            "away": {field: away_expected},
            "observations": observations,
            "baseline_method": "historical_score_average_proxy",
            "baseline_warning": "Proxy basado en marcadores; no equivale a xG, eficiencia avanzada ni métricas oficiales.",
            "sample": {"home_games": len(home), "away_games": len(away), "window": self.window,
                       "competition": competition},
        }
