import sqlite3
import threading
from datetime import datetime, timezone
import json

class Database:
    def __init__(self, path):
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        with self.lock:
            self.conn.executescript("""
            PRAGMA foreign_keys=ON;
            CREATE TABLE IF NOT EXISTS matches(
              id TEXT PRIMARY KEY, sport TEXT NOT NULL, home_name TEXT NOT NULL,
              away_name TEXT NOT NULL, kickoff_utc TEXT NOT NULL,
              kickoff_local TEXT NOT NULL, status TEXT NOT NULL,
              payload_json TEXT NOT NULL DEFAULT '{}'
            );
            CREATE TABLE IF NOT EXISTS lineups(
              match_id TEXT PRIMARY KEY REFERENCES matches(id),
              status TEXT NOT NULL, source TEXT NOT NULL, confirmed_at TEXT NOT NULL,
              payload_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS odds(
              id INTEGER PRIMARY KEY AUTOINCREMENT, match_id TEXT NOT NULL REFERENCES matches(id),
              market TEXT NOT NULL, selection TEXT NOT NULL, line REAL,
              decimal_odds REAL NOT NULL, captured_at TEXT NOT NULL,
              bookmaker TEXT NOT NULL DEFAULT 'unknown',
              provider TEXT NOT NULL DEFAULT 'unknown'
            );
            CREATE TABLE IF NOT EXISTS projections(
              id INTEGER PRIMARY KEY AUTOINCREMENT, match_id TEXT NOT NULL REFERENCES matches(id),
              created_at TEXT NOT NULL, simulations INTEGER NOT NULL,
              result_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS historical_results(
              id TEXT PRIMARY KEY, sport TEXT NOT NULL, home_name TEXT NOT NULL,
              away_name TEXT NOT NULL, kickoff_utc TEXT NOT NULL,
              home_score REAL NOT NULL, away_score REAL NOT NULL,
              source TEXT NOT NULL, captured_at TEXT NOT NULL,
              competition TEXT NOT NULL DEFAULT ''
            );
            CREATE INDEX IF NOT EXISTS idx_history_teams_date
              ON historical_results(sport,home_name,away_name,kickoff_utc);
            CREATE TABLE IF NOT EXISTS team_aliases(
              sport TEXT NOT NULL, alias_name TEXT NOT NULL, canonical_name TEXT NOT NULL,
              created_at TEXT NOT NULL, PRIMARY KEY(sport,alias_name)
            );
            CREATE TABLE IF NOT EXISTS provider_sync_log(
              provider TEXT NOT NULL, sport TEXT NOT NULL, requested_date TEXT NOT NULL,
              completed_at TEXT NOT NULL, records_count INTEGER NOT NULL DEFAULT 0,
              status TEXT NOT NULL, PRIMARY KEY(provider,sport,requested_date)
            );
            CREATE TABLE IF NOT EXISTS player_observations(
              id TEXT PRIMARY KEY, sport TEXT NOT NULL, player_id TEXT NOT NULL,
              team_name TEXT NOT NULL, observed_at TEXT NOT NULL, source TEXT NOT NULL,
              stats_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_player_obs
              ON player_observations(sport,player_id,observed_at);
            CREATE TABLE IF NOT EXISTS availability_reports(
              id TEXT PRIMARY KEY, match_id TEXT NOT NULL REFERENCES matches(id),
              team_side TEXT NOT NULL, status TEXT NOT NULL, source TEXT NOT NULL,
              published_at TEXT NOT NULL, payload_json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS injury_observations(
              id TEXT PRIMARY KEY, match_id TEXT NOT NULL REFERENCES matches(id),
              team_name TEXT NOT NULL, player_id TEXT NOT NULL, player_name TEXT NOT NULL,
              injury_type TEXT NOT NULL, reason TEXT NOT NULL, observed_at TEXT NOT NULL,
              source TEXT NOT NULL, payload_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_injury_match_observed
              ON injury_observations(match_id, observed_at);
            CREATE TABLE IF NOT EXISTS team_stat_observations(
              id TEXT PRIMARY KEY, sport TEXT NOT NULL, team_id TEXT NOT NULL,
              team_name TEXT NOT NULL, league_id TEXT NOT NULL, competition TEXT NOT NULL,
              season TEXT NOT NULL, valid_before TEXT NOT NULL, observed_at TEXT NOT NULL,
              source TEXT NOT NULL, stats_json TEXT NOT NULL,
              UNIQUE(sport,team_id,league_id,season,valid_before)
            );
            CREATE INDEX IF NOT EXISTS idx_team_stats_lookup
              ON team_stat_observations(sport,team_id,league_id,season,valid_before);
            CREATE INDEX IF NOT EXISTS idx_matches_kickoff ON matches(kickoff_local);
            CREATE INDEX IF NOT EXISTS idx_odds_match ON odds(match_id, captured_at);
            """)
            history_columns={row["name"] for row in self.conn.execute("PRAGMA table_info(historical_results)")}
            if "competition" not in history_columns:
                self.conn.execute("ALTER TABLE historical_results ADD COLUMN competition TEXT NOT NULL DEFAULT ''")
            projection_columns={row["name"] for row in self.conn.execute("PRAGMA table_info(projections)")}
            if "input_snapshot_json" not in projection_columns:
                self.conn.execute("ALTER TABLE projections ADD COLUMN input_snapshot_json TEXT NOT NULL DEFAULT '{}'")
            if "model_version" not in projection_columns:
                self.conn.execute("ALTER TABLE projections ADD COLUMN model_version TEXT NOT NULL DEFAULT 'legacy'")
            if "seed" not in projection_columns:
                self.conn.execute("ALTER TABLE projections ADD COLUMN seed INTEGER")
            odds_columns={row["name"] for row in self.conn.execute("PRAGMA table_info(odds)")}
            if "bookmaker" not in odds_columns:
                self.conn.execute("ALTER TABLE odds ADD COLUMN bookmaker TEXT NOT NULL DEFAULT 'unknown'")
            if "provider" not in odds_columns:
                self.conn.execute("ALTER TABLE odds ADD COLUMN provider TEXT NOT NULL DEFAULT 'unknown'")
            self.conn.commit()

    def upsert_match(self, match):
        required = ("id","sport","home_name","away_name","kickoff_utc","kickoff_local","status")
        if any(not match.get(k) for k in required):
            raise ValueError("Datos incompletos del partido")
        with self.lock:
            self.conn.execute("""INSERT INTO matches VALUES(?,?,?,?,?,?,?,?)
              ON CONFLICT(id) DO UPDATE SET sport=excluded.sport, home_name=excluded.home_name,
              away_name=excluded.away_name, kickoff_utc=excluded.kickoff_utc,
              kickoff_local=excluded.kickoff_local, status=excluded.status,
              payload_json=excluded.payload_json""",
              (match["id"],match["sport"],match["home_name"],match["away_name"],
               match["kickoff_utc"],match["kickoff_local"],match["status"],
               json.dumps(match.get("payload",{}))))
            self.conn.commit()

    def get_today_matches(self, sport=None, local_date=None):
        local_date = local_date or datetime.now().astimezone().date().isoformat()
        sql = """SELECT * FROM matches WHERE substr(kickoff_local,1,10)=?
                 AND status IN ('SCHEDULED','LIVE') ORDER BY kickoff_local"""
        args = [local_date]
        if sport:
            sql += " AND sport=?"; args.append(sport)
        with self.lock:
            return [dict(r) for r in self.conn.execute(sql,args).fetchall()]

    def get_match(self, match_id):
        with self.lock:
            row = self.conn.execute("SELECT * FROM matches WHERE id=?",(match_id,)).fetchone()
            return dict(row) if row else None

    def save_lineup(self, match_id, record):
        with self.lock:
            self.conn.execute("""INSERT OR REPLACE INTO lineups VALUES(?,?,?,?,?)""",
              (match_id,record["status"],record["source"],record["confirmed_at"],json.dumps(record)))
            self.conn.commit()

    def get_lineup(self, match_id):
        with self.lock:
            row = self.conn.execute("SELECT * FROM lineups WHERE match_id=?",(match_id,)).fetchone()
            return json.loads(row["payload_json"]) if row else None

    def add_odds(self, match_id, market, selection, decimal_odds, line=None,
                 bookmaker="unknown", provider="unknown", captured_at=None):
        if decimal_odds <= 1:
            raise ValueError("La cuota decimal debe ser mayor que 1")
        if not market or not selection or not bookmaker or not provider:
            raise ValueError("La cuota debe identificar mercado, selección, casa y proveedor")
        captured_at=captured_at or datetime.now(timezone.utc).isoformat()
        dt=datetime.fromisoformat(captured_at.replace("Z","+00:00"))
        if dt.tzinfo is None:
            raise ValueError("captured_at debe incluir zona horaria")
        with self.lock:
            self.conn.execute("""INSERT INTO odds
              (match_id,market,selection,line,decimal_odds,captured_at,bookmaker,provider)
              VALUES(?,?,?,?,?,?,?,?)""",
              (match_id,market,selection,line,decimal_odds,captured_at,bookmaker,provider))
            self.conn.commit()

    def latest_odds(self, match_id):
        with self.lock:
            rows = self.conn.execute("""SELECT o.* FROM odds o JOIN
              (SELECT market,selection,line,bookmaker,MAX(captured_at) t
               FROM odds WHERE match_id=? GROUP BY market,selection,line,bookmaker) x
              ON o.market=x.market AND o.selection=x.selection AND o.line IS x.line
                 AND o.bookmaker=x.bookmaker AND o.captured_at=x.t
              WHERE o.match_id=?""",(match_id,match_id)).fetchall()
            return [dict(r) for r in rows]

    def save_projection(self, match_id, simulations, result, input_snapshot=None,
                        model_version="advanced_models_v1", seed=None):
        with self.lock:
            cur = self.conn.execute("""INSERT INTO projections
              (match_id,created_at,simulations,result_json,input_snapshot_json,model_version,seed)
              VALUES(?,?,?,?,?,?,?)""",
              (match_id,datetime.now(timezone.utc).isoformat(),simulations,json.dumps(result),
               json.dumps(input_snapshot or {}, ensure_ascii=False),model_version,seed))
            self.conn.commit()
            return cur.lastrowid

    def get_projection_record(self, projection_id):
        with self.lock:
            row = self.conn.execute("SELECT * FROM projections WHERE id=?", (projection_id,)).fetchone()
            if not row:
                return None
            item = dict(row)
            item["result"] = json.loads(item.pop("result_json"))
            item["input_snapshot"] = json.loads(item.pop("input_snapshot_json"))
            return item



    def get_latest_projection(self, match_id):
        with self.lock:
            row=self.conn.execute(
                "SELECT result_json FROM projections WHERE match_id=? ORDER BY created_at DESC,id DESC LIMIT 1",
                (match_id,)
            ).fetchone()
            return json.loads(row["result_json"]) if row else None

    def get_matches_with_latest_projection(self, sport=None, local_date=None):
        local_date = local_date or datetime.now().astimezone().date().isoformat()
        sql = """SELECT m.* FROM matches m
                 WHERE substr(m.kickoff_local,1,10)=?
                 AND m.status IN ('SCHEDULED','LIVE')
                 AND EXISTS (SELECT 1 FROM projections p WHERE p.match_id=m.id)"""
        args=[local_date]
        if sport:
            sql += " AND m.sport=?"; args.append(sport)
        sql += " ORDER BY m.kickoff_local"
        with self.lock:
            return [dict(r) for r in self.conn.execute(sql,args).fetchall()]

    @staticmethod
    def _norm_team(value):
        import re, unicodedata
        value = unicodedata.normalize("NFKD", value or "").encode("ascii","ignore").decode().lower()
        return re.sub(r"[^a-z0-9]", "", value)

    def find_match_for_odds(self, sport, home_name, away_name, kickoff_utc, tolerance_minutes=30):
        from datetime import datetime
        target = datetime.fromisoformat(kickoff_utc.replace("Z","+00:00"))
        with self.lock:
            rows = self.conn.execute(
                "SELECT id,home_name,away_name,kickoff_utc FROM matches WHERE sport=? AND status='SCHEDULED'",
                (sport,)
            ).fetchall()
        for row in rows:
            try:
                candidate = datetime.fromisoformat(row["kickoff_utc"].replace("Z","+00:00"))
                delta = abs((candidate-target).total_seconds()) / 60
            except ValueError:
                continue
            if (self._norm_team(row["home_name"]) == self._norm_team(home_name)
                and self._norm_team(row["away_name"]) == self._norm_team(away_name)
                and delta <= tolerance_minutes):
                return row["id"]
        return None


    def save_historical_result(self, record):
        required=("id","sport","home_name","away_name","kickoff_utc","home_score","away_score","source")
        if any(k not in record for k in required):
            raise ValueError("Resultado histórico incompleto")
        if record["sport"] not in ("football","basketball","baseball"):
            raise ValueError("Deporte histórico no soportado")
        if float(record["home_score"]) < 0 or float(record["away_score"]) < 0:
            raise ValueError("Los marcadores no pueden ser negativos")
        with self.lock:
            self.conn.execute("""INSERT OR REPLACE INTO historical_results
              (id,sport,home_name,away_name,kickoff_utc,home_score,away_score,source,captured_at,competition)
              VALUES(?,?,?,?,?,?,?,?,?,?)""",
              (record["id"],record["sport"],record["home_name"],record["away_name"],
               record["kickoff_utc"],record["home_score"],record["away_score"],
               record["source"],record.get("captured_at",datetime.now(timezone.utc).isoformat()),
               (record.get("competition") or "").strip()))
            self.conn.commit()

    def import_historical_results(self, records):
        """Inserta un lote validado en una transacción, sin sobrescribir IDs existentes."""
        with self.lock:
            inserted = 0
            try:
                self.conn.execute("BEGIN")
                for record in records:
                    cur = self.conn.execute("""INSERT OR IGNORE INTO historical_results
                      (id,sport,home_name,away_name,kickoff_utc,home_score,away_score,source,captured_at,competition)
                      VALUES(?,?,?,?,?,?,?,?,?,?)""",
                      (record["id"],record["sport"],record["home_name"],record["away_name"],
                       record["kickoff_utc"],record["home_score"],record["away_score"],
                       record["source"],record["captured_at"],(record.get("competition") or "").strip()))
                    inserted += cur.rowcount
                self.conn.commit()
            except Exception:
                self.conn.rollback()
                raise
            return inserted, len(records) - inserted

    def canonical_team_name(self, sport, team_name):
        """Devuelve el nombre canónico configurado; no adivina equivalencias."""
        key = self._norm_team(team_name)
        with self.lock:
            aliases = self.conn.execute(
                "SELECT alias_name,canonical_name FROM team_aliases WHERE sport=?", (sport,)
            ).fetchall()
        for row in aliases:
            if self._norm_team(row["alias_name"]) == key:
                return row["canonical_name"]
        return team_name.strip()

    def save_team_alias(self, sport, alias_name, canonical_name):
        if sport not in ("football", "basketball", "baseball"):
            raise ValueError("Deporte no soportado")
        alias_name = (alias_name or "").strip()
        canonical_name = (canonical_name or "").strip()
        if not alias_name or not canonical_name:
            raise ValueError("El alias y el nombre canónico son obligatorios")
        if self._norm_team(alias_name) == self._norm_team(canonical_name):
            raise ValueError("El alias y el nombre canónico ya son equivalentes")
        stamp = datetime.now(timezone.utc).isoformat()
        with self.lock:
            rows = self.conn.execute("SELECT alias_name,canonical_name FROM team_aliases WHERE sport=?", (sport,)).fetchall()
            for row in rows:
                if self._norm_team(row["alias_name"]) == self._norm_team(alias_name):
                    if row["canonical_name"] == canonical_name:
                        return False
                    raise ValueError("Ese alias ya está asignado a otro equipo; elimina o corrige la asignación existente")
            self.conn.execute(
                "INSERT INTO team_aliases(sport,alias_name,canonical_name,created_at) VALUES(?,?,?,?)",
                (sport, alias_name, canonical_name, stamp)
            )
            self.conn.commit()
        return True

    def list_team_aliases(self, sport=None):
        sql = "SELECT sport,alias_name,canonical_name,created_at FROM team_aliases"
        args = []
        if sport:
            sql += " WHERE sport=?"; args.append(sport)
        sql += " ORDER BY sport,canonical_name,alias_name"
        with self.lock:
            return [dict(row) for row in self.conn.execute(sql, args).fetchall()]

    def historical_results_before(self, sport, team_name, cutoff_utc, limit=20, competition=None):
        from datetime import datetime
        cutoff=datetime.fromisoformat(cutoff_utc.replace("Z","+00:00"))
        canonical = self.canonical_team_name(sport, team_name)
        with self.lock:
            alias_rows = self.conn.execute(
                "SELECT alias_name FROM team_aliases WHERE sport=? AND canonical_name=?", (sport, canonical)
            ).fetchall()
            names = [canonical] + [row["alias_name"] for row in alias_rows]
            placeholders = ",".join("?" for _ in names)
            sql = f"SELECT * FROM historical_results WHERE sport=? AND (home_name IN ({placeholders}) OR away_name IN ({placeholders}))"
            params = [sport] + names + names
            if competition:
                sql += " AND LOWER(TRIM(competition))=LOWER(TRIM(?))"
                params.append(competition)
            sql += " ORDER BY kickoff_utc DESC"
            rows=self.conn.execute(sql, params).fetchall()
        eligible=[]
        for row in rows:
            try:
                dt=datetime.fromisoformat(row["kickoff_utc"].replace("Z","+00:00"))
            except ValueError:
                continue
            if dt.tzinfo is not None and dt < cutoff:
                eligible.append(dict(row))
            if len(eligible)>=limit:
                break
        return eligible

    def historical_coverage(self, sport=None):
        """Cobertura agregada y por equipo usando identidades canónicas explícitas."""
        sql = "SELECT * FROM historical_results"
        args = []
        if sport:
            sql += " WHERE sport=?"; args.append(sport)
        with self.lock:
            rows = [dict(r) for r in self.conn.execute(sql, args).fetchall()]
            aliases = [dict(r) for r in self.conn.execute("SELECT sport,alias_name,canonical_name FROM team_aliases").fetchall()]
        alias_map = {(a["sport"], self._norm_team(a["alias_name"])): a["canonical_name"] for a in aliases}
        def canonical(sp, name):
            return alias_map.get((sp, self._norm_team(name)), name)
        teams = {}
        sources = set()
        dates = []
        for row in rows:
            sources.add(row["source"])
            dates.append(row["kickoff_utc"])
            for name in (row["home_name"], row["away_name"]):
                key = (row["sport"], canonical(row["sport"], name))
                teams[key] = teams.get(key, 0) + 1
        by_sport = {}
        by_competition = {}
        for row in rows:
            competition = (row.get("competition") or "(sin competición)").strip()
            comp_key = (row["sport"], competition)
            comp_item = by_competition.setdefault(comp_key, {"matches": 0, "teams": set(), "sources": set(), "dates": []})
            comp_item["matches"] += 1
            comp_item["teams"].update((canonical(row["sport"], row["home_name"]), canonical(row["sport"], row["away_name"])))
            comp_item["sources"].add(row["source"])
            comp_item["dates"].append(row["kickoff_utc"])
            item = by_sport.setdefault(row["sport"], {"matches": 0, "teams": set(), "sources": set(), "dates": []})
            item["matches"] += 1
            item["teams"].add(canonical(row["sport"], row["home_name"]))
            item["teams"].add(canonical(row["sport"], row["away_name"]))
            item["sources"].add(row["source"])
            item["dates"].append(row["kickoff_utc"])
        summary = {}
        for sp, item in by_sport.items():
            summary[sp] = {"matches": item["matches"], "teams": len(item["teams"]),
                           "sources": sorted(item["sources"]), "from": min(item["dates"]), "to": max(item["dates"])}
        competition_summary = {}
        for (sp, competition), item in by_competition.items():
            competition_summary.setdefault(sp, []).append({
                "competition": competition, "matches": item["matches"],
                "teams": len(item["teams"]), "sources": sorted(item["sources"]),
                "from": min(item["dates"]), "to": max(item["dates"])
            })
        for values in competition_summary.values():
            values.sort(key=lambda x: (-x["matches"], x["competition"].casefold()))
        team_rows = [{"sport": sp, "team": name, "matches": count} for (sp, name), count in teams.items()]
        team_rows.sort(key=lambda x: (x["sport"], -x["matches"], x["team"].casefold()))
        return {"total_matches": len(rows), "total_teams": len(teams),
                "sources": sorted(sources), "sports": summary,
                "competitions": competition_summary, "teams": team_rows}


    def has_provider_sync(self, provider, sport, requested_date):
        with self.lock:
            row = self.conn.execute(
                "SELECT status FROM provider_sync_log WHERE provider=? AND sport=? AND requested_date=?",
                (provider, sport, requested_date)).fetchone()
            return bool(row and row["status"] == "success")

    def record_provider_sync(self, provider, sport, requested_date, records_count, status="success"):
        with self.lock:
            self.conn.execute("""INSERT INTO provider_sync_log
                (provider,sport,requested_date,completed_at,records_count,status)
                VALUES(?,?,?,?,?,?) ON CONFLICT(provider,sport,requested_date) DO UPDATE SET
                completed_at=excluded.completed_at,records_count=excluded.records_count,status=excluded.status""",
                (provider, sport, requested_date, datetime.now(timezone.utc).isoformat(),
                 max(0, int(records_count)), status))
            self.conn.commit()

    def provider_sync_history(self, provider=None, sport=None, limit=100):
        sql = "SELECT * FROM provider_sync_log WHERE 1=1"
        args = []
        if provider:
            sql += " AND provider=?"; args.append(provider)
        if sport:
            sql += " AND sport=?"; args.append(sport)
        sql += " ORDER BY completed_at DESC LIMIT ?"; args.append(max(1, int(limit)))
        with self.lock:
            return [dict(row) for row in self.conn.execute(sql, args).fetchall()]

    def save_player_observation(self, record):
        required=("id","sport","player_id","team_name","observed_at","source","stats")
        if any(k not in record for k in required):
            raise ValueError("Observación de jugador incompleta")
        if record["sport"] not in ("football","basketball","baseball"):
            raise ValueError("Deporte no soportado")
        dt=datetime.fromisoformat(record["observed_at"].replace("Z","+00:00"))
        if dt.tzinfo is None:
            raise ValueError("observed_at debe incluir zona horaria")
        with self.lock:
            self.conn.execute("""INSERT OR REPLACE INTO player_observations
              VALUES(?,?,?,?,?,?,?)""",(record["id"],record["sport"],record["player_id"],
              record["team_name"],record["observed_at"],record["source"],json.dumps(record["stats"])))
            self.conn.commit()

    def player_observations_before(self, sport, player_id, cutoff_utc, limit=10):
        cutoff=datetime.fromisoformat(cutoff_utc.replace("Z","+00:00"))
        if cutoff.tzinfo is None:
            raise ValueError("cutoff debe incluir zona horaria")
        with self.lock:
            rows=self.conn.execute("""SELECT * FROM player_observations
              WHERE sport=? AND player_id=? ORDER BY observed_at DESC""",(sport,player_id)).fetchall()
        out=[]
        for row in rows:
            dt=datetime.fromisoformat(row["observed_at"].replace("Z","+00:00"))
            if dt.tzinfo is not None and dt < cutoff:
                item=dict(row); item["stats"]=json.loads(item.pop("stats_json")); out.append(item)
            if len(out)>=limit: break
        return out

    def player_observations_for_name_before(self, sport, player_name, cutoff_utc, limit=10):
        cutoff=datetime.fromisoformat(cutoff_utc.replace("Z", "+00:00"))
        if cutoff.tzinfo is None:
            raise ValueError("cutoff debe incluir zona horaria")
        with self.lock:
            rows=self.conn.execute("""SELECT * FROM player_observations
              WHERE sport=? ORDER BY observed_at DESC""",(sport,)).fetchall()
        out=[]
        wanted=str(player_name).strip().casefold()
        for row in rows:
            observed=datetime.fromisoformat(row["observed_at"].replace("Z", "+00:00"))
            stats=json.loads(row["stats_json"])
            if observed.tzinfo is not None and observed < cutoff and str(stats.get("player_name", "")).strip().casefold()==wanted:
                item=dict(row); item["stats"]=stats; out.append(item)
                if len(out)>=max(1,int(limit)): break
        return out

    def save_availability_report(self, report):
        required=("id","match_id","team_side","status","source","published_at","payload")
        if any(k not in report for k in required):
            raise ValueError("Informe de disponibilidad incompleto")
        if report["team_side"] not in ("home","away"):
            raise ValueError("team_side inválido")
        dt=datetime.fromisoformat(report["published_at"].replace("Z","+00:00"))
        if dt.tzinfo is None: raise ValueError("published_at debe incluir zona horaria")
        with self.lock:
            self.conn.execute("""INSERT OR REPLACE INTO availability_reports
              VALUES(?,?,?,?,?,?,?)""",(report["id"],report["match_id"],report["team_side"],
              report["status"],report["source"],report["published_at"],json.dumps(report["payload"])))
            self.conn.commit()

    def latest_availability_reports(self, match_id, before_utc):
        cutoff=datetime.fromisoformat(before_utc.replace("Z","+00:00"))
        with self.lock:
            rows=self.conn.execute("""SELECT * FROM availability_reports
              WHERE match_id=? ORDER BY published_at DESC""",(match_id,)).fetchall()
        result=[]
        for row in rows:
            dt=datetime.fromisoformat(row["published_at"].replace("Z","+00:00"))
            if dt.tzinfo is not None and dt < cutoff:
                item=dict(row); item["payload"]=json.loads(item.pop("payload_json")); result.append(item)
        return result

    def save_injury_observations(self, match_id, reports):
        """Guarda observaciones de lesiones con timestamp de consulta al proveedor."""
        inserted = 0
        with self.lock:
            for report in reports:
                observed = report.get("provider_observed_at")
                if not observed:
                    continue
                dt = datetime.fromisoformat(observed.replace("Z", "+00:00"))
                if dt.tzinfo is None:
                    continue
                player_id = str(report.get("player_id") or "")
                player_name = str(report.get("player_name") or "").strip()
                team_name = str(report.get("team_name") or "").strip()
                if not player_name or not team_name:
                    continue
                identity = player_id or player_name.casefold()
                record_id = f"{match_id}:{identity}:{observed}"
                cur = self.conn.execute("""INSERT OR IGNORE INTO injury_observations
                  (id,match_id,team_name,player_id,player_name,injury_type,reason,observed_at,source,payload_json)
                  VALUES(?,?,?,?,?,?,?,?,?,?)""",
                  (record_id, match_id, team_name, player_id, player_name,
                   str(report.get("type") or "unknown"), str(report.get("reason") or ""),
                   observed, str(report.get("source") or "unknown"), json.dumps(report)))
                inserted += cur.rowcount
            self.conn.commit()
        return inserted

    def get_injury_observations(self, match_id, before_utc=None):
        cutoff = datetime.fromisoformat(before_utc.replace("Z", "+00:00")) if before_utc else None
        with self.lock:
            rows = self.conn.execute("""SELECT * FROM injury_observations
              WHERE match_id=? ORDER BY observed_at DESC""", (match_id,)).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            observed = datetime.fromisoformat(item["observed_at"].replace("Z", "+00:00"))
            if cutoff is None or (observed.tzinfo is not None and cutoff.tzinfo is not None and observed < cutoff):
                item["payload"] = json.loads(item.pop("payload_json"))
                result.append(item)
        return result

    def close(self):
        with self.lock:
            self.conn.close()

    def save_team_stat_observation(self, record):
        required = ("sport", "team_id", "league_id", "season", "valid_before", "observed_at", "statistics")
        if any(record.get(k) in (None, "") for k in required):
            raise ValueError("Observación estadística incompleta")
        observed = datetime.fromisoformat(record["observed_at"].replace("Z", "+00:00"))
        if observed.tzinfo is None:
            raise ValueError("observed_at debe incluir zona horaria")
        datetime.strptime(record["valid_before"], "%Y-%m-%d").date()
        identity = ":".join(str(record[k]) for k in ("sport", "team_id", "league_id", "season", "valid_before"))
        with self.lock:
            self.conn.execute("""INSERT OR REPLACE INTO team_stat_observations
              (id,sport,team_id,team_name,league_id,competition,season,valid_before,observed_at,source,stats_json)
              VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
              (identity, record["sport"], str(record["team_id"]), str(record.get("team_name") or ""),
               str(record["league_id"]), str(record.get("competition") or ""), str(record["season"]),
               record["valid_before"], record["observed_at"], str(record.get("source") or "unknown"),
               json.dumps(record["statistics"], ensure_ascii=False)))
            self.conn.commit()
        return identity

    def get_team_stat_observation(self, sport, team_id, league_id, season, before_utc):
        cutoff = datetime.fromisoformat(before_utc.replace("Z", "+00:00"))
        if cutoff.tzinfo is None:
            raise ValueError("El corte del partido debe incluir zona horaria")
        with self.lock:
            rows = self.conn.execute("""SELECT * FROM team_stat_observations
              WHERE sport=? AND team_id=? AND league_id=? AND season=?
              ORDER BY valid_before DESC, observed_at DESC""",
              (sport, str(team_id), str(league_id), str(season))).fetchall()
        for row in rows:
            valid = datetime.strptime(row["valid_before"], "%Y-%m-%d").date()
            observed = datetime.fromisoformat(row["observed_at"].replace("Z", "+00:00"))
            if valid < cutoff.date() and observed < cutoff:
                item = dict(row); item["statistics"] = json.loads(item.pop("stats_json"))
                return item
        return None
