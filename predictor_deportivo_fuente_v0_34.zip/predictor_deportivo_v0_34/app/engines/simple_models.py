import random, math

def _poisson(lam, rng):
    limit = math.exp(-lam); k=0; p=1.0
    while p > limit:
        k += 1; p *= rng.random()
    return k-1

def project_match(sport, data, simulations, seed=None):
    if not 1000 <= simulations <= 50000:
        raise ValueError("Simulaciones permitidas: 1.000 a 50.000")
    rng = random.Random(seed)
    if sport == "football":
        h, a = float(data["home"]["expected_goals"]), float(data["away"]["expected_goals"])
        hw=dr=aw=0; goals=0
        for _ in range(simulations):
            x,y=_poisson(h,rng),_poisson(a,rng); goals += x+y
            if x>y: hw+=1
            elif x==y: dr+=1
            else: aw+=1
        return {"home_win":hw/simulations,"draw":dr/simulations,"away_win":aw/simulations,
                "expected_total_goals":goals/simulations,"model":"poisson_baseline"}
    if sport == "basketball":
        h,a=float(data["home"]["expected_points"]),float(data["away"]["expected_points"])
        hw=aw=0; hs=as_=0
        for _ in range(simulations):
            x=max(0,round(rng.gauss(h,11))); y=max(0,round(rng.gauss(a,11)))
            if x>y: hw+=1
            elif y>x: aw+=1
            else:
                if rng.random()<.5: hw+=1
                else: aw+=1
            hs+=x; as_+=y
        return {"home_win":hw/simulations,"away_win":aw/simulations,
                "expected_home_points":hs/simulations,"expected_away_points":as_/simulations,
                "model":"normal_score_baseline"}
    if sport == "baseball":
        h,a=float(data["home"]["expected_runs"]),float(data["away"]["expected_runs"])
        hw=aw=0; hr=ar=0
        for _ in range(simulations):
            x,y=_poisson(h,rng),_poisson(a,rng)
            if x==y:
                if rng.random()<.5: x+=1
                else: y+=1
            if x>y: hw+=1
            else: aw+=1
            hr+=x; ar+=y
        return {"home_win":hw/simulations,"away_win":aw/simulations,
                "expected_home_runs":hr/simulations,"expected_away_runs":ar/simulations,
                "model":"poisson_run_baseline"}
    raise ValueError("Deporte no soportado")
