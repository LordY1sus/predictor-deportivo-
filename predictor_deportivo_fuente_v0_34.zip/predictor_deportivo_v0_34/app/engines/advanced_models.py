"""Motores de simulación mejorados. No sustituyen calibración con históricos."""
import math
import random

def _poisson_pmf(lam, k):
    return math.exp(-lam + k*math.log(lam) - math.lgamma(k+1)) if lam > 0 else (1.0 if k == 0 else 0.0)

def _football(data, simulations, rng):
    home, away = data["home"], data["away"]
    # Ajustes transparentes de las cuatro capas: base, alineación, contexto y forma.
    def adjusted(team, side):
        base=float(team["expected_goals"])
        factors=data.get("adjustments",{}).get(side,{})
        value=base
        for key in ("lineup","context","form"):
            value *= float(factors.get(key,1.0))
        return min(5.0,max(0.05,value))
    lh,la=adjusted(home,"home"),adjusted(away,"away")
    rho=float(data.get("dixon_coles_rho",-0.08))
    max_goals=12
    cells=[]
    total=0.0
    for h in range(max_goals+1):
        ph=_poisson_pmf(lh,h)
        for a in range(max_goals+1):
            p=ph*_poisson_pmf(la,a)
            # Dixon-Coles: corrección de marcadores bajos 0-0, 0-1, 1-0 y 1-1.
            if h==0 and a==0: tau=1-lh*la*rho
            elif h==0 and a==1: tau=1+lh*rho
            elif h==1 and a==0: tau=1+la*rho
            elif h==1 and a==1: tau=1-rho
            else: tau=1.0
            p=max(0.0,p*tau)
            cells.append((h,a,p)); total+=p
    if total <= 0: raise ValueError("Parámetros Dixon-Coles inválidos")
    weights=[c[2]/total for c in cells]
    # Muestreo Monte Carlo de la distribución corregida.
    cumulative=[]; acc=0.0
    for w in weights:
        acc+=w; cumulative.append(acc)
    hw=dr=aw=gh=0
    for _ in range(simulations):
        u=rng.random()
        lo,hi=0,len(cumulative)-1
        while lo<hi:
            mid=(lo+hi)//2
            if u<=cumulative[mid]: hi=mid
            else: lo=mid+1
        h,a,_=cells[lo]
        gh+=h+a
        if h>a: hw+=1
        elif h==a: dr+=1
        else: aw+=1
    return {"home_win":hw/simulations,"draw":dr/simulations,"away_win":aw/simulations,
            "expected_total_goals":gh/simulations,"expected_home_goals":lh,
            "expected_away_goals":la,"model":"dixon_coles_monte_carlo"}

def _basketball(data, simulations, rng):
    h,a=data["home"],data["away"]
    pace=float(data.get("pace",99.0))
    if not 70 <= pace <= 115: raise ValueError("Pace debe estar entre 70 y 115 posesiones")
    def expected(team, side):
        base=float(team["expected_points"])
        factors=data.get("adjustments",{}).get(side,{})
        # Efecto de alineación, contexto y forma; valores relativos.
        for key in ("lineup","context","form"):
            base*=float(factors.get(key,1.0))
        return min(180.0,max(50.0,base))
    hp,ap=expected(h,"home"),expected(a,"away")
    base_pace=float(data.get("reference_pace",99.0))
    scale=pace/base_pace
    hp*=scale; ap*=scale
    # Variación común del ritmo induce correlación entre marcadores.
    hw=aw=hs=as_=0
    for _ in range(simulations):
        pace_noise=rng.gauss(1.0,0.035)
        x=max(0,round(rng.gauss(hp*pace_noise,10.5)))
        y=max(0,round(rng.gauss(ap*pace_noise,10.5)))
        if x==y:
            if rng.random()<0.5: x+=1
            else: y+=1
        if x>y: hw+=1
        else: aw+=1
        hs+=x; as_+=y
    return {"home_win":hw/simulations,"away_win":aw/simulations,
            "expected_home_points":hs/simulations,"expected_away_points":as_/simulations,
            "pace":pace,"model":"pace_adjusted_efficiency_monte_carlo"}

def _half_inning(expected_runs, rng):
    # Modelo simplificado de estados de bases y outs; no incorpora reglas particulares
    # de cada liga ni datos de bateadores. Se escala a la expectativa suministrada.
    scale=max(0.55,min(1.65,expected_runs/4.5))
    probs=[0.68,0.08*scale,0.15*scale,0.05*scale,0.005*scale,0.035*scale]
    norm=sum(probs); probs=[p/norm for p in probs]
    runs=outs=0
    bases=[False,False,False]
    while outs<3:
        u=rng.random(); cum=0; event=0
        for i,p in enumerate(probs):
            cum+=p
            if u<=cum: event=i; break
        if event==0:
            outs+=1
        elif event==1: # base por bolas: avance forzado
            if bases[0] and bases[1] and bases[2]: runs+=1
            bases=[True, bases[0] or bases[1], bases[2] or (bases[0] and bases[1])]
        elif event in (2,3,4): # hit sencillo/doble/triple
            advance={2:1,3:2,4:3}[event]
            new=[False,False,False]
            for idx,occupied in enumerate(bases):
                if occupied:
                    dest=idx+advance
                    if dest>=3: runs+=1
                    else: new[dest]=True
            new[min(2,advance-1)]=True
            bases=new
        else: # cuadrangular
            runs+=1+sum(bases); bases=[False,False,False]
    return runs

def _baseball(data, simulations, rng):
    h,a=data["home"],data["away"]
    hr=float(h["expected_runs"]); ar=float(a["expected_runs"])
    factors=data.get("adjustments",{})
    hr*=float(factors.get("home",{}).get("lineup",1))*float(factors.get("home",{}).get("context",1))*float(factors.get("home",{}).get("form",1))
    ar*=float(factors.get("away",{}).get("lineup",1))*float(factors.get("away",{}).get("context",1))*float(factors.get("away",{}).get("form",1))
    wins_h=wins_a=total_h=total_a=0
    for _ in range(simulations):
        rh=ra=0
        # Nueve entradas reglamentarias; desempate simplificado por una carrera.
        for _inning in range(9):
            rh+=_half_inning(hr,rng); ra+=_half_inning(ar,rng)
        if rh==ra:
            if rng.random()<0.5: rh+=1
            else: ra+=1
        if rh>ra: wins_h+=1
        else: wins_a+=1
        total_h+=rh; total_a+=ra
    return {"home_win":wins_h/simulations,"away_win":wins_a/simulations,
            "expected_home_runs":total_h/simulations,"expected_away_runs":total_a/simulations,
            "model":"base_out_state_monte_carlo_approx"}

def project_match(sport, data, simulations, seed=None):
    if not 1000 <= simulations <= 50000:
        raise ValueError("Simulaciones permitidas: 1.000 a 50.000")
    rng=random.Random(seed)
    if sport=="football": return _football(data,simulations,rng)
    if sport=="basketball": return _basketball(data,simulations,rng)
    if sport=="baseball": return _baseball(data,simulations,rng)
    raise ValueError("Deporte no soportado")
