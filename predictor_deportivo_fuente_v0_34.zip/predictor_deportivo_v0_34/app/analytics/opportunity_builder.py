"""Ranking de EV positivo con correspondencia exacta de mercado y cuota fresca."""
from datetime import datetime, timezone
from app.analytics.ev import evaluate


def build_opportunities(match, projection, odds_rows, kelly_fraction=0.25,
                        now_utc=None, max_age_minutes=360):
    sport = match["sport"]
    if sport == "football":
        selections = {
            "home_win": ("h2h", match["home_name"]),
            "draw": ("h2h", "Draw"),
            "away_win": ("h2h", match["away_name"]),
        }
    elif sport in ("basketball", "baseball"):
        selections = {
            "home_win": ("h2h", match["home_name"]),
            "away_win": ("h2h", match["away_name"]),
        }
    else:
        return []

    now = now_utc or datetime.now(timezone.utc)
    if now.tzinfo is None or now.utcoffset() is None:
        raise ValueError("now_utc debe incluir zona horaria")
    try:
        kickoff = datetime.fromisoformat(str(match["kickoff_utc"]).replace("Z", "+00:00"))
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError("El partido requiere kickoff_utc válido") from exc
    if kickoff.tzinfo is None or kickoff.utcoffset() is None:
        raise ValueError("kickoff_utc debe incluir zona horaria")
    now = now.astimezone(timezone.utc)
    kickoff = kickoff.astimezone(timezone.utc)
    # Este constructor solo genera oportunidades prepartido; nunca recicla
    # cuotas de un partido ya iniciado ni cuotas capturadas después del kickoff.
    if now >= kickoff:
        return []
    results = []
    for key, (market, selection) in selections.items():
        probability = projection.get(key)
        if not isinstance(probability, (int, float)) or not 0 < probability < 1:
            continue
        matching = [q for q in odds_rows
                    if q["market"] == market and q["selection"] == selection
                    and q.get("line") is None]
        for quote in matching:
            try:
                captured = datetime.fromisoformat(quote["captured_at"].replace("Z", "+00:00"))
                if captured.tzinfo is None or captured.utcoffset() is None:
                    continue
                captured = captured.astimezone(timezone.utc)
                if captured >= kickoff:
                    continue
                age_minutes = (now - captured).total_seconds() / 60
                if age_minutes < 0 or age_minutes > max_age_minutes:
                    continue
                calc = evaluate(float(probability), float(quote["decimal_odds"]), kelly_fraction)
            except (KeyError, TypeError, ValueError, AttributeError):
                continue
            if calc["eligible"]:
                results.append({
                    "match_id": match["id"], "sport": sport, "market": market,
                    "selection": selection, "decimal_odds": float(quote["decimal_odds"]),
                    "bookmaker": quote.get("bookmaker", "unknown"),
                    "provider": quote.get("provider", "unknown"),
                    "captured_at": quote["captured_at"], "age_minutes": round(age_minutes, 1),
                    "projection_probability": probability, **calc
                })
    return sorted(results, key=lambda x: (x["expected_value"], x["kelly_fractional"]), reverse=True)
