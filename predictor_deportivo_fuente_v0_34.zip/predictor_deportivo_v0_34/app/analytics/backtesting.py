"""Métricas de evaluación de pronósticos cerrados; no estiman rentabilidad futura."""
import math


def _calibration_summary(confidences, outcomes, bins=10):
    """ECE por bins uniformes. En multicategoría usa confianza de la clase elegida."""
    if not confidences:
        return {"expected_calibration_error": None, "calibration_bins": []}
    buckets = [[] for _ in range(bins)]
    for confidence, outcome in zip(confidences, outcomes):
        index = min(bins - 1, int(float(confidence) * bins))
        buckets[index].append((float(confidence), int(outcome)))
    total = len(confidences)
    ece = 0.0
    details = []
    for index, bucket in enumerate(buckets):
        if not bucket:
            continue
        mean_confidence = sum(x[0] for x in bucket) / len(bucket)
        observed_rate = sum(x[1] for x in bucket) / len(bucket)
        ece += len(bucket) / total * abs(mean_confidence - observed_rate)
        details.append({
            "lower_bound": index / bins,
            "upper_bound": (index + 1) / bins,
            "samples": len(bucket),
            "mean_confidence": mean_confidence,
            "observed_rate": observed_rate,
        })
    return {"expected_calibration_error": ece, "calibration_bins": details}


def evaluate_multiclass(predictions):
    """Cada fila: probabilities dict y outcome ('home_win','draw','away_win')."""
    if not predictions:
        return {"samples": 0, "brier_score": None, "log_loss": None,
                "accuracy": None, **_calibration_summary([], [])}
    keys = ("home_win", "draw", "away_win")
    brier = logloss = correct = 0.0
    confidences, hits = [], []
    for row in predictions:
        probs = row["probabilities"]
        outcome = row["outcome"]
        if outcome not in keys:
            raise ValueError("Resultado no reconocido")
        values = [float(probs.get(k, 0.0)) for k in keys]
        if any(not math.isfinite(p) or p < 0 or p > 1 for p in values) or abs(sum(values) - 1) > 1e-6:
            raise ValueError("Las probabilidades deben sumar 1")
        for key, p in zip(keys, values):
            target = 1.0 if key == outcome else 0.0
            brier += (p - target) ** 2
        logloss -= math.log(max(1e-15, float(probs[outcome])))
        predicted = max(keys, key=lambda k: probs.get(k, 0.0))
        hit = int(predicted == outcome)
        correct += hit
        confidences.append(max(values))
        hits.append(hit)
    n = len(predictions)
    return {"samples": n, "brier_score": brier / (n * 3), "log_loss": logloss / n,
            "accuracy": correct / n, **_calibration_summary(confidences, hits)}


def evaluate_binary(predictions):
    """Cada fila: probability y outcome booleano/0-1; probability es P(home_win)."""
    if not predictions:
        return {"samples": 0, "brier_score": None, "log_loss": None,
                "accuracy": None, **_calibration_summary([], [])}
    brier = logloss = correct = 0.0
    probabilities, outcomes = [], []
    for row in predictions:
        p = float(row["probability"])
        y = int(row["outcome"])
        if not math.isfinite(p) or not 0 <= p <= 1 or y not in (0, 1):
            raise ValueError("Probabilidad o resultado binario inválido")
        brier += (p - y) ** 2
        logloss -= math.log(max(1e-15, p if y else 1 - p))
        correct += int((p >= 0.5) == bool(y))
        probabilities.append(p)
        outcomes.append(y)
    n = len(predictions)
    return {"samples": n, "brier_score": brier / n, "log_loss": logloss / n,
            "accuracy": correct / n, **_calibration_summary(probabilities, outcomes)}
