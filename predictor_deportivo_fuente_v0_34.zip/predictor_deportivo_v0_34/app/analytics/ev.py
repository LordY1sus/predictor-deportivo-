def evaluate(probability, decimal_odds, fraction=0.25):
    if not 0 < probability < 1 or decimal_odds <= 1 or not 0 < fraction <= 1:
        raise ValueError("Probabilidad, cuota o fracción Kelly inválida")
    implied=1/decimal_odds
    ev=probability*decimal_odds-1
    full=max(0.0,(probability*decimal_odds-1)/(decimal_odds-1))
    return {"model_probability":probability,"implied_probability":implied,
            "edge":probability-implied,"expected_value":ev,
            "kelly_full":full,"kelly_fractional":full*fraction,
            "eligible":ev>0}
