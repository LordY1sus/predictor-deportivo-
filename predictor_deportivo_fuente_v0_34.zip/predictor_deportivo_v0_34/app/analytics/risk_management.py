"""Conservative bankroll-risk calculations; informational only, never places bets."""
from __future__ import annotations

import math
from typing import Iterable, Mapping, Any


def _finite_number(name: str, value: Any) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} debe ser numérico") from exc
    if not math.isfinite(number):
        raise ValueError(f"{name} debe ser finito")
    return number


def calculate_stake(
    bankroll: float,
    probability: float,
    decimal_odds: float,
    *,
    kelly_fraction: float = 0.25,
    max_stake_pct: float = 0.01,
) -> dict[str, float | bool]:
    """Return a capped Kelly stake. No positive edge means a zero stake."""
    bank = _finite_number("bankroll", bankroll)
    prob = _finite_number("probability", probability)
    odds = _finite_number("decimal_odds", decimal_odds)
    fraction = _finite_number("kelly_fraction", kelly_fraction)
    cap_pct = _finite_number("max_stake_pct", max_stake_pct)
    if bank <= 0:
        raise ValueError("bankroll debe ser mayor que cero")
    if not 0 < prob < 1:
        raise ValueError("probability debe estar entre 0 y 1")
    if odds <= 1:
        raise ValueError("decimal_odds debe ser mayor que 1")
    if not 0 < fraction <= 1:
        raise ValueError("kelly_fraction debe estar entre 0 y 1")
    if not 0 < cap_pct <= 1:
        raise ValueError("max_stake_pct debe estar entre 0 y 1")

    ev = prob * odds - 1.0
    full_kelly = max(0.0, ev / (odds - 1.0))
    raw_fractional = bank * full_kelly * fraction
    cap = bank * cap_pct
    stake = min(raw_fractional, cap) if ev > 0 else 0.0
    return {
        "expected_value": ev,
        "kelly_full_pct": full_kelly,
        "kelly_fractional_pct": full_kelly * fraction,
        "stake": stake,
        "stake_pct": stake / bank,
        "cap": cap,
        "eligible": ev > 0,
    }


def simulate_bankroll(
    initial_bankroll: float,
    bets: Iterable[Mapping[str, Any]],
) -> dict[str, float | int]:
    """Replay supplied settled bets chronologically; outcomes must be explicit."""
    initial = _finite_number("initial_bankroll", initial_bankroll)
    if initial <= 0:
        raise ValueError("initial_bankroll debe ser mayor que cero")
    balance = peak = initial
    max_drawdown = 0.0
    count = wins = losses = pushes = 0
    for index, bet in enumerate(bets):
        stake = _finite_number(f"bets[{index}].stake", bet.get("stake"))
        odds = _finite_number(f"bets[{index}].decimal_odds", bet.get("decimal_odds"))
        outcome = str(bet.get("outcome", "")).lower()
        if stake < 0 or stake > balance:
            raise ValueError("cada stake debe ser no negativo y no superar la banca disponible")
        if odds <= 1:
            raise ValueError("decimal_odds debe ser mayor que 1")
        if outcome not in {"win", "loss", "push"}:
            raise ValueError("outcome debe ser win, loss o push")
        if outcome == "win":
            balance += stake * (odds - 1)
            wins += 1
        elif outcome == "loss":
            balance -= stake
            losses += 1
        else:
            pushes += 1
        count += 1
        peak = max(peak, balance)
        if peak > 0:
            max_drawdown = max(max_drawdown, (peak - balance) / peak)
    return {
        "initial_bankroll": initial,
        "ending_bankroll": balance,
        "net_profit": balance - initial,
        "max_drawdown_pct": max_drawdown,
        "bets_count": count,
        "wins": wins,
        "losses": losses,
        "pushes": pushes,
    }
