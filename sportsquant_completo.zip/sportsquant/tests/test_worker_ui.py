import dataclasses
import threading
import time
import types
from datetime import datetime, timedelta, timezone

import flet as ft
import pytest

from sportsquant.core.enums import MatchStatus, Sport
from sportsquant.core.models import RawMatch, Team
from sportsquant.data.storage import Storage
from sportsquant.matches.providers.base import ProviderError
from sportsquant.matches.providers.static_provider import StaticProvider
from sportsquant.matches.service import MatchService
from sportsquant.projection.engine import ProjectionEngine
from sportsquant.settings import UserSettings, load_settings, save_settings
from sportsquant.ui import components
from sportsquant.ui.app import SportsQuantApp
from sportsquant.workers.projection_worker import ProjectionWorker, ProjState
from .factories import make_lineup
from .synth import KICK, T0, football_ctx


class Clock:
    def __init__(self, now): self.now = now
    def __call__(self): return self.now


class StubFactory:
    """Constructor de contexto falso: devuelve el contexto sintético del partido pedido."""
    def __init__(self, clock=None, advance_to=None, error=None, gate=None):
        self.calls, self.clock, self.advance_to, self.error, self.gate = [], clock, advance_to, error, gate

    def build(self, match, asof):
        self.calls.append(match.match_id)
        if self.gate is not None:
            self.gate.wait(5)
        if self.advance_to is not None:
            self.clock.now = self.advance_to  # el tiempo pasa durante la descarga de datos
        if self.error is not None:
            raise self.error
        return dataclasses.replace(football_ctx(), match=match, asof=asof)


def raw(match_id="m1", lineups=True, status="NS"):
    return RawMatch(
        match_id, Sport.FOOTBALL, "Liga", KICK, Team("T1", "Local", "LOC"), Team("T2", "Visita", "VIS"), status,
        home_lineup=make_lineup(Sport.FOOTBALL, "T1") if lineups else None,
        away_lineup=make_lineup(Sport.FOOTBALL, "T2") if lineups else None,
    )


def make_service(raws, clock):
    svc = MatchService(StaticProvider(raws), clock=clock)
    svc._settings = types.SimpleNamespace(tz=lambda: timezone.utc, include_live_carryover=True)
    svc.refresh(Sport.FOOTBALL)
    return svc


def make_worker(raws=None, factory=None, clock=None):
    clock = clock or Clock(T0)
    svc = make_service(raws if raws is not None else [raw()], clock)
    storage = Storage()
    worker = ProjectionWorker(svc, factory or StubFactory(), ProjectionEngine(), storage, clock=clock)
    return worker, svc, storage, clock


# ------------------------------------------------------------------------ worker
def test_worker_success_saves_projection_and_clamps_simulations():
    worker, svc, storage, _ = make_worker()
    seen = []
    st = worker.submit("m1", 10, listener=lambda mid, s: seen.append(s.state), seed=3, wait=True)
    assert st.state is ProjState.DONE and st.result.n_simulations == 1_000
    assert sum(st.result.probs.values()) == pytest.approx(1.0)
    assert storage.load_projection("m1") == st.result
    assert seen == [ProjState.QUEUED, ProjState.RUNNING, ProjState.DONE]
    worker.shutdown()


def test_worker_blocks_without_official_lineups_and_never_builds_context():
    factory = StubFactory()
    worker, *_ = make_worker([raw(lineups=False)], factory)
    st = worker.submit("m1", 5_000, wait=True)
    assert st.state is ProjState.BLOCKED and "LINEUP_REQUIRED" in st.message and factory.calls == []
    assert worker.submit("nope", 5_000).state is ProjState.BLOCKED
    worker.shutdown()


def test_worker_ignores_double_click_while_busy():
    gate = threading.Event()
    factory = StubFactory(gate=gate)
    worker, *_ = make_worker(factory=factory)
    first = worker.submit("m1", 3_000)
    assert first.busy
    second = worker.submit("m1", 3_000)  # doble toque
    assert second.busy
    gate.set()
    deadline = time.time() + 5
    while worker.status("m1").busy and time.time() < deadline:
        time.sleep(0.01)
    assert worker.status("m1").state is ProjState.DONE and factory.calls == ["m1"]
    worker.shutdown()


def test_worker_rechecks_t_lt_T_after_slow_data_download():
    clock = Clock(T0)
    factory = StubFactory(clock=clock, advance_to=KICK + timedelta(minutes=1))
    worker, _, storage, _ = make_worker(factory=factory, clock=clock)
    st = worker.submit("m1", 3_000, wait=True)
    assert st.state is ProjState.BLOCKED and "t < T" in st.message
    assert storage.load_projection("m1") is None  # nunca se simuló
    worker.shutdown()


def test_worker_reports_errors_without_dying():
    worker, *_ = make_worker(factory=StubFactory(error=ProviderError("ESPN caído")))
    assert worker.submit("m1", 2_000, wait=True).message == "ESPN caído"
    worker2, *_ = make_worker(factory=StubFactory(error=ZeroDivisionError("boom")))
    st = worker2.submit("m1", 2_000, wait=True)
    assert st.state is ProjState.ERROR and "inesperado" in st.message
    assert worker2.submit("m1", 2_000, wait=True).state is ProjState.ERROR  # el hilo sigue vivo
    worker.shutdown(); worker2.shutdown()


def test_refreshing_matches_never_triggers_projections():
    factory = StubFactory()
    worker, svc, *_ = make_worker(factory=factory)
    for _ in range(3):
        svc.refresh(Sport.FOOTBALL)
    assert factory.calls == [] and worker.status("m1").state is ProjState.IDLE  # cero ejecución automática
    worker.shutdown()


# -------------------------------------------------------------------- ajustes
def test_user_settings_roundtrip_and_sanitizing():
    st = Storage()
    s = UserSettings(n_simulations=10**9, kelly_multiplier=5, stake_cap=0.9, football_leagues=["", " eng.1 "], auto_refresh_seconds=1, sport="cricket")
    save_settings(st, s)
    got = load_settings(st)
    assert got.n_simulations == 50_000 and got.kelly_multiplier == 1.0 and got.stake_cap == 0.25
    assert got.football_leagues == ["eng.1"] and got.auto_refresh_seconds == 20 and got.sport == "football"
    assert load_settings(Storage()).n_simulations == 10_000


# ---------------------------------------------------------------------------- UI
class FakePage:
    def __init__(self):
        self.controls, self.dialogs, self.updates = [], [], 0

    def add(self, *c): self.controls.extend(c)
    def update(self, *a): self.updates += 1
    def run_thread(self, fn, *a, **k): fn(*a, **k)
    def show_dialog(self, d): self.dialogs.append(d)
    def pop_dialog(self): return self.dialogs.pop() if self.dialogs else None


def make_app(raws=None):
    clock = Clock(T0)
    worker, svc, storage, _ = make_worker(raws, clock=clock)
    services = types.SimpleNamespace(storage=storage, matches=svc, worker=worker, settings=UserSettings(),
                                     apply_leagues=lambda leagues: setattr(services, "leagues", leagues))
    page = FakePage()
    app = SportsQuantApp(page, services)
    app._tz_settings = types.SimpleNamespace(tz=lambda: timezone.utc)
    return app, page, services


def walk(control):
    """Itera todos los controles hijos (para buscar textos/botones en pruebas)."""
    yield control
    for attr in ("controls", "content"):
        child = getattr(control, attr, None)
        if isinstance(child, list):
            for c in child:
                yield from walk(c)
        elif child is not None and not isinstance(child, (str, int, float)):
            yield from walk(child)


def texts(control):
    return [c.value for c in walk(control) if isinstance(c, ft.Text) and c.value]


def wait_idle(worker, match_id, timeout=5):
    end = time.time() + timeout
    while worker.status(match_id).busy and time.time() < end:
        time.sleep(0.01)


def test_app_start_shows_cartelera_with_enabled_button_and_lineup_chip():
    app, page, svc = make_app()
    app.start()
    app.stop()
    assert page.controls and app.status.value.startswith("1 partidos hoy")
    card = app.matches_col.controls[0]
    assert isinstance(card, ft.Card)
    all_text = " ".join(texts(card))
    assert "Local  vs  Visita" in all_text and "ALINEACIÓN OFICIAL" in all_text and "SCHEDULED" in all_text
    button = next(c for c in walk(card) if isinstance(c, ft.Button))
    assert button.content == "Proyectar" and not button.disabled
    assert "Sin apuestas" in " ".join(texts(app.ranking_col))
    svc.worker.shutdown()


def test_app_disables_project_button_until_lineups_official_and_shows_reason():
    app, _, svc = make_app([raw(lineups=False)])
    app.start(); app.stop()
    card = app.matches_col.controls[0]
    button = next(c for c in walk(card) if isinstance(c, ft.Button))
    assert button.disabled and "ALINEACIÓN PENDIENTE" in " ".join(texts(card))
    assert any("LINEUP_REQUIRED" in t for t in texts(card))
    svc.worker.shutdown()


def test_app_project_flow_then_ranking_and_result_panel():
    app, page, svc = make_app()
    app.start(); app.stop()
    svc.storage.set_manual_odds("m1", "HOME", 80.0)  # cuota exagerada → EV > 0 seguro
    svc.storage.set_manual_odds("m1", "DRAW", 15.0)
    svc.storage.set_manual_odds("m1", "AWAY", 15.0)
    app._on_project("m1")
    wait_idle(svc.worker, "m1")
    app.render()
    assert svc.worker.status("m1").state is ProjState.DONE
    card = app.matches_col.controls[0]
    tile = next(c for c in walk(card) if isinstance(c, ft.ExpansionTile))
    body = " ".join(texts(tile))
    assert "Marcador esperado" in body and "L4 base" in body and "L1 alineación" in body and "simulaciones" in body
    ranking_text = " ".join(texts(app.ranking_col))
    assert "1." in ranking_text and "@" in ranking_text and "Kelly fraccionado" in ranking_text
    svc.worker.shutdown()


def test_app_edit_odds_dialog_validates_and_saves():
    app, page, svc = make_app()
    app.start(); app.stop()
    app._edit_odds("m1")
    dialog = page.dialogs[-1]
    fields = [c for c in walk(dialog.content) if isinstance(c, ft.TextField)]
    assert [f.label for f in fields] == ["Gana LOC", "Empate", "Gana VIS"]
    save = dialog.actions[1].on_click
    fields[0].value = "abc"
    save(None)
    assert svc.storage.manual_odds("m1") == {} and any("inválida" in t for t in texts(dialog.content))
    fields[0].value, fields[1].value, fields[2].value = "2,10", "3.4", ""
    save(None)
    assert svc.storage.manual_odds("m1") == {"HOME": 2.1, "DRAW": 3.4} and not page.dialogs
    assert "LOC 2.10" in " ".join(texts(app.matches_col.controls[0]))
    svc.worker.shutdown()


def test_app_settings_dialog_saves_and_applies_leagues():
    app, page, svc = make_app()
    app.start(); app.stop()
    app._open_settings()
    dialog = page.dialogs[-1]
    kelly, cap, auto, leagues = [c for c in walk(dialog.content) if isinstance(c, (ft.Dropdown, ft.TextField))]
    kelly.value, cap.value, auto.value, leagues.value = "1/2", "3", "90", "eng.1, esp.1\nita.1"
    dialog.actions[1].on_click(None)
    assert svc.settings.kelly_multiplier == 0.5 and svc.settings.stake_cap == pytest.approx(0.03) and svc.settings.auto_refresh_seconds == 90
    assert [x.strip() for x in svc.leagues] == ["eng.1", "esp.1", "ita.1"]
    assert load_settings(svc.storage).kelly_multiplier == 0.5
    svc.worker.shutdown()


def test_app_simulation_slider_updates_label_and_persists():
    app, page, svc = make_app()
    app.start(); app.stop()
    app._on_sims(types.SimpleNamespace(control=types.SimpleNamespace(value=23_400.0)))
    assert app.s.n_simulations == 23_000 and "23,000" in app.sims_label.value
    app._on_sims_end(None)
    assert load_settings(svc.storage).n_simulations == 23_000
    svc.worker.shutdown()


def test_app_live_and_finished_cards():
    live = dataclasses.replace(raw("live", status="2H"), kickoff=T0 - timedelta(minutes=70),
                               score=__import__("sportsquant.core.models", fromlist=["Score"]).Score(2, 1),
                               clock=__import__("sportsquant.core.models", fromlist=["LiveClock"]).LiveClock("70'"))
    done = dataclasses.replace(raw("done", status="FT"), kickoff=T0 - timedelta(hours=3))
    app, _, svc = make_app([live, done, raw("next")])
    app.start(); app.stop()
    cards = app.matches_col.controls
    assert len(cards) == 2  # el FINISHED desaparece
    live_text = " ".join(texts(cards[0]))  # LIVE primero
    assert "LIVE" in live_text and "2 – 1 · 70'" in live_text
    assert not any(isinstance(c, ft.Button) for c in walk(cards[0]))  # LIVE: sin botón Proyectar
    assert any(isinstance(c, ft.Button) for c in walk(cards[1]))
    svc.worker.shutdown()


def test_components_helpers():
    from sportsquant.core.models import OddsLine
    from .synth import make_match
    m = make_match()
    assert components.odds_text(m, []).startswith("Sin cuotas")
    t = components.odds_text(m, [OddsLine("1X2", "HOME", 1.8, "DK"), OddsLine("1X2", "AWAY", 4.0, "DK")])
    assert "T1 1.80" in t and "T2 4.00" in t and "(DK)" in t
    assert components.pct(0.1234) == "12.3%" and components.pitchers_text(m) is None
