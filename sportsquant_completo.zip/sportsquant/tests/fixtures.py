"""Respuestas simuladas con la forma de ESPN y MLB StatsAPI.

La forma de ESPN (evento, competidores, estado, cuotas) replica una respuesta real observada;
`rosters`, `boxscore.players` e `injuries` siguen la forma documentada y se validan con la
herramienta `tools/check_sources.py` contra los servicios en vivo.
"""
from __future__ import annotations

SOCCER_POS = ["G", "RB", "CD-L", "CD-R", "LB", "DM", "CM", "AM", "RW", "LW", "F"]


def espn_event(event_id="401878755", home=("360", "Manchester United", "MAN"), away=("364", "Liverpool", "LIV"), *,
               date="2026-11-22T16:30Z", state="pre", name="STATUS_SCHEDULED", scores=("0", "0"), period=0,
               display_clock="0'", neutral=False, odds=True, league_odds=None):
    comp = {
        "id": event_id, "date": date, "neutralSite": neutral,
        "venue": {"fullName": "Old Trafford", "address": {"city": "Manchester", "country": "England"}},
        "competitors": [
            {"homeAway": "home", "score": scores[0], "team": {"id": home[0], "displayName": home[1], "abbreviation": home[2]}},
            {"homeAway": "away", "score": scores[1], "team": {"id": away[0], "displayName": away[1], "abbreviation": away[2]}},
        ],
    }
    if odds:
        comp["odds"] = league_odds or [{
            "provider": {"name": "ESPN BET"},
            "homeTeamOdds": {"current": {"moneyLine": {"decimal": 1.76, "american": "-130"}}},
            "awayTeamOdds": {"current": {"moneyLine": {"decimal": 4.1, "american": "+310"}}},
            "drawOdds": {"moneyLine": 280},
        }]
    return {"id": event_id, "date": date,
            "status": {"period": period, "displayClock": display_clock, "type": {"name": name, "state": state, "completed": state == "post"}},
            "competitions": [comp]}


def scoreboard(*events, league_name="English Premier League"):
    return {"leagues": [{"name": league_name}], "events": list(events)}


def soccer_roster(team_id, *, starters=11, bench=5, apps=20):
    rows = []
    for i in range(starters + bench):
        rows.append({
            "starter": i < starters, "jersey": str(i + 1),
            "athlete": {"id": f"{team_id}{i:02d}", "displayName": f"Jugador {team_id}-{i}"},
            "position": {"abbreviation": SOCCER_POS[i] if i < 11 else "M"},
            "stats": [{"name": "appearances", "value": float(apps - i)}, {"name": "subIns", "value": float(max(0, i - 11))},
                      {"name": "totalGoals", "value": float(max(0, 8 - i))}, {"name": "goalAssists", "value": float(max(0, 4 - i // 2))}],
        })
    return rows


def soccer_summary(home_id, away_id, *, lineups=True, shots=((14, 5), (9, 3)), starters=11):
    out = {"boxscore": {"teams": [
        {"team": {"id": home_id}, "statistics": [{"name": "totalShots", "displayValue": str(shots[0][0])}, {"name": "shotsOnTarget", "displayValue": str(shots[0][1])}]},
        {"team": {"id": away_id}, "statistics": [{"name": "totalShots", "displayValue": str(shots[1][0])}, {"name": "shotsOnTarget", "displayValue": str(shots[1][1])}]},
    ]}}
    if lineups:
        out["rosters"] = [{"homeAway": "home", "team": {"id": home_id}, "roster": soccer_roster(home_id, starters=starters)},
                          {"homeAway": "away", "team": {"id": away_id}, "roster": soccer_roster(away_id)}]
    return out


NBA_LABELS = ["MIN", "PTS", "FG", "3PT", "FT", "REB", "AST", "TO", "STL", "BLK", "OREB", "DREB", "PF", "+/-"]


def nba_team_players(team_id, *, fga=88, fgm=40, tpa=34, tpm=12, fta=22, ftm=17, oreb=10, tov=13, pts=109, starters=True,
                     minutes_each=24.0, skew=False):
    rows = []
    for i in range(10):
        w = 0.75 ** i if skew else 1.0  # con skew: producción decreciente (la estrella rinde ≈2.7× más por 36 min que el 10.º)
        tot = sum(0.75 ** j for j in range(10)) if skew else 10.0
        share = w / tot
        mins = (34 - 3 * i) if skew else minutes_each
        rows.append({"starter": starters and i < 5, "athlete": {"id": f"{team_id}{i}", "displayName": f"Jugador {team_id}{i}"},
                     "stats": [f"{mins:g}", f"{pts * share:g}", f"{fgm * share:g}-{fga * share:g}", f"{tpm * share:g}-{tpa * share:g}",
                               f"{ftm * share:g}-{fta * share:g}", "4", f"{6 * share:g}", f"{tov * share:g}", f"{8 * share:g}", f"{5 * share:g}",
                               f"{oreb * share:g}", "3", "2", "+1"]})
    return rows


def nba_summary(home_id, away_id, *, home_kw=None, away_kw=None, injuries=None):
    def team(tid, kw):
        return {"team": {"id": tid}, "statistics": [{"labels": NBA_LABELS, "athletes": nba_team_players(tid, **(kw or {}))}]}
    out = {"boxscore": {"players": [team(home_id, home_kw), team(away_id, away_kw)]}}
    if injuries is not None:
        out["injuries"] = injuries
    return out


def mlb_game(pk=777001, *, home=(147, "New York Yankees", "NYY"), away=(111, "Boston Red Sox", "BOS"), date="2026-07-04T23:05:00Z",
             abstract="Preview", detailed="Scheduled", lineups=True, pitchers=True, scores=None, inning=None):
    def team(t, extra):
        return {"team": {"id": t[0], "name": t[1], "abbreviation": t[2]}, **extra}
    h_extra, a_extra = {}, {}
    if pitchers:
        h_extra["probablePitcher"] = {"id": 5001, "fullName": "Gerrit Local"}
        a_extra["probablePitcher"] = {"id": 5002, "fullName": "Brayan Visita"}
    if scores:
        h_extra["score"], a_extra["score"] = scores
    g = {"gamePk": pk, "gameDate": date, "status": {"abstractGameState": abstract, "detailedState": detailed},
         "teams": {"home": team(home, h_extra), "away": team(away, a_extra)},
         "venue": {"name": "Yankee Stadium", "location": {"city": "Bronx", "defaultCoordinates": {"latitude": 40.83, "longitude": -73.93}}},
         "weather": {"condition": "Clear", "temp": "86", "wind": "10 mph, Out To CF"}}
    if lineups:
        mk = lambda base: [{"id": base + i, "fullName": f"Bateador {base + i}", "primaryPosition": {"abbreviation": "DH"}} for i in range(9)]
        g["lineups"] = {"homePlayers": mk(1000), "awayPlayers": mk(2000)}
    if inning:
        g["linescore"] = {"currentInning": inning[0], "inningState": inning[1]}
    return g
