from dataclasses import replace
from datetime import timedelta

from sportsquant.core.enums import InjuryStatus, IssueCode as C, LineupStatus, Sport
from sportsquant.core.models import InjuryEntry, PlayerSlot
from sportsquant.matches.lineup_validator import validate_lineups
from .factories import NOW, make_lineup, make_match, ready_match


def codes(check):
    return {i.code for i in check.issues}


# ---- Fútbol ----------------------------------------------------------------------
def test_football_ok():
    check = validate_lineups(ready_match(Sport.FOOTBALL))
    assert check.ok and check.status is LineupStatus.OK and check.badge == "OFICIAL"


def test_missing_lineup_requires_lineup():
    m = make_match(home_lineup=make_lineup(Sport.FOOTBALL, "H"))
    check = validate_lineups(m)
    assert not check.ok and check.status is LineupStatus.LINEUP_REQUIRED
    assert codes(check) == {C.LINEUP_MISSING}
    assert check.home.ok and not check.away.ok
    assert check.summary().startswith("LINEUP_REQUIRED · visitante:")


def test_unofficial_lineup_blocks_and_skips_structural_noise():
    m = make_match(
        home_lineup=make_lineup(Sport.FOOTBALL, "H", is_official=False, starters=()),
        away_lineup=make_lineup(Sport.FOOTBALL, "A"),
    )
    assert codes(validate_lineups(m)) == {C.NOT_OFFICIAL}


def test_football_needs_exactly_eleven():
    full = make_lineup(Sport.FOOTBALL, "H")
    ten = replace(full, starters=full.starters[:10])
    m = make_match(home_lineup=ten, away_lineup=make_lineup(Sport.FOOTBALL, "A"))
    assert C.WRONG_STARTER_COUNT in codes(validate_lineups(m))


def test_football_goalkeeper_rules():
    base = make_lineup(Sport.FOOTBALL, "H")
    no_gk = replace(base, starters=(replace(base.starters[0], position="CB"),) + base.starters[1:])
    two_gk = replace(base, starters=(base.starters[0], replace(base.starters[1], position="GK")) + base.starters[2:])
    away = make_lineup(Sport.FOOTBALL, "A")
    assert C.GOALKEEPER_INVALID in codes(validate_lineups(make_match(home_lineup=no_gk, away_lineup=away)))
    assert C.GOALKEEPER_INVALID in codes(validate_lineups(make_match(home_lineup=two_gk, away_lineup=away)))


def test_football_goalkeeper_not_audited_without_positions():
    base = make_lineup(Sport.FOOTBALL, "H")
    anon = replace(base, starters=tuple(replace(p, position=None) for p in base.starters))
    m = make_match(home_lineup=anon, away_lineup=make_lineup(Sport.FOOTBALL, "A"))
    assert validate_lineups(m).ok


def test_duplicate_players():
    base = make_lineup(Sport.FOOTBALL, "H")
    dup = replace(base, starters=base.starters[:10] + (base.starters[0],))
    m = make_match(home_lineup=dup, away_lineup=make_lineup(Sport.FOOTBALL, "A"))
    assert C.DUPLICATE_PLAYER in codes(validate_lineups(m))


def test_swapped_sides_detected():
    m = make_match(home_lineup=make_lineup(Sport.FOOTBALL, "A"), away_lineup=make_lineup(Sport.FOOTBALL, "H"))
    assert codes(validate_lineups(m)) == {C.TEAM_MISMATCH}


def test_lineup_published_after_kickoff_is_rejected():
    late = make_lineup(Sport.FOOTBALL, "H", published_at=NOW + timedelta(hours=4))
    m = make_match(home_lineup=late, away_lineup=make_lineup(Sport.FOOTBALL, "A"))  # kickoff = NOW+3h
    assert C.PUBLISHED_AFTER_KICKOFF in codes(validate_lineups(m))
    early = make_lineup(Sport.FOOTBALL, "H", published_at=NOW + timedelta(hours=2))
    assert validate_lineups(make_match(home_lineup=early, away_lineup=make_lineup(Sport.FOOTBALL, "A"))).ok


def test_starter_ruled_out_blocks_but_questionable_only_warns():
    base = make_lineup(Sport.FOOTBALL, "H")
    out = replace(base, injury_report=(InjuryEntry("H3", "Jugador H3", InjuryStatus.OUT),))
    doubt = replace(base, injury_report=(InjuryEntry("H3", "Jugador H3", InjuryStatus.QUESTIONABLE),))
    away = make_lineup(Sport.FOOTBALL, "A")
    assert C.STARTER_RULED_OUT in codes(validate_lineups(make_match(home_lineup=out, away_lineup=away)))
    ok = validate_lineups(make_match(home_lineup=doubt, away_lineup=away))
    assert ok.ok and [w.code for w in ok.warnings] == [C.STARTER_UNCERTAIN]


# ---- Baloncesto ------------------------------------------------------------------
def test_basketball_ok_and_rules():
    assert validate_lineups(ready_match(Sport.BASKETBALL)).ok
    no_report = make_lineup(Sport.BASKETBALL, "H", injury_report_published=False)
    m = make_match(sport=Sport.BASKETBALL, home_lineup=no_report, away_lineup=make_lineup(Sport.BASKETBALL, "A"))
    assert codes(validate_lineups(m)) == {C.INJURY_REPORT_MISSING}
    base = make_lineup(Sport.BASKETBALL, "H")
    six = replace(base, starters=base.starters + (PlayerSlot("H9", "Extra", "C"),))
    m = make_match(sport=Sport.BASKETBALL, home_lineup=six, away_lineup=make_lineup(Sport.BASKETBALL, "A"))
    assert C.WRONG_STARTER_COUNT in codes(validate_lineups(m))


# ---- Béisbol ---------------------------------------------------------------------
def test_baseball_ok():
    assert validate_lineups(ready_match(Sport.BASEBALL)).ok


def test_baseball_pitcher_rules():
    away = make_lineup(Sport.BASEBALL, "A")
    missing = make_lineup(Sport.BASEBALL, "H", starting_pitcher=None)
    probable = make_lineup(Sport.BASEBALL, "H", pitcher_confirmed=False)
    mk = lambda h: make_match(sport=Sport.BASEBALL, home_lineup=h, away_lineup=away)
    assert codes(validate_lineups(mk(missing))) == {C.PITCHER_MISSING}
    assert codes(validate_lineups(mk(probable))) == {C.PITCHER_NOT_CONFIRMED}


def test_baseball_batting_order_must_be_1_to_9():
    base = make_lineup(Sport.BASEBALL, "H")
    bad = tuple(replace(p, batting_order=1 if i == 8 else p.batting_order) for i, p in enumerate(base.starters))
    gap = tuple(replace(p, batting_order=None if i == 0 else p.batting_order) for i, p in enumerate(base.starters))
    away = make_lineup(Sport.BASEBALL, "A")
    for starters in (bad, gap):
        m = make_match(sport=Sport.BASEBALL, home_lineup=replace(base, starters=starters), away_lineup=away)
        assert C.BATTING_ORDER_INVALID in codes(validate_lineups(m))


def test_baseball_pitcher_who_bats_is_not_double_counted():
    base = make_lineup(Sport.BASEBALL, "H")
    pitcher = base.starting_pitcher
    starters = base.starters[:8] + (PlayerSlot(pitcher.player_id, pitcher.name, "P", batting_order=9),)
    lineup = replace(base, starters=starters, injury_report=(InjuryEntry(pitcher.player_id, pitcher.name, InjuryStatus.OUT),))
    m = make_match(sport=Sport.BASEBALL, home_lineup=lineup, away_lineup=make_lineup(Sport.BASEBALL, "A"))
    out_issues = [i for i in validate_lineups(m).issues if i.code is C.STARTER_RULED_OUT]
    assert len(out_issues) == 1
