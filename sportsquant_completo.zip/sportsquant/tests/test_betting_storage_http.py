import math
from datetime import datetime, timedelta, timezone

import httpx
import pytest

from sportsquant.betting.ev import expected_log_growth, expected_value, fractional_kelly, implied_probability, kelly_fraction
from sportsquant.betting.ranking import build_candidates, merge_odds, rank_bets
from sportsquant.core.enums import Sport
from sportsquant.core.models import OddsLine
from sportsquant.data.http import HttpClient
from sportsquant.data.storage import Storage
from sportsquant.matches.providers.base import ProviderError
from sportsquant.projection.engine import ProjectionEngine
from .synth import football_ctx, make_match


def test_ev_and_kelly_known_values():
    assert implied_probability(2.5) == pytest.approx(0.4)
    assert expected_value(0.5, 2.2) == pytest.approx(0.10)
    assert expected_value(0.4, 2.5) == pytest.approx(0.0)
    assert kelly_fraction(0.55, 2.0) == pytest.approx(0.10)  # (0.55*2-1)/1
    assert kelly_fraction(0.4, 2.5) == 0.0 and kelly_fraction(0.3, 2.5) == 0.0
    assert fractional_kelly(0.55, 2.0, 0.25, 0.05) == pytest.approx(0.025)
    assert fractional_kelly(0.9, 3.0, 0.5, 0.05) == 0.05  # tope
    assert fractional_kelly(0.55, 1.0) == 0.0  # cuota inválida
    # Kelly completo maximiza el crecimiento logarítmico
    f = kelly_fraction(0.55, 2.0)
    assert expected_log_growth(0.55, 2.0, f) > expected_log_growth(0.55, 2.0, f * 0.5) > 0
    assert expected_log_growth(0.55, 2.0, f) > expected_log_growth(0.55, 2.0, f * 1.8)
    assert expected_log_growth(0.5, 2.0, 1.0) == -math.inf


def result_with(probs):
    res = ProjectionEngine().project(football_ctx(), 2_000, seed=1)
    import dataclasses
    return dataclasses.replace(res, probs=probs, mc_se={k: 0.005 for k in probs})


def test_ranking_discards_non_positive_ev_and_sorts_by_risk_adjusted_growth():
    m = make_match()
    res = result_with({"HOME": 0.55, "DRAW": 0.25, "AWAY": 0.20})
    odds = [OddsLine("1X2", "HOME", 2.10), OddsLine("1X2", "DRAW", 3.00), OddsLine("1X2", "AWAY", 4.20)]
    cands = build_candidates(m, res, odds)
    assert {c.selection for c in cands} == {"HOME", "DRAW", "AWAY"}
    ranked = rank_bets(cands, best_per_match=False)
    assert [c.selection for c in ranked] == ["HOME"]  # DRAW EV=-0.25, AWAY EV=-0.16
    assert all(c.ev > 0 for c in ranked) and ranked[0].ev == pytest.approx(0.55 * 2.1 - 1)
    assert ranked[0].stake_fraction == pytest.approx(0.25 * kelly_fraction(0.55, 2.1))


def test_ranking_orders_multiple_matches_and_best_per_match():
    a = make_match(home="T1", away="T2")
    b = make_match(home="T3", away="T4")
    import dataclasses
    b = dataclasses.replace(b, match_id="synth:football:2")
    ra, rb = result_with({"HOME": 0.60, "DRAW": 0.25, "AWAY": 0.15}), result_with({"HOME": 0.45, "DRAW": 0.30, "AWAY": 0.25})
    rb = dataclasses.replace(rb, match_id=b.match_id)
    odds_a = [OddsLine("1X2", "HOME", 1.90), OddsLine("1X2", "DRAW", 5.00)]  # ambas con EV>0 en el mismo partido
    odds_b = [OddsLine("1X2", "HOME", 2.50)]
    ranked = rank_bets(build_candidates(a, ra, odds_a) + build_candidates(b, rb, odds_b))
    assert [c.match_id for c in ranked] == sorted([c.match_id for c in ranked], key=lambda mid: -next(x.log_growth for x in ranked if x.match_id == mid))
    assert len({c.match_id for c in ranked}) == len(ranked) == 2  # una por partido
    assert len(rank_bets(build_candidates(a, ra, odds_a) + build_candidates(b, rb, odds_b), best_per_match=False)) == 3


def test_manual_odds_override_provider_odds():
    provider = [OddsLine("1X2", "HOME", 2.0, "DK"), OddsLine("1X2", "AWAY", 3.8, "DK")]
    merged = {o.selection: o for o in merge_odds(provider, {"HOME": 2.4, "DRAW": 3.3, "AWAY": 0.5})}
    assert merged["HOME"].decimal_odds == 2.4 and merged["HOME"].bookmaker == "manual"
    assert merged["AWAY"].decimal_odds == 3.8  # cuota manual inválida (<=1) se ignora
    assert merged["DRAW"].market == "MANUAL"


def test_storage_roundtrip_and_validation():
    st = Storage()
    st.kv_set("a", {"x": [1, 2]})
    assert st.kv_get("a") == {"x": [1, 2]} and st.kv_get("zzz", 7) == 7
    st.set_manual_odds("m1", "HOME", 2.2)
    st.set_manual_odds("m1", "HOME", 2.4)
    assert st.manual_odds("m1") == {"HOME": 2.4}
    with pytest.raises(ValueError):
        st.set_manual_odds("m1", "AWAY", 1.0)
    st.set_manual_odds("m1", "HOME", None)
    assert st.manual_odds("m1") == {}
    res = ProjectionEngine().project(football_ctx(), 2_000, seed=2)
    st.save_projection(res)
    assert st.load_projection(res.match_id) == res
    assert st.load_projections("football") == [res] and st.load_projections("baseball") == []
    assert st.load_projections("football", kickoff_after=res.kickoff_utc + timedelta(days=1)) == []
    st.cache_put("k", '{"a":1}', fetched=1.0)
    assert st.cache_get("k") == (1.0, '{"a":1}')


def mock_client(handler, storage=None, **kw):
    return HttpClient(storage, transport=httpx.MockTransport(handler), sleep=lambda s: None, **kw)


def test_http_cache_ttl_and_immutable():
    calls = []
    clock = {"t": 1000.0}
    def handler(req):
        calls.append(str(req.url))
        return httpx.Response(200, json={"n": len(calls)})
    c = mock_client(handler, Storage(), clock=lambda: clock["t"])
    assert c.get_json("https://x/a", ttl=60)["n"] == 1
    assert c.get_json("https://x/a", ttl=60)["n"] == 1  # cacheado
    clock["t"] += 61
    assert c.get_json("https://x/a", ttl=60)["n"] == 2  # vencido
    assert c.get_json("https://x/b", {"q": 1}, ttl=None)["n"] == 3
    clock["t"] += 10**7
    assert c.get_json("https://x/b", {"q": 1}, ttl=None)["n"] == 3  # inmutable
    assert c.get_json("https://x/a", ttl=0)["n"] == 4 and c.get_json("https://x/a", ttl=0)["n"] == 5


def test_http_retries_then_stale_fallback_then_error():
    st = Storage()
    st.cache_put("https://x/y", '{"old": true}', fetched=0.0)
    n = {"c": 0}
    def flaky(req):
        n["c"] += 1
        return httpx.Response(503) if n["c"] < 3 else httpx.Response(200, json={"ok": 1})
    assert mock_client(flaky, Storage()).get_json("https://x/z", ttl=10) == {"ok": 1} and n["c"] == 3
    down = lambda req: httpx.Response(500)
    assert mock_client(down, st, clock=lambda: 10**9).get_json("https://x/y", ttl=60) == {"old": True}  # caché vencida
    with pytest.raises(ProviderError):
        mock_client(down, Storage()).get_json("https://x/none", ttl=60)
    calls = {"c": 0}
    def not_found(req):
        calls["c"] += 1
        return httpx.Response(404)
    with pytest.raises(ProviderError):
        mock_client(not_found, Storage()).get_json("https://x/404")
    assert calls["c"] == 1  # 4xx no se reintenta
