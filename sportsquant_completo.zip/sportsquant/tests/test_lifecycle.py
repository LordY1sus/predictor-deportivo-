from datetime import datetime, timedelta

import pytest

from sportsquant.core.enums import MatchStatus as S
from sportsquant.core.enums import Sport
from sportsquant.matches.lifecycle import (
    UnknownStatusError, baseball_clock, basketball_clock, football_clock,
    is_visible_today, merge_match, merge_status, normalize_status, sort_for_display,
)
from .factories import CARACAS, NOW, UTC, make_lineup, make_match


@pytest.mark.parametrize("raw, expected", [
    ("NS", S.SCHEDULED), ("Pre-Game", S.SCHEDULED), ("STATUS_SCHEDULED", S.SCHEDULED),
    ("1H", S.LIVE), ("HT", S.LIVE), ("2H", S.LIVE), ("Q3", S.LIVE), ("2nd Quarter", S.LIVE),
    ("Top 7th", S.LIVE), ("Bottom 9th", S.LIVE), ("Rain Delay", S.LIVE), ("STATUS_IN_PROGRESS", S.LIVE),
    ("2OT", S.LIVE), ("FT", S.FINISHED), ("AET", S.FINISHED), ("Final/OT", S.FINISHED),
    ("Final", S.FINISHED), ("PST", S.FINISHED), ("Postponed", S.FINISHED), ("CANC", S.FINISHED),
])
def test_normalize_known(raw, expected):
    assert normalize_status(raw) is expected


@pytest.mark.parametrize("raw", ["", "   ", "???", "P", "weird-state"])
def test_normalize_unknown_never_guesses(raw):
    with pytest.raises(UnknownStatusError):
        normalize_status(raw)


def test_provider_map_overrides_generic():
    assert normalize_status("P", {"P": S.SCHEDULED}) is S.SCHEDULED
    assert normalize_status("final", {"FINAL": S.LIVE}) is S.LIVE


def test_merge_status_is_monotonic():
    assert merge_status(S.LIVE, S.SCHEDULED) is S.LIVE
    assert merge_status(S.FINISHED, S.LIVE) is S.FINISHED
    assert merge_status(S.SCHEDULED, S.LIVE) is S.LIVE


def test_merge_ignores_regression_entirely():
    live = make_match(status=S.LIVE, raw_status="1H")
    stale = make_match(status=S.SCHEDULED, raw_status="NS")
    assert merge_match(live, stale) is live


def test_merge_keeps_official_lineup_when_feed_degrades():
    official = make_lineup(Sport.FOOTBALL, "H")
    prev = make_match(home_lineup=official)
    degraded = make_match(home_lineup=make_lineup(Sport.FOOTBALL, "H", is_official=False))
    assert merge_match(prev, degraded).home_lineup is official
    assert merge_match(prev, make_match()).home_lineup is official


def test_merge_new_official_lineup_replaces_old():
    old = make_lineup(Sport.FOOTBALL, "H")
    new = make_lineup(Sport.FOOTBALL, "H", source="late-change")
    merged = merge_match(make_match(home_lineup=old), make_match(home_lineup=new))
    assert merged.home_lineup is new


def test_visibility_rules():
    tz = CARACAS
    today_game = make_match(kickoff=NOW + timedelta(hours=2))
    finished = make_match(status=S.FINISHED)
    yesterday = make_match(kickoff=NOW - timedelta(days=1))
    assert is_visible_today(today_game, NOW, tz)
    assert not is_visible_today(finished, NOW, tz)
    assert not is_visible_today(yesterday, NOW, tz)


def test_visibility_uses_local_date_not_utc_date():
    # 02:00 UTC del 23-nov = 22:00 del 22-nov en Caracas (UTC-4)
    late = make_match(kickoff=datetime(2026, 11, 23, 2, 0, tzinfo=UTC))
    assert is_visible_today(late, NOW, CARACAS)
    assert not is_visible_today(late, NOW, UTC)


def test_live_carryover_across_midnight():
    started_yesterday = make_match(
        status=S.LIVE, kickoff=datetime(2026, 11, 22, 3, 0, tzinfo=UTC)  # 21 nov 23:00 local
    )
    assert is_visible_today(started_yesterday, NOW, CARACAS, include_live_carryover=True)
    assert not is_visible_today(started_yesterday, NOW, CARACAS, include_live_carryover=False)


def test_sort_live_first_then_kickoff():
    a = make_match(match_id="a", kickoff=NOW + timedelta(hours=1))
    b = make_match(match_id="b", kickoff=NOW + timedelta(hours=5))
    c = make_match(match_id="c", status=S.LIVE, kickoff=NOW - timedelta(minutes=30))
    assert [m.match_id for m in sort_for_display([b, a, c])] == ["c", "a", "b"]


def test_clock_labels():
    assert football_clock(67).label == "67'"
    assert football_clock(45, 2).label == "45+2'"
    assert football_clock(45, halftime=True).label == "Descanso"
    assert basketball_clock(3, "05:12").label == "Q3 05:12"
    assert basketball_clock(5).label == "OT"
    assert basketball_clock(6).label == "2OT"
    assert baseball_clock(7, "top").label == "▲ 7"
    assert baseball_clock(7, "bottom").label == "▼ 7"
    assert baseball_clock(7).label == "Inning 7"
