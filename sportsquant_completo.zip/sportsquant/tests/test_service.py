from datetime import datetime, timedelta

from sportsquant.core.config import Settings
from sportsquant.core.enums import GateCode, MatchStatus, Sport
from sportsquant.matches.providers.static_provider import StaticProvider
from sportsquant.matches.service import MatchService
from .factories import CARACAS, NOW, UTC, make_lineup, make_raw


class Clock:
    def __init__(self, now: datetime) -> None:
        self.now = now

    def __call__(self) -> datetime:
        return self.now


def build(raws=(), **provider_kw):
    clock = Clock(NOW)
    provider = StaticProvider(raws, **provider_kw)
    # Zona fija para que la prueba sea determinista; en producción se usa la del dispositivo.
    service = MatchService(provider, Settings(), clock)
    service._settings = type("S", (), {"tz": lambda self: CARACAS, "include_live_carryover": True})()
    return service, provider, clock


def test_refresh_shows_only_todays_unfinished_matches():
    service, _, _ = build([
        make_raw("scheduled", raw_status="NS"),
        make_raw("live", raw_status="2H", kickoff=NOW - timedelta(hours=1)),
        make_raw("done", raw_status="FT", kickoff=NOW - timedelta(hours=4)),
        make_raw("tomorrow", kickoff=NOW + timedelta(days=1)),
        make_raw("other-sport", sport=Sport.BASKETBALL),
    ])
    report = service.refresh(Sport.FOOTBALL)
    ids = [m.match_id for m in service.today_matches(Sport.FOOTBALL)]
    assert ids == ["live", "scheduled"]  # LIVE primero; FT y mañana fuera
    assert report.fetched == 4 and report.visible == 2 and report.error is None
    assert service.today_matches(Sport.BASKETBALL) == []  # refresco por deporte


def test_unknown_status_and_naive_datetimes_are_skipped_and_reported():
    service, _, _ = build([
        make_raw("ok"),
        make_raw("weird", raw_status="???"),
        make_raw("naive", kickoff=datetime(2026, 11, 22, 18, 0)),
    ])
    report = service.refresh(Sport.FOOTBALL)
    assert [m.match_id for m in service.today_matches(Sport.FOOTBALL)] == ["ok"]
    assert {s.split(":")[0] for s in report.skipped} == {"weird", "naive"}


def test_provider_error_keeps_previous_cache():
    service, provider, _ = build([make_raw("a")])
    service.refresh(Sport.FOOTBALL)
    provider.fail_with = "sin red"
    report = service.refresh(Sport.FOOTBALL)
    assert report.error == "sin red" and report.visible == 1
    assert [m.match_id for m in service.today_matches(Sport.FOOTBALL)] == ["a"]


def test_status_never_regresses_across_refreshes():
    service, provider, _ = build([make_raw("a", raw_status="1H", kickoff=NOW - timedelta(minutes=20))])
    service.refresh(Sport.FOOTBALL)
    provider.set_matches([make_raw("a", raw_status="NS", kickoff=NOW - timedelta(minutes=20))])
    service.refresh(Sport.FOOTBALL)
    assert service.get("a").status is MatchStatus.LIVE


def test_finished_match_disappears_after_refresh():
    service, provider, _ = build([make_raw("a", raw_status="2H", kickoff=NOW - timedelta(hours=1))])
    service.refresh(Sport.FOOTBALL)
    assert len(service.today_matches(Sport.FOOTBALL)) == 1
    provider.set_matches([make_raw("a", raw_status="FT", kickoff=NOW - timedelta(hours=1))])
    service.refresh(Sport.FOOTBALL)
    assert service.today_matches(Sport.FOOTBALL) == []


def test_provider_status_map_is_used():
    service, _, _ = build([make_raw("a", raw_status="P")], status_map={"P": MatchStatus.SCHEDULED})
    service.refresh(Sport.FOOTBALL)
    assert service.get("a").status is MatchStatus.SCHEDULED


def test_gate_through_service_and_time_passing():
    raw = make_raw(
        "a", kickoff=NOW + timedelta(minutes=30),
        home_lineup=make_lineup(Sport.FOOTBALL, "H"), away_lineup=make_lineup(Sport.FOOTBALL, "A"),
    )
    service, _, clock = build([raw])
    service.refresh(Sport.FOOTBALL)
    assert service.gate("a").allowed
    clock.now = NOW + timedelta(minutes=31)  # el reloj avanza entre el toque y el cálculo
    assert service.gate("a").code is GateCode.KICKOFF_PASSED
    assert service.gate("nope").allowed is False


def test_lineup_arrival_unlocks_projection():
    service, provider, _ = build([make_raw("a", home_lineup=make_lineup(Sport.FOOTBALL, "H"))])
    service.refresh(Sport.FOOTBALL)
    assert service.gate("a").code is GateCode.LINEUP_REQUIRED
    provider.set_matches([make_raw(
        "a", home_lineup=make_lineup(Sport.FOOTBALL, "H"), away_lineup=make_lineup(Sport.FOOTBALL, "A"),
    )])
    service.refresh(Sport.FOOTBALL)
    assert service.gate("a").allowed
