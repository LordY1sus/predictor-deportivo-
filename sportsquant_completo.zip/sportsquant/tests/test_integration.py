"""Integración: red simulada (httpx.MockTransport) → proveedor → servicio → worker → motor → ranking."""
import types
from datetime import datetime, timedelta, timezone

import httpx
import pytest

from sportsquant.betting.ranking import build_candidates, merge_odds, rank_bets
from sportsquant.core.enums import Sport
from sportsquant.matches.gate import projection_gate
from sportsquant.services import create_services
from sportsquant.workers.projection_worker import ProjState
from . import fixtures as fx
from .synth import synth_league

CLOCK = datetime(2026, 11, 22, 14, 0, tzinfo=timezone.utc)  # el partido de ESPN empieza 16:30 UTC


class Net:
    """Servidor falso con la forma de ESPN y Open-Meteo; registra las llamadas."""

    ids = {"T1": "360", "T2": "364"}

    def __init__(self, lineups=True, weather=True):
        self.calls, self.lineups, self.weather = [], lineups, weather
        games, _, _ = synth_league(n_teams=10, n_rounds=3)
        tid = lambda t: self.ids.get(t, t)
        self.games = {str(i): (tid(g.home_id), tid(g.away_id)) for i, g in enumerate(games)}
        self.history = [
            fx.espn_event(str(i), home=(tid(g.home_id), tid(g.home_id), tid(g.home_id)), away=(tid(g.away_id), tid(g.away_id), tid(g.away_id)),
                          date=g.played_at.strftime("%Y-%m-%dT%H:%MZ"), state="post", name="STATUS_FULL_TIME",
                          scores=(str(int(g.home_score)), str(int(g.away_score))), odds=False)
            for i, g in enumerate(games)
        ]

    def __call__(self, req: httpx.Request) -> httpx.Response:
        path, q = req.url.path, dict(req.url.params)
        self.calls.append((req.url.host, path, q))
        if path.endswith("/soccer/eng.1/scoreboard"):
            if q.get("limit") == "1000":
                return httpx.Response(200, json=fx.scoreboard(*self.history))
            return httpx.Response(200, json=fx.scoreboard(fx.espn_event("401878755", date="2026-11-22T16:30Z")))
        if path.endswith("/soccer/eng.1/summary"):
            eid = q["event"]
            if eid == "401878755":
                return httpx.Response(200, json=fx.soccer_summary("360", "364", lineups=self.lineups))
            h, a = self.games[eid]
            return httpx.Response(200, json=fx.soccer_summary(h, a, shots=((13, 5), (9, 3))))
        if req.url.host == "geocoding-api.open-meteo.com" and self.weather:
            return httpx.Response(200, json={"results": [{"latitude": 53.48, "longitude": -2.24, "country": "United Kingdom"}]})
        if req.url.host == "api.open-meteo.com" and self.weather:
            return httpx.Response(200, json={"hourly": {"time": ["2026-11-22T16:00", "2026-11-22T17:00"], "temperature_2m": [4.0, 4.0],
                                                        "precipitation": [3.0, 3.0], "precipitation_probability": [80, 80],
                                                        "wind_speed_10m": [11.0, 11.0]}})
        return httpx.Response(404)


def make(tmp_path, net):
    svc = create_services(tmp_path, transport=httpx.MockTransport(net), clock=lambda: CLOCK)
    svc.apply_leagues(["eng.1"])
    svc.matches._settings = types.SimpleNamespace(tz=lambda: timezone.utc, include_live_carryover=True)
    return svc


def test_full_pipeline_refresh_gate_project_rank(tmp_path):
    net = Net()
    svc = make(tmp_path, net)
    report = svc.matches.refresh(Sport.FOOTBALL)
    assert report.error is None and report.visible == 1
    m = svc.matches.today_matches(Sport.FOOTBALL)[0]
    assert m.match_id == "espn:soccer/eng.1:401878755" and len(m.home_lineup.starters) == 11
    assert svc.matches.gate(m.match_id).allowed
    # solo el resumen del partido próximo se pidió al refrescar (los 12 partidos históricos no)
    assert [c[2]["event"] for c in net.calls if c[1].endswith("/summary")] == ["401878755"]

    st = svc.worker.submit(m.match_id, 5_000, seed=11, wait=True)
    assert st.state is ProjState.DONE, st.message
    res = st.result
    assert sum(res.probs.values()) == pytest.approx(1.0) and res.coverage > 0.6
    l2 = next(l for l in res.layers if l.name.startswith("L2"))
    assert any("clima" in n and "lluvia fuerte" in n for n in l2.notes) and l2.home_mult < 1.0  # Open-Meteo: 3 mm/h, 11 m/s
    assert any("xG" in n for n in res.layers[0].notes)

    odds = merge_odds(m.odds, {})
    ranked = rank_bets(build_candidates(m, res, odds))
    assert all(b.ev > 0 for b in ranked)
    assert svc.storage.load_projection(m.match_id) == res

    # Segunda proyección: historial y resúmenes finales vienen de la caché SQLite (cero llamadas nuevas a ellos)
    before = len(net.calls)
    svc.worker.submit(m.match_id, 5_000, seed=11, wait=True)
    new = [c for c in net.calls[before:] if c[1].endswith("/scoreboard") and c[2].get("limit") == "1000"]
    assert new == []
    svc.close()


def test_pipeline_without_published_lineups_blocks_projection(tmp_path):
    svc = make(tmp_path, Net(lineups=False))
    svc.matches.refresh(Sport.FOOTBALL)
    m = svc.matches.today_matches(Sport.FOOTBALL)[0]
    gate = svc.matches.gate(m.match_id)
    assert not gate.allowed and gate.code.value == "LINEUP_REQUIRED"
    assert svc.worker.submit(m.match_id, 5_000, wait=True).state is ProjState.BLOCKED
    svc.close()


def test_pipeline_survives_weather_outage(tmp_path):
    svc = make(tmp_path, Net(weather=False))
    svc.matches.refresh(Sport.FOOTBALL)
    m = svc.matches.today_matches(Sport.FOOTBALL)[0]
    st = svc.worker.submit(m.match_id, 3_000, wait=True)
    assert st.state is ProjState.DONE and any("clima" in n.lower() for n in st.result.notes)
    svc.close()


def test_pipeline_source_down_keeps_cartelera_and_reports(tmp_path):
    net = Net()
    svc = make(tmp_path, net)
    svc.matches.refresh(Sport.FOOTBALL)
    svc.http._client.close()
    svc.http._client = httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(500)))
    svc.http._sleep = lambda s: None
    report = svc.matches.refresh(Sport.FOOTBALL)
    assert report.error is not None or report.visible == 1  # caché vencida o error informado
    assert len(svc.matches.today_matches(Sport.FOOTBALL)) == 1  # la cartelera no desaparece
    svc.close()
