import dataclasses
from datetime import timedelta

import pytest

from sportsquant.core.enums import MatchStatus, Sport
from sportsquant.core.stats import MatchContext, PastGame, PlayerValue, TeamData, Venue, Weather
from sportsquant.projection.engine import InsufficientDataError, LeakageError, ProjectionEngine
from sportsquant.projection.layers.l1_lineup import lineup_layer
from sportsquant.projection.layers.l2_venue_weather import venue_weather_layer, weather_multiplier
from sportsquant.projection.layers.l3_form_fatigue import form_fatigue_layer, rest_effects
from sportsquant.projection.layers.l4_base_stats import base_rates
from sportsquant.projection.params import PARAMS
from sportsquant.projection.ratings import fit_league
from sportsquant.projection.results import ProjectionResult
from .synth import KICK, T0, basketball_league, football_ctx, history_from, make_match, synth_league

P = PARAMS[Sport.FOOTBALL]


def with_history(ctx, side, extra):
    team = getattr(ctx, side)
    return dataclasses.replace(ctx, **{side: dataclasses.replace(team, history=team.history + tuple(extra))})


# ---------------------------------------------------------------- Capa 4
def test_l4_football_strong_home_gets_higher_rate():
    games, att, dfn = synth_league()
    best = max(att, key=lambda t: att[t] / dfn[t])
    worst = min(att, key=lambda t: att[t] / dfn[t])
    ctx = football_ctx(best, worst)
    base, out = base_rates(ctx, P)
    assert base.home_rate > base.away_rate and 0.7 < out.coverage <= 1.0


def test_l4_raises_attack_when_xg_exceeds_goals():
    ctx = football_ctx()
    base0, _ = base_rates(ctx, P)
    xg_games = [PastGame(f"x{i}", T0 - timedelta(days=i + 1), "T5", True, 0.0, 1.0, xg_for=2.0, xg_against=0.5) for i in range(6)]
    xg_away = [PastGame(f"y{i}", T0 - timedelta(days=i + 1), "T6", False, 1.0, 1.0, xg_for=1.0, xg_against=1.0) for i in range(6)]
    ctx2 = with_history(with_history(ctx, "home", xg_games), "away", xg_away)
    base1, out = base_rates(ctx2, P)
    assert base1.home_rate > base0.home_rate and any("xG" in n for n in out.notes)


def test_l4_without_league_data_raises():
    ctx = football_ctx()
    empty = dataclasses.replace(ctx.league, n_games=0, att={}, defn={})
    with pytest.raises(InsufficientDataError):
        base_rates(dataclasses.replace(ctx, league=empty), P)


def basketball_ctx(metrics_h=None, metrics_a=None):
    games = basketball_league()
    lg = fit_league(games, asof=T0, prior_games=6.0)
    lg = dataclasses.replace(lg, metrics={"pace": 99.0, "three_pct": 0.36})
    m = make_match(Sport.BASKETBALL, "T1", "T2")
    return MatchContext(m, TeamData("T1", history=history_from(games, "T1"), metrics=metrics_h or {}),
                        TeamData("T2", history=history_from(games, "T2"), metrics=metrics_a or {}), lg, asof=T0)


def test_l4_basketball_pace_and_three_point_regression():
    pace_m = {"pace": 104.0}
    base_slow, _ = base_rates(basketball_ctx({"pace": 94.0}, {"pace": 94.0}), PARAMS[Sport.BASKETBALL])
    base_fast, _ = base_rates(basketball_ctx(pace_m, pace_m), PARAMS[Sport.BASKETBALL])
    assert base_fast.pace > base_slow.pace
    lucky = {"games_n": 12, "three_pa_pg": 40.0, "three_pm_pg": 18.0, "fga_pg": 90.0, "poss_pg": 100.0}  # 45 % de triples
    plain, _ = base_rates(basketball_ctx(), PARAMS[Sport.BASKETBALL])
    reg, out = base_rates(basketball_ctx({**lucky, "pace": 99.0}, {"pace": 99.0, **lucky}), PARAMS[Sport.BASKETBALL])
    assert reg.home_rate < plain.home_rate and any("eFG" in n for n in out.notes)


def baseball_ctx(h=None, a=None, venue=None, weather=None):
    games, _, _ = synth_league(8, 3, mu_h=4.6, mu_a=4.4)
    lg = fit_league(games, asof=T0, prior_games=8.0)
    lg = dataclasses.replace(lg, metrics={"runs_pg": 4.5, "lg_fip": 4.1})
    m = make_match(Sport.BASEBALL, "T1", "T2")
    return MatchContext(m, TeamData("T1", history=history_from(games, "T1"), metrics=h or {}),
                        TeamData("T2", history=history_from(games, "T2"), metrics=a or {}), lg,
                        venue=venue or Venue(), weather=weather, asof=T0)


def test_l4_baseball_pitching_and_offense_matter():
    ace = {"sp_fip": 2.8, "sp_xfip": 3.0, "sp_ip": 150, "sp_ip_per_start": 6.3, "bullpen_fip": 3.6, "wrc_plus": 100}
    bad = {"sp_fip": 5.5, "sp_xfip": 5.2, "sp_ip": 150, "sp_ip_per_start": 5.0, "bullpen_fip": 4.8, "wrc_plus": 100}
    vs_ace, _ = base_rates(baseball_ctx(a=ace), PARAMS[Sport.BASEBALL])
    vs_bad, _ = base_rates(baseball_ctx(a=bad), PARAMS[Sport.BASEBALL])
    assert vs_ace.home_rate < vs_bad.home_rate
    hot, _ = base_rates(baseball_ctx(h={"wrc_plus": 125}, a=bad), PARAMS[Sport.BASEBALL])
    assert hot.home_rate > vs_bad.home_rate


def test_l4_baseball_small_sample_pitcher_is_regressed():
    rookie = {"sp_fip": 1.5, "sp_xfip": 1.5, "sp_ip": 8, "sp_ip_per_start": 5.5, "bullpen_fip": 4.1}
    vet = {**rookie, "sp_ip": 180}
    r1, _ = base_rates(baseball_ctx(a=rookie), PARAMS[Sport.BASEBALL])
    r2, _ = base_rates(baseball_ctx(a=vet), PARAMS[Sport.BASEBALL])
    assert r1.home_rate > r2.home_rate  # el novato con 8 IP se contrae hacia la media


# ---------------------------------------------------------------- Capa 3
def test_l3_hot_team_gets_boost_and_cold_team_penalty():
    ctx = football_ctx()
    hot = [PastGame(f"h{i}", T0 - timedelta(days=2 + i * 3), "T7", True, 5.0, 0.0) for i in range(6)]
    cold = [PastGame(f"c{i}", T0 - timedelta(days=2 + i * 3), "T7", True, 0.0, 4.0) for i in range(6)]
    base = form_fatigue_layer(ctx, P).home_mult
    assert form_fatigue_layer(with_history(ctx, "home", hot), P).home_mult > base
    assert form_fatigue_layer(with_history(ctx, "home", cold), P).home_mult < base


def test_l3_form_is_bounded_and_decays_with_age():
    ctx = football_ctx()
    # 20+ días de antigüedad: sin efecto de descanso, solo cambia el peso por decaimiento
    recent = [PastGame(f"h{i}", T0 - timedelta(days=20 + i), "T7", True, 9.0, 0.0) for i in range(10)]
    old = [PastGame(f"o{i}", T0 - timedelta(days=200 + i), "T7", True, 9.0, 0.0) for i in range(10)]
    base = form_fatigue_layer(ctx, P).home_mult
    m_recent = form_fatigue_layer(with_history(ctx, "home", recent), P).home_mult
    m_old = form_fatigue_layer(with_history(ctx, "home", old), P).home_mult
    assert base < m_old < m_recent
    assert m_recent <= P.form_clip[1] * 1.15  # acotado (forma × defensa rival)


def test_l3_ignores_games_at_or_after_cutoff():
    ctx = football_ctx()
    future = [PastGame("f", KICK + timedelta(days=1), "T7", True, 9.0, 0.0), PastGame("f2", T0, "T7", True, 9.0, 0.0)]
    assert form_fatigue_layer(with_history(ctx, "home", future), P).home_mult == pytest.approx(form_fatigue_layer(ctx, P).home_mult)


def test_rest_effects_by_sport():
    ctx = football_ctx()
    recent = [PastGame("r", KICK - timedelta(days=2), "T7", True, 1.0, 1.0)]
    att, _, notes = rest_effects(Sport.FOOTBALL, dataclasses.replace(ctx.home, history=tuple(recent)), ctx, away_today=False)
    assert att < 1.0 and notes
    bctx = basketball_ctx()
    b2b = [PastGame("b", KICK - timedelta(hours=22), "T7", False, 100.0, 100.0)]
    att, _, notes = rest_effects(Sport.BASKETBALL, dataclasses.replace(bctx.home, history=tuple(b2b)), bctx, away_today=False)
    assert att == pytest.approx(0.978) and "back-to-back" in notes
    tired = dataclasses.replace(baseball_ctx().home, metrics={"bullpen_pitches_3d": 620.0})
    _, opp, _ = rest_effects(Sport.BASEBALL, tired, baseball_ctx(), away_today=False)
    assert 1.0 < opp <= 1.06


# ---------------------------------------------------------------- Capa 2
def test_l2_neutral_venue_removes_home_advantage():
    ctx = football_ctx()
    neutral = dataclasses.replace(ctx, venue=Venue(neutral=True))
    out = venue_weather_layer(neutral, P)
    assert out.home_mult < venue_weather_layer(ctx, P).home_mult and out.away_mult > venue_weather_layer(ctx, P).away_mult


def test_l2_weather_effects():
    heavy = Weather(temp_c=10, wind_ms=12, precip_mm=3.0)
    assert weather_multiplier(Sport.FOOTBALL, Venue(), heavy)[0] < 0.95
    assert weather_multiplier(Sport.BASKETBALL, Venue(), heavy)[0] == 1.0
    warm = Weather(temp_c=32, wind_out_ms=5.0)
    cold = Weather(temp_c=8, wind_out_ms=-5.0)
    assert weather_multiplier(Sport.BASEBALL, Venue(), warm)[0] > 1.05 > 0.95 > weather_multiplier(Sport.BASEBALL, Venue(), cold)[0]
    assert weather_multiplier(Sport.BASEBALL, Venue(roof="dome"), warm)[0] == 1.0
    half = weather_multiplier(Sport.BASEBALL, Venue(roof="retractable"), warm)[0]
    assert 1.0 < half < weather_multiplier(Sport.BASEBALL, Venue(), warm)[0]


def test_l2_park_factor_scales_both_teams():
    coors = baseball_ctx(venue=Venue(park_factor=1.14))
    out = venue_weather_layer(coors, PARAMS[Sport.BASEBALL])
    plain = venue_weather_layer(baseball_ctx(), PARAMS[Sport.BASEBALL])
    assert out.home_mult / plain.home_mult == pytest.approx(1.07) and out.away_mult / plain.away_mult == pytest.approx(1.07)


def test_l2_similar_scenarios_reward_good_home_record_against_strong_opponents():
    games, att, dfn = synth_league()
    rating = {t: att[t] / dfn[t] for t in att}
    strong_opp = max(rating, key=rating.get)
    ctx = football_ctx("T1", strong_opp)
    over = [PastGame(f"s{i}", T0 - timedelta(days=10 + i * 4), t, True, 4.0, 0.0)
            for i, t in enumerate(sorted(rating, key=rating.get)[-5:] * 2)]
    boosted = with_history(ctx, "home", over)
    assert venue_weather_layer(boosted, P).home_mult > venue_weather_layer(ctx, P).home_mult


# ---------------------------------------------------------------- Capa 1
def squad(prefix, n=16, base_off=0.3):
    return tuple(PlayerValue(f"{prefix}{i}", f"{prefix}{i}", "MID", usage=max(0.1, 1 - i * 0.06),
                             off_value=base_off + (0.25 if i < 3 else 0.0), def_value=1.0) for i in range(n))


def test_l1_football_missing_stars_reduce_attack():
    pool = squad("H")
    full = tuple(p.player_id for p in pool[:11])
    rotated = tuple(p.player_id for p in pool[3:14])  # fuera los 3 titulares ofensivos
    ctx = football_ctx()
    a = lineup_layer(dataclasses.replace(ctx, home=dataclasses.replace(ctx.home, players=pool, active_ids=full)), P)
    b = lineup_layer(dataclasses.replace(ctx, home=dataclasses.replace(ctx.home, players=pool, active_ids=rotated)), P)
    assert a.home_mult == pytest.approx(1.0) and b.home_mult < 0.95 and any("fuera" in n for n in b.notes)


def test_l1_without_players_is_neutral_and_flags_coverage():
    out = lineup_layer(football_ctx(), P)
    assert out.home_mult == 1.0 and out.away_mult == 1.0 and out.coverage == 0.0


def bball_players(prefix):
    vals = [12, 9, 6, 4, 3, 2, 1.5, 1, 0.5, 0]
    mins = [34, 33, 31, 29, 26, 22, 18, 15, 12, 10]
    return tuple(PlayerValue(f"{prefix}{i}", f"{prefix}{i}", "G", off_value=v, def_value=v / 4, minutes=m)
                 for i, (v, m) in enumerate(zip(vals, mins)))


def test_l1_basketball_star_out_hurts_offense_and_boosts_opponent_with_dudoso_less():
    bctx = basketball_ctx()
    pool = bball_players("H")
    starters = tuple(p.player_id for p in pool[1:6])  # sin la estrella H0
    healthy = dataclasses.replace(bctx.home, players=pool, active_ids=tuple(p.player_id for p in pool[:5]))
    out_star = dataclasses.replace(bctx.home, players=pool, active_ids=starters, availability={"H0": 0.0})
    doubtful = dataclasses.replace(bctx.home, players=pool, active_ids=starters, availability={"H0": 0.5})
    mk = lambda home: lineup_layer(dataclasses.replace(bctx, home=home), PARAMS[Sport.BASKETBALL])
    h, o, d = mk(healthy), mk(out_star), mk(doubtful)
    assert h.home_mult == pytest.approx(1.0, abs=1e-6)
    assert o.home_mult < d.home_mult <= h.home_mult  # más probable de jugar => menor castigo
    assert o.away_mult >= 1.0  # su defensa también cae
    assert o.home_mult >= PARAMS[Sport.BASKETBALL].lineup_clip[0]


def test_l1_baseball_lineup_quality():
    bctx = baseball_ctx()
    pool = tuple(PlayerValue(f"B{i}", f"B{i}", "BAT", usage=1 - i * 0.05, off_value=1.25 - i * 0.04) for i in range(13))
    best = tuple(p.player_id for p in pool[:9])
    bench = tuple(p.player_id for p in pool[4:13])
    mk = lambda ids: lineup_layer(dataclasses.replace(bctx, home=dataclasses.replace(bctx.home, players=pool, active_ids=ids)), PARAMS[Sport.BASEBALL])
    assert mk(best).home_mult == pytest.approx(1.0) and mk(bench).home_mult < 0.95


# ---------------------------------------------------------------- Motor
def test_engine_end_to_end_football_and_roundtrip():
    eng = ProjectionEngine()
    res = eng.project(football_ctx(), 10_000, seed=42)
    assert sum(res.probs.values()) == pytest.approx(1.0)
    assert {l.name for l in res.layers} == {"L4 base", "L3 forma/fatiga", "L2 sede/clima", "L1 alineación"}
    assert res.n_simulations == 10_000 and 0.0 < res.coverage <= 1.0
    back = ProjectionResult.from_dict(res.to_dict())
    assert back == res
    assert eng.project(football_ctx(), 10_000, seed=42).probs == res.probs


def test_engine_clamps_simulations_and_enforces_t_lt_T():
    eng = ProjectionEngine()
    assert eng.project(football_ctx(), 5, seed=1).n_simulations == 1_000
    assert eng.project(football_ctx(), 10**7, seed=1).n_simulations == 50_000
    with pytest.raises(LeakageError):
        eng.project(football_ctx(asof=KICK), 2_000)
    with pytest.raises(LeakageError):
        eng.project(football_ctx(asof=KICK + timedelta(minutes=1)), 2_000)


def test_engine_discards_history_from_the_future():
    ctx = football_ctx()
    cheat = [PastGame("leak", T0 + timedelta(hours=1), "T7", True, 20.0, 0.0)] * 5  # t >= asof
    leaked = with_history(ctx, "home", cheat)
    eng = ProjectionEngine()
    assert eng.project(leaked, 5_000, seed=3).probs == eng.project(ctx, 5_000, seed=3).probs


def test_engine_all_sports_run():
    eng = ProjectionEngine()
    for ctx in (basketball_ctx({"pace": 99.0}, {"pace": 101.0}), baseball_ctx({"wrc_plus": 105}, {"sp_fip": 3.9, "sp_ip": 100})):
        res = eng.project(ctx, 5_000, seed=1)
        assert set(res.probs) == {"HOME", "AWAY"} and sum(res.probs.values()) == pytest.approx(1.0)
