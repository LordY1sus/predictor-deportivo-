from datetime import timedelta

from sportsquant.core.enums import GateCode, MatchStatus, Sport
from sportsquant.matches.gate import projection_gate
from .factories import NOW, make_lineup, make_match, ready_match


def test_allowed_when_scheduled_before_kickoff_with_official_lineups():
    gate = projection_gate(ready_match(), NOW)
    assert gate.allowed and gate.code is GateCode.OK


def test_blocked_without_official_lineups():
    gate = projection_gate(make_match(home_lineup=make_lineup(Sport.FOOTBALL, "H")), NOW)
    assert not gate.allowed and gate.code is GateCode.LINEUP_REQUIRED
    assert gate.lineup is not None and not gate.lineup.ok


def test_blocked_when_not_scheduled():
    for status in (MatchStatus.LIVE, MatchStatus.FINISHED):
        gate = projection_gate(ready_match(status=status), NOW)
        assert gate.code is GateCode.NOT_SCHEDULED


def test_blocked_at_or_after_kickoff_even_if_feed_still_says_scheduled():
    m = ready_match(kickoff=NOW + timedelta(minutes=10))
    assert projection_gate(m, NOW + timedelta(minutes=9, seconds=59)).allowed
    assert projection_gate(m, NOW + timedelta(minutes=10)).code is GateCode.KICKOFF_PASSED
    assert projection_gate(m, NOW + timedelta(minutes=30)).code is GateCode.KICKOFF_PASSED


def test_all_three_sports_pass_with_valid_lineups():
    for sport in Sport:
        assert projection_gate(ready_match(sport), NOW).allowed, sport
