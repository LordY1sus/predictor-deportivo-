"""Constructores de datos de prueba."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from sportsquant.core.enums import MatchStatus, Sport
from sportsquant.core.models import Match, PlayerSlot, RawMatch, Team, TeamLineup

UTC = timezone.utc
NOW = datetime(2026, 11, 22, 15, 0, tzinfo=UTC)
CARACAS = timezone(timedelta(hours=-4))  # offset fijo: las pruebas no dependen de tzdata

_FOOTBALL_POS = ["GK", "RB", "CB", "CB", "LB", "CM", "CM", "CM", "RW", "ST", "LW"]
_BASKET_POS = ["PG", "SG", "SF", "PF", "C"]


def make_lineup(sport: Sport, team_id: str = "H", **overrides) -> TeamLineup:
    base: dict = {"team_id": team_id, "is_official": True, "source": "test"}
    if sport is Sport.FOOTBALL:
        base["starters"] = tuple(
            PlayerSlot(f"{team_id}{i}", f"Jugador {team_id}{i}", _FOOTBALL_POS[i]) for i in range(11)
        )
    elif sport is Sport.BASKETBALL:
        base["starters"] = tuple(
            PlayerSlot(f"{team_id}{i}", f"Jugador {team_id}{i}", _BASKET_POS[i]) for i in range(5)
        )
        base["injury_report_published"] = True
    else:
        base["starters"] = tuple(
            PlayerSlot(f"{team_id}{i}", f"Bateador {team_id}{i}", "DH", batting_order=i + 1)
            for i in range(9)
        )
        base["starting_pitcher"] = PlayerSlot(f"{team_id}P", "Abridor", "P")
        base["pitcher_confirmed"] = True
    base.update(overrides)
    return TeamLineup(**base)


def make_raw(
    match_id: str = "m1",
    sport: Sport = Sport.FOOTBALL,
    raw_status: str = "NS",
    kickoff: datetime | None = None,
    **kw,
) -> RawMatch:
    return RawMatch(
        match_id=match_id,
        sport=sport,
        competition="Liga Test",
        kickoff=kickoff or NOW + timedelta(hours=3),
        home=Team("H", "Local"),
        away=Team("A", "Visitante"),
        raw_status=raw_status,
        **kw,
    )


def make_match(status: MatchStatus = MatchStatus.SCHEDULED, **kw) -> Match:
    return Match.from_raw(make_raw(**kw), status)


def ready_match(sport: Sport = Sport.FOOTBALL, **kw) -> Match:
    """Partido programado con ambas alineaciones oficiales válidas."""
    return make_match(
        sport=sport,
        home_lineup=make_lineup(sport, "H"),
        away_lineup=make_lineup(sport, "A"),
        **kw,
    )
