import numpy as np
import pytest

from sportsquant.core.stats import LeagueGame
from sportsquant.projection.ratings import expected_scores, fit_league
from sportsquant.projection.results import MAX_SIMULATIONS, MIN_SIMULATIONS, clamp_simulations
from sportsquant.projection.sims.baseball import simulate_baseball
from sportsquant.projection.sims.basketball import simulate_basketball
from sportsquant.projection.sims.football import simulate_football
from .synth import T0, synth_league


def test_ipf_recovers_true_strengths():
    games, att, dfn = synth_league(n_teams=14, n_rounds=6, seed=11)
    lg = fit_league(games, asof=T0, prior_games=2.0)
    ids = sorted(att)
    corr_a = np.corrcoef([att[t] for t in ids], [lg.att[t] for t in ids])[0, 1]
    corr_d = np.corrcoef([dfn[t] for t in ids], [lg.defn[t] for t in ids])[0, 1]
    assert corr_a > 0.9 and corr_d > 0.9
    assert abs(np.mean(list(lg.att.values())) - 1.0) < 1e-9
    assert lg.avg_home == pytest.approx(1.5, rel=0.08)


def test_ipf_exact_on_noiseless_data():
    games, att, dfn = synth_league(n_teams=8, n_rounds=3, noise=False)
    lg = fit_league(games, asof=T0, prior_games=0.01, iterations=300)
    ids = sorted(att)
    ratio = np.array([lg.att[t] / att[t] for t in ids])
    assert ratio.std() / ratio.mean() < 0.02  # misma forma salvo escala


def test_ipf_never_uses_games_from_the_future():
    games, _, _ = synth_league(n_teams=6, n_rounds=2)
    cut = games[len(games) // 2].played_at
    lg_cut = fit_league(games, asof=cut)
    assert lg_cut.n_games == sum(1 for g in games if g.played_at < cut)
    assert fit_league(games, asof=games[0].played_at) is None


def test_ipf_neutral_and_expected_scores():
    games = [LeagueGame("A", "B", 2, 1, T0.replace(year=2026, month=1)), LeagueGame("B", "A", 0, 1, T0.replace(year=2026, month=2))]
    lg = fit_league(games, asof=T0, prior_games=1.0)
    h, a = expected_scores(lg, "A", "B")
    hn, an = expected_scores(lg, "A", "B", neutral=True)
    assert h > 0 and a > 0 and hn == pytest.approx(an * (hn / an))
    assert expected_scores(lg, "A", "ZZZ") is None


def test_clamp_simulations():
    assert clamp_simulations(10) == MIN_SIMULATIONS and clamp_simulations(10**9) == MAX_SIMULATIONS
    assert clamp_simulations(12_345.9) == 12_345


@pytest.mark.parametrize("sim,rates,draws", [
    (simulate_football, (1.5, 1.2), True),
    (simulate_basketball, (113.0, 110.0), False),
    (simulate_baseball, (4.6, 4.3), False),
])
def test_probabilities_sum_to_one_and_seed_reproducible(sim, rates, draws):
    kw = {"pace": 99.0} if sim is simulate_basketball else {}
    a = sim(*rates, 20_000, np.random.default_rng(5), **kw)
    b = sim(*rates, 20_000, np.random.default_rng(5), **kw)
    assert sum(a.probs.values()) == pytest.approx(1.0, abs=1e-9)
    assert a.probs == b.probs
    assert ("DRAW" in a.probs) is draws
    assert all(0 < s < 0.02 for s in a.se.values())


def test_football_symmetry_and_monotonicity():
    s = simulate_football(1.4, 1.4, 60_000, np.random.default_rng(1))
    assert abs(s.probs["HOME"] - s.probs["AWAY"]) < 0.01
    strong = simulate_football(2.2, 0.9, 60_000, np.random.default_rng(1))
    assert strong.probs["HOME"] > 0.6 > s.probs["HOME"] > strong.probs["AWAY"]
    assert 0.2 < s.probs["DRAW"] < 0.35  # empate típico de partidos parejos
    assert strong.exp_home == pytest.approx(2.2, rel=0.05)


def test_football_dixon_coles_raises_low_score_draws():
    plain = simulate_football(1.2, 1.0, 120_000, np.random.default_rng(9), rho=0.0)
    dc = simulate_football(1.2, 1.0, 120_000, np.random.default_rng(9), rho=-0.12)
    assert dc.probs["DRAW"] > plain.probs["DRAW"]


def test_basketball_margin_and_scoring_are_realistic():
    s = simulate_basketball(114.0, 111.0, 60_000, np.random.default_rng(2), pace=99.0)
    assert 10.5 < s.margin_sd < 14.0  # NBA ≈ 12-13
    assert s.exp_home == pytest.approx(114.0, abs=1.5)
    assert 0.5 < s.probs["HOME"] < 0.65


def test_baseball_run_distribution_matches_mlb_dispersion():
    s = simulate_baseball(4.5, 4.5, 80_000, np.random.default_rng(4))
    assert abs(s.probs["HOME"] - 0.5) < 0.01
    # var/media de carreras por equipo ≈ 2.1 (con extras se acerca a la media)
    assert 3.0 < s.total_sd < 4.6
    assert s.exp_home == pytest.approx(4.5, rel=0.06)
