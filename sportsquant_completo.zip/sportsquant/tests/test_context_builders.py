import dataclasses
from datetime import date, datetime, timedelta, timezone

import pytest

from sportsquant.core.enums import MatchStatus, Sport
from sportsquant.core.models import Match, RawMatch, Team
from sportsquant.data import context as ctxmod
from sportsquant.data.context import BaseballContextBuilder, BasketballContextBuilder, FootballContextBuilder, nba_profile
from sportsquant.data.espn import FinishedGame, lineups_from_summary, parse_nba_players
from sportsquant.data.mlb import MlbClient
from sportsquant.matches.providers.base import ProviderError
from sportsquant.projection.engine import ProjectionEngine
from . import fixtures as fx
from .synth import T0, basketball_league, synth_league

KICK = T0 + timedelta(hours=4)


def finished_from(games, league):
    return [FinishedGame(str(i), league, g.home_id, g.away_id, g.home_score, g.away_score, g.played_at) for i, g in enumerate(games)]


class FakeEspn:
    workers = 1

    def __init__(self, finished, summary_fn):
        self.finished, self.summary_fn, self.calls = finished, summary_fn, []

    def finished_games(self, sport_path, leagues, until, lookback_days):
        return list(self.finished)

    def summary(self, sport_path, league, event_id, *, final=False):
        self.calls.append(event_id)
        out = self.summary_fn(event_id)
        if out is None:
            raise ProviderError("404")
        return out

    def map(self, fn, items):
        return [fn(i) for i in items]


def raw_match(match_id, sport, home="T1", away="T2", venue=None):
    return RawMatch(match_id, sport, "Liga", KICK, Team(home, home, home), Team(away, away, away), "scheduled", venue=venue)


# --------------------------------------------------------------------- fútbol
def football_setup():
    games, _, _ = synth_league(n_teams=10, n_rounds=3)
    finished = finished_from(games, "eng.1")
    by_id = {f.event_id: f for f in finished}

    def summary(eid):
        if eid == "999":
            return fx.soccer_summary("T1", "T2")
        g = by_id[eid]
        return fx.soccer_summary(g.home_id, g.away_id, shots=((15, 6), (8, 2)))

    raw = raw_match("espn:soccer/eng.1:999", Sport.FOOTBALL, venue="Old Trafford · Manchester")
    h, a = lineups_from_summary(raw, summary("999"))
    match = Match.from_raw(dataclasses.replace(raw, home_lineup=h, away_lineup=a), MatchStatus.SCHEDULED)
    return FakeEspn(finished, summary), match


def test_football_builder_and_engine_end_to_end():
    espn, match = football_setup()
    ctx = FootballContextBuilder(espn, ["eng.1"], weather=None).build(match, T0)
    assert ctx.league.n_games == len(espn.finished) and ctx.league.att.keys() >= {"T1", "T2"}
    assert all(g.played_at < T0 for t in (ctx.home, ctx.away) for g in t.history)
    assert sum(g.xg_for is not None for g in ctx.home.history) == FootballContextBuilder.XG_LAST_N  # proxy de xG por tiros
    assert len(ctx.home.active_ids) == 11 and len(ctx.home.players) >= 16
    assert ctx.venue.city == "Manchester" and ctx.weather is None
    res = ProjectionEngine().project(ctx, 5_000, seed=4)
    layers = {l.name: l for l in res.layers}
    assert layers["L1 alineación"].coverage > 0.9 and "xG" in " ".join(layers["L4 base"].notes)
    assert sum(res.probs.values()) == pytest.approx(1.0)


def test_football_builder_excludes_future_results_and_survives_missing_summaries():
    espn, match = football_setup()
    future = FinishedGame("f1", "eng.1", "T1", "T2", 9.0, 0.0, T0 + timedelta(hours=1))
    espn.finished.append(future)
    broken = FakeEspn(espn.finished, lambda eid: None)  # ningún resumen disponible
    ctx = FootballContextBuilder(broken, ["eng.1"]).build(match, T0)
    assert ctx.league.n_games == len(espn.finished) - 1  # el partido futuro no entra en el IPF
    assert not any(g.game_id.endswith(":f1") for g in ctx.home.history)
    assert ctx.home.players == () and any("plantilla" in n or "resumen" in n for n in ctx.notes)
    res = ProjectionEngine().project(ctx, 2_000, seed=1)  # sigue proyectando con cobertura reducida
    assert res.layers[3].coverage == 0.0


def test_football_builder_weather_failure_does_not_block():
    espn, match = football_setup()

    class BadWeather:
        def geocode(self, *a, **k): raise ProviderError("sin red")
    ctx = FootballContextBuilder(espn, ["eng.1"], weather=BadWeather()).build(match, T0)
    assert ctx.weather is None and any("clima" in n for n in ctx.notes)


# ------------------------------------------------------------------ baloncesto
def test_nba_profile_formulas():
    box = parse_nba_players(fx.nba_summary("H", "A", home_kw={"fga": 88, "fta": 22, "oreb": 10, "tov": 13, "pts": 110},
                                           away_kw={"fga": 90, "fta": 20, "oreb": 12, "tov": 12, "pts": 100}))
    metrics, players, lg_pace, (m3, a3) = nba_profile("H", [box])
    poss_h, poss_a = 88 + 0.44 * 22 - 10 + 13, 90 + 0.44 * 20 - 12 + 12
    assert metrics["pace"] == pytest.approx((poss_h + poss_a) / 2)
    assert metrics["ortg"] == pytest.approx(100 * 110 / poss_h) and metrics["drtg"] == pytest.approx(100 * 100 / poss_a)
    assert metrics["games_n"] == 1 and metrics["three_pa_pg"] == pytest.approx(34) and metrics["opp_poss_pg"] == pytest.approx(poss_a)
    assert players == [] and m3 == pytest.approx(24) and a3 == pytest.approx(68)  # 1 solo partido: minutos insuficientes (< 30)
    _, players2, _, _ = nba_profile("H", [box, box])
    assert len(players2) == 10 and all(p.minutes == pytest.approx(24.0) for p in players2)


def test_nba_profile_detects_overtime_in_pace():
    reg = parse_nba_players(fx.nba_summary("H", "A"))
    ot = parse_nba_players(fx.nba_summary("H", "A", home_kw={"minutes_each": 26.5}, away_kw={"minutes_each": 26.5}))  # 265 min = 1 OT
    assert nba_profile("H", [ot])[0]["pace"] == pytest.approx(nba_profile("H", [reg])[0]["pace"] * 48 / 53)


def basketball_setup(star_out):
    games = basketball_league()
    finished = finished_from(games, "nba")
    by_id = {f.event_id: f for f in finished}

    def summary(eid):
        if eid == "888":
            s = fx.nba_summary("T1", "T2", home_kw={"skew": True}, away_kw={"skew": True},
                               injuries=[{"team": {"id": "T1"}, "injuries": [{"athlete": {"id": "T10", "displayName": "Estrella"}, "status": "Out"}]}])
            if star_out:  # titulares oficiales sin la estrella T10
                rows = s["boxscore"]["players"][0]["statistics"][0]["athletes"]
                for i, r in enumerate(rows):
                    r["starter"] = 1 <= i <= 5
            return s
        g = by_id[eid]
        return fx.nba_summary(g.home_id, g.away_id, home_kw={"skew": True}, away_kw={"skew": True})

    raw = raw_match("espn:basketball/nba:888", Sport.BASKETBALL)
    h, a = lineups_from_summary(raw, summary("888"))
    match = Match.from_raw(dataclasses.replace(raw, home_lineup=h, away_lineup=a), MatchStatus.SCHEDULED)
    return FakeEspn(finished, summary), match


def test_basketball_builder_metrics_players_availability_and_effect():
    espn, match = basketball_setup(star_out=True)
    ctx = BasketballContextBuilder(espn).build(match, T0)
    assert ctx.home.metrics["games_n"] == BasketballContextBuilder.LAST_N and ctx.home.metrics["pace"] > 80
    assert ctx.league.metrics["pace"] > 80 and 0.2 < ctx.league.metrics["three_pct"] < 0.5
    assert ctx.home.availability == {"T10": 0.0} and "T10" not in ctx.home.active_ids and len(ctx.home.active_ids) == 5
    star = next(p for p in ctx.home.players if p.player_id == "T10")
    assert star.minutes > 30 and star.off_value > max(p.off_value for p in ctx.home.players if p.player_id != "T10")
    out = ProjectionEngine().project(ctx, 20_000, seed=9)
    healthy_espn, healthy_match = basketball_setup(star_out=False)
    healthy_ctx = dataclasses.replace(BasketballContextBuilder(healthy_espn).build(healthy_match, T0),
                                      home=dataclasses.replace(ctx.home, active_ids=tuple(f"T1{i}" for i in range(5)), availability={}))
    healthy = ProjectionEngine().project(healthy_ctx, 20_000, seed=9)
    # La liga sintética tiene diferencias enormes entre equipos (probabilidades ≈ 0 o 1), así que se compara
    # la tasa de anotación esperada (determinista) en lugar de una probabilidad saturada.
    assert out.rate_home < healthy.rate_home and out.rate_away >= healthy.rate_away
    assert next(l for l in out.layers if l.name.startswith("L1")).home_mult < 1.0


# --------------------------------------------------------------------- béisbol
def person(pid, name, *, pa=None, ops=None, ip=None, gs=0, hr=5, bb=20, k=60):
    stats = []
    if pa is not None:
        stats.append({"group": {"displayName": "hitting"}, "splits": [{"stat": {"plateAppearances": pa, "ops": ops, "obp": ".330", "slg": ".420"}}]})
    if ip is not None:
        stats.append({"group": {"displayName": "pitching"}, "splits": [{"stat": {
            "inningsPitched": str(ip), "gamesStarted": gs, "homeRuns": hr, "baseOnBalls": bb, "hitBatsmen": 3, "strikeOuts": k, "airOuts": 90, "earnedRuns": 30}}]})
    return {"person": {"id": pid, "fullName": name, "stats": stats}}


class FakeMlb(MlbClient):
    def __init__(self, finished):
        self.finished, self.workers, self.split_calls = finished, 1, []

    def finished_games(self, until, lookback_days):
        return list(self.finished)

    def team_stats(self, group, season):
        out = {}
        for i in range(8):
            if group == "hitting":
                out[f"T{i}"] = {"gamesPlayed": 150, "plateAppearances": 6000, "runs": 700 + 15 * i, "obp": str(0.31 + 0.005 * i), "slg": str(0.40 + 0.006 * i), "ops": ".730"}
            else:
                out[f"T{i}"] = {"inningsPitched": "1300.0", "homeRuns": 170, "baseOnBalls": 480, "hitBatsmen": 60, "strikeOuts": 1250, "earnedRuns": 580, "airOuts": 1500}
        return out

    def roster(self, team_id, season):
        batters = [person(1000 + i, f"Bateador {1000 + i}", pa=600 - 20 * i, ops=str(0.85 - 0.02 * i)) for i in range(12)]
        pitchers = [person(10, "Abridor", ip=180.0, gs=30)] + [person(11 + i, f"Relevista {i}", ip=60.0, gs=0, hr=6, bb=22, k=70) for i in range(6)]
        return batters + pitchers

    def person_stat(self, pid, group, season, *, stats="season", sit_codes=None):
        if group == "pitching":
            return [{"stat": {"inningsPitched": "170.0", "gamesStarted": 29, "homeRuns": 15, "baseOnBalls": 40, "hitBatsmen": 4, "strikeOuts": 190, "airOuts": 180}}]
        self.split_calls.append(pid)
        return [{"split": {"code": "vl"}, "stat": {"ops": ".900", "plateAppearances": 120}}, {"split": {"code": "vr"}, "stat": {"ops": ".700", "plateAppearances": 300}}]

    def person(self, pid):
        return {"pitchHand": {"code": "L"}}

    def boxscore(self, game_pk):
        return {"teams": {"home": {"pitchers": [10, 11, 12], "players": {"ID10": {"stats": {"pitching": {"pitchesThrown": 95}}},
                                                                          "ID11": {"stats": {"pitching": {"pitchesThrown": 30}}},
                                                                          "ID12": {"stats": {"pitching": {"pitchesThrown": 25}}}}},
                          "away": {"pitchers": [], "players": {}}}}

    def schedule(self, start, end, **kw):
        return {"dates": [{"games": [fx.mlb_game(777001)]}]}


def test_baseball_builder_end_to_end():
    games, _, _ = synth_league(8, 3, mu_h=4.6, mu_a=4.4)
    finished = finished_from(games, "mlb")
    yesterday = FinishedGame("88", "mlb", "T1", "T5", 4.0, 3.0, T0 - timedelta(days=1))
    future = FinishedGame("99", "mlb", "T1", "T5", 30.0, 0.0, T0 + timedelta(hours=1))
    mlb = FakeMlb(finished + [yesterday, future])
    raw = dataclasses.replace(
        raw_match("mlb:777001", Sport.BASEBALL, venue="Yankee Stadium · Bronx"),
        home_lineup=__import__("sportsquant.data.mlb", fromlist=["x"]).parse_game(fx.mlb_game())["home_lineup"] if False else None,
    )
    from sportsquant.data.mlb import parse_game
    parsed = parse_game(fx.mlb_game())
    match = Match.from_raw(dataclasses.replace(raw, home_lineup=dataclasses.replace(parsed.home_lineup, team_id="T1"),
                                               away_lineup=dataclasses.replace(parsed.away_lineup, team_id="T2")), MatchStatus.SCHEDULED)
    ctx = BaseballContextBuilder(mlb, weather=None).build(match, T0)
    assert all(g.played_at < T0 for g in ctx.home.history)
    m = ctx.home.metrics
    assert m["wrc_plus_is_proxy"] == 1.0 and 80 < m["wrc_plus"] < 125
    assert m["sp_fip"] and m["sp_xfip"] and m["bullpen_fip"] and m["sp_ip_per_start"] == pytest.approx(170 / 29)
    assert m["bullpen_pitches_3d"] == 55.0  # relevistas del partido de ayer (el abridor se excluye)
    assert ctx.venue.park_factor == 1.00 and ctx.venue.roof == "open" and ctx.venue.lat == pytest.approx(40.83)
    assert ctx.weather.temp_c == pytest.approx(30.0) and ctx.weather.wind_out_ms > 0
    assert len(ctx.home.players) == 12 and len(ctx.home.active_ids) == 9 and mlb.split_calls  # splits vs abridor zurdo
    res = ProjectionEngine().project(ctx, 5_000, seed=5)
    l2 = next(l for l in res.layers if l.name.startswith("L2"))
    assert l2.home_mult > 1.0 and any("clima" in n for n in l2.notes)  # 30 °C y viento afuera → más carreras
    assert sum(res.probs.values()) == pytest.approx(1.0)


def test_baseball_builder_degrades_without_stats():
    games, _, _ = synth_league(8, 3, mu_h=4.6, mu_a=4.4)

    class Down(FakeMlb):
        def team_stats(self, group, season): raise ProviderError("caído")
        def roster(self, team_id, season): raise ProviderError("caído")
        def schedule(self, *a, **k): raise ProviderError("caído")
        def person_stat(self, *a, **k): raise ProviderError("caído")
        def person(self, pid): raise ProviderError("caído")
    match = Match.from_raw(raw_match("mlb:777001", Sport.BASEBALL), MatchStatus.SCHEDULED)
    ctx = BaseballContextBuilder(Down(finished_from(games, "mlb"))).build(match, T0)
    assert len(ctx.notes) >= 3
    res = ProjectionEngine().project(ctx, 2_000, seed=1)  # usa fuerzas IPF de carreras como respaldo
    assert sum(res.probs.values()) == pytest.approx(1.0) and res.coverage < 0.6


def test_split_venue():
    assert ctxmod.split_venue("Old Trafford · Manchester") == ("Old Trafford", "Manchester")
    assert ctxmod.split_venue("Solo nombre") == ("Solo nombre", None) and ctxmod.split_venue(None) == (None, None)
