"""Datos sintéticos para probar el motor sin red."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import numpy as np

from sportsquant.core.enums import Sport
from sportsquant.core.models import Match, PlayerSlot, RawMatch, Team, TeamLineup
from sportsquant.core.stats import (
    LeagueData, LeagueGame, MatchContext, PastGame, PlayerValue, TeamData, Venue, Weather,
)
from sportsquant.projection.ratings import fit_league

UTC = timezone.utc
T0 = datetime(2026, 11, 22, 12, 0, tzinfo=UTC)  # "ahora"
KICK = T0 + timedelta(hours=4)


def synth_league(n_teams=12, n_rounds=4, mu_h=1.5, mu_a=1.2, seed=7, noise=True):
    """Liga con fuerzas verdaderas conocidas; devuelve (games, true_att, true_def)."""
    rng = np.random.default_rng(seed)
    ids = [f"T{i}" for i in range(n_teams)]
    att = dict(zip(ids, np.exp(rng.normal(0, 0.25, n_teams))))
    dfn = dict(zip(ids, np.exp(rng.normal(0, 0.25, n_teams))))
    games, day = [], 0
    for _ in range(n_rounds):
        for h in ids:
            for a in ids:
                if h == a:
                    continue
                day += 1
                lam_h, lam_a = mu_h * att[h] * dfn[a], mu_a * att[a] * dfn[h]
                hs, as_ = (rng.poisson(lam_h), rng.poisson(lam_a)) if noise else (lam_h, lam_a)
                games.append(LeagueGame(h, a, float(hs), float(as_), T0 - timedelta(days=300) + timedelta(days=day * 0.2)))
    return games, att, dfn


def history_from(games, team_id, cut=None):
    out = []
    for i, g in enumerate(games):
        if g.home_id == team_id:
            out.append(PastGame(f"g{i}", g.played_at, g.away_id, True, g.home_score, g.away_score))
        elif g.away_id == team_id:
            out.append(PastGame(f"g{i}", g.played_at, g.home_id, False, g.away_score, g.home_score))
    return tuple(g for g in out if cut is None or g.played_at < cut)


def make_match(sport=Sport.FOOTBALL, home="T1", away="T2", kickoff=KICK, **kw):
    raw = RawMatch(
        match_id=f"synth:{sport.value}:1", sport=sport, competition="Liga", kickoff=kickoff,
        home=Team(home, f"Equipo {home}", home), away=Team(away, f"Equipo {away}", away),
        raw_status="scheduled", **kw,
    )
    from sportsquant.core.enums import MatchStatus
    return Match.from_raw(raw, MatchStatus.SCHEDULED)


def football_ctx(home="T1", away="T2", **over):
    games, _, _ = synth_league()
    lg = fit_league(games, asof=T0, prior_games=4.0)
    ctx = MatchContext(
        match=make_match(Sport.FOOTBALL, home, away), league=lg, asof=T0,
        home=TeamData(home, history=history_from(games, home)),
        away=TeamData(away, history=history_from(games, away)),
    )
    return _replace(ctx, **over)


def _replace(ctx, **over):
    import dataclasses
    return dataclasses.replace(ctx, **over) if over else ctx


def basketball_league(n_teams=10, seed=3):
    games, att, dfn = synth_league(n_teams, 3, mu_h=114.0, mu_a=111.0, seed=seed, noise=False)
    return games
