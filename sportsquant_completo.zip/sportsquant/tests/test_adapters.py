import dataclasses
from datetime import date, datetime, timedelta, timezone

import pytest

from sportsquant.core.enums import MatchStatus, Sport
from sportsquant.core.models import Match
from sportsquant.data import espn, mlb
from sportsquant.matches.lifecycle import normalize_status
from sportsquant.matches.lineup_validator import validate_lineups
from sportsquant.matches.providers.base import ProviderError
from sportsquant.matches.providers.composite import CompositeProvider
from . import fixtures as fx

UTC = timezone.utc


# ------------------------------------------------------------------------ ESPN
def test_odds_shapes_and_conversions():
    assert espn.american_to_decimal("+310") == pytest.approx(4.1)
    assert espn.american_to_decimal(-130) == pytest.approx(1.7692, abs=1e-3)
    assert espn.american_to_decimal("EVEN") == 2.0 and espn.american_to_decimal(50) is None
    assert espn.odds_decimal({"current": {"moneyLine": {"decimal": 1.76}}}) == 1.76
    assert espn.odds_decimal({"current": {"moneyLine": {"value": 4.1}}}) == 4.1
    assert espn.odds_decimal({"moneyLine": 280}) == pytest.approx(3.8)
    assert espn.odds_decimal({"moneyLine": "-200"}) == pytest.approx(1.5)
    assert espn.odds_decimal({"odds": {"value": 1.7}}) == 1.7
    assert espn.odds_decimal({"current": {"moneyLine": {"decimal": 0.9}}}) is None
    assert espn.odds_decimal(None) is None and espn.odds_decimal({}) is None


def test_parse_event_scheduled_soccer_with_odds_and_venue():
    raw = espn.parse_event(Sport.FOOTBALL, "soccer", "eng.1", "Premier League", fx.espn_event())
    assert raw.match_id == "espn:soccer/eng.1:401878755" and espn.parse_match_id(raw.match_id) == ("soccer", "eng.1", "401878755")
    assert (raw.home.name, raw.away.team_id) == ("Manchester United", "364")
    assert raw.kickoff == datetime(2026, 11, 22, 16, 30, tzinfo=UTC) and raw.score is None
    by = {o.selection: o.decimal_odds for o in raw.odds}
    assert by == {"HOME": 1.76, "DRAW": pytest.approx(3.8), "AWAY": 4.1} and raw.odds[0].market == "1X2"
    assert raw.venue == "Old Trafford · Manchester"
    assert normalize_status(raw.raw_status) is MatchStatus.SCHEDULED


@pytest.mark.parametrize("name,state,expected", [
    ("STATUS_SCHEDULED", "pre", MatchStatus.SCHEDULED), ("STATUS_FIRST_HALF", "in", MatchStatus.LIVE),
    ("STATUS_HALFTIME", "in", MatchStatus.LIVE), ("STATUS_FULL_TIME", "post", MatchStatus.FINISHED),
    ("STATUS_FINAL", "post", MatchStatus.FINISHED), ("STATUS_POSTPONED", "post", MatchStatus.FINISHED),
    ("STATUS_POSTPONED", "pre", MatchStatus.FINISHED), ("STATUS_CANCELED", "pre", MatchStatus.FINISHED),
    ("STATUS_DELAYED", "in", MatchStatus.LIVE),
])
def test_espn_status_normalization(name, state, expected):
    ev = fx.espn_event(name=name, state=state)
    raw = espn.parse_event(Sport.FOOTBALL, "soccer", "eng.1", "x", ev)
    assert normalize_status(raw.raw_status) is expected


def test_parse_event_live_score_and_clock_by_sport():
    live = espn.parse_event(Sport.FOOTBALL, "soccer", "eng.1", "x", fx.espn_event(state="in", name="STATUS_SECOND_HALF", scores=("2", "1"), display_clock="67'"))
    assert (live.score.home, live.score.away, live.clock.label) == (2, 1, "67'")
    ht = espn.parse_event(Sport.FOOTBALL, "soccer", "eng.1", "x", fx.espn_event(state="in", name="STATUS_HALFTIME", scores=("1", "1")))
    assert ht.clock.label == "Descanso"
    nba = espn.parse_event(Sport.BASKETBALL, "basketball", "nba", "NBA", fx.espn_event(state="in", name="STATUS_IN_PROGRESS", scores=("58", "61"), period=3, display_clock="5:12"))
    assert nba.clock.label == "Q3 5:12" and nba.odds[0].market == "ML"
    assert espn.parse_event(Sport.FOOTBALL, "soccer", "x", "x", {"id": "1"}) is None  # evento incompleto: se descarta


def test_lineups_from_soccer_summary_validate_ok_and_missing():
    raw = espn.parse_event(Sport.FOOTBALL, "soccer", "eng.1", "x", fx.espn_event())
    h, a = espn.lineups_from_summary(raw, fx.soccer_summary("360", "364"))
    m = Match.from_raw(dataclasses.replace(raw, home_lineup=h, away_lineup=a), MatchStatus.SCHEDULED)
    check = validate_lineups(m)
    assert check.ok, check.summary()
    assert len(h.starters) == 11 and h.starters[0].position == "G"
    none_h, none_a = espn.lineups_from_summary(raw, fx.soccer_summary("360", "364", lineups=False))
    assert none_h is None and none_a is None  # sin alineación publicada → LINEUP_REQUIRED (falla seguro)
    partial = espn.lineups_from_summary(raw, fx.soccer_summary("360", "364", starters=10))[0]
    m2 = Match.from_raw(dataclasses.replace(raw, home_lineup=partial, away_lineup=a), MatchStatus.SCHEDULED)
    assert not validate_lineups(m2).ok


def test_nba_lineups_players_and_injuries():
    def inj(out_id, dtd_id):
        return [{"team": {"id": "H"}, "injuries": [{"athlete": {"id": out_id, "displayName": "X"}, "status": "Out"},
                                                    {"athlete": {"id": dtd_id, "displayName": "Y"}, "status": "Day-To-Day"}]}]
    raw = espn.parse_event(Sport.BASKETBALL, "basketball", "nba", "NBA", fx.espn_event(home=("H", "Home", "H"), away=("A", "Away", "A")))

    def check(injuries):
        h, a = espn.lineups_from_summary(raw, fx.nba_summary("H", "A", injuries=injuries))
        return h, validate_lineups(Match.from_raw(dataclasses.replace(raw, home_lineup=h, away_lineup=a), MatchStatus.SCHEDULED))

    h, ok = check(inj("H8", "H7"))  # H8 (OUT) y H7 (dudoso) están en el banquillo → no bloquea
    assert len(h.starters) == 5 and h.injury_report_published
    assert {e.status.value for e in h.injury_report} == {"OUT", "QUESTIONABLE"} and ok.ok and not ok.issues
    _, blocked = check(inj("H3", "H7"))  # H3 es titular y figura OUT → incoherencia: bloquea
    assert not blocked.ok and blocked.issues[0].code.value == "STARTER_RULED_OUT"
    _, warned = check(inj("H8", "H2"))  # titular dudoso → solo aviso
    assert warned.ok and [w.code.value for w in warned.warnings] == ["STARTER_UNCERTAIN"]
    assert not espn.lineups_from_summary(raw, fx.nba_summary("H", "A"))[0].injury_report_published
    assert espn.lineups_from_summary(raw, fx.nba_summary("H", "A", home_kw={"starters": False}))[0] is None


def test_parse_finished_and_date_windows():
    data = fx.scoreboard(
        fx.espn_event("1", state="post", name="STATUS_FULL_TIME", scores=("2", "1")),
        fx.espn_event("2", state="post", name="STATUS_POSTPONED", scores=("0", "0")),
        fx.espn_event("3", state="pre"),
    )
    games = espn.parse_finished(data, "eng.1")
    assert [(g.event_id, g.home_score, g.away_score) for g in games] == [("1", 2.0, 1.0)]
    wins = espn.date_windows(date(2026, 11, 23), 300)
    assert wins == espn.date_windows(date(2026, 11, 23), 300)  # estables
    assert all((b - a).days == 89 for a, b in wins) and wins[-1][0] <= date(2026, 11, 23) <= wins[-1][1]
    assert espn.date_windows(date(2026, 11, 24), 300)[:-1] == wins[:-1] or len(espn.date_windows(date(2026, 11, 24), 300)) >= len(wins) - 1


class FakeEspnClient(espn.EspnClient):
    def __init__(self, boards=None, summaries=None, finished=()):
        self.boards, self.summaries, self._finished, self.workers = boards or {}, summaries or {}, list(finished), 1
        self.summary_calls = []

    def scoreboard(self, sport_path, league, dates=None, limit=None, ttl=45.0):
        if league in self.boards:
            return self.boards[league]
        raise ProviderError("sin conexión")

    def summary(self, sport_path, league, event_id, *, final=False):
        self.summary_calls.append(event_id)
        if event_id in self.summaries:
            return self.summaries[event_id]
        raise ProviderError("404")

    def finished_games(self, sport_path, leagues, until, lookback_days):
        return list(self._finished)

    def map(self, fn, items):
        return [fn(i) for i in items]


def test_provider_fetches_lineups_only_inside_window_and_survives_partial_failures():
    near = fx.espn_event("1", date="2026-11-22T16:30Z")
    far = fx.espn_event("2", date="2026-11-22T23:30Z", home=("1", "A", "A"), away=("2", "B", "B"))
    client = FakeEspnClient(boards={"eng.1": fx.scoreboard(near, far)}, summaries={"1": fx.soccer_summary("360", "364")})
    now = datetime(2026, 11, 22, 15, 0, tzinfo=UTC)
    prov = espn.EspnProvider(client, ["eng.1", "esp.1"], lineup_window_hours=3, clock=lambda: now)
    raws = prov.fetch_matches(Sport.FOOTBALL, date(2026, 11, 22))  # esp.1 falla pero eng.1 responde
    by = {r.match_id.split(":")[-1]: r for r in raws}
    assert by["1"].home_lineup is not None and by["2"].home_lineup is None
    assert client.summary_calls == ["1"]  # el partido lejano no consulta el resumen
    assert prov.fetch_matches(Sport.BASEBALL, date(2026, 11, 22)) == []
    with pytest.raises(ProviderError):
        espn.EspnProvider(FakeEspnClient(), ["eng.1"]).fetch_matches(Sport.FOOTBALL, date(2026, 11, 22))


def test_composite_provider_routes_by_sport():
    class P:
        name, status_map = "p", {}
        def __init__(self, tag): self.tag = tag
        def fetch_matches(self, sport, day): return [self.tag]
    c = CompositeProvider({Sport.FOOTBALL: P("f")})
    assert c.fetch_matches(Sport.FOOTBALL, date(2026, 1, 1)) == ["f"]
    with pytest.raises(ProviderError):
        c.fetch_matches(Sport.BASEBALL, date(2026, 1, 1))


# -------------------------------------------------------------------------- MLB
def test_parse_mlb_game_lineups_pitchers_and_validation():
    raw = mlb.parse_game(fx.mlb_game())
    assert raw.match_id == "mlb:777001" and raw.home.short_name == "NYY" and raw.venue == "Yankee Stadium · Bronx"
    assert normalize_status(raw.raw_status) is MatchStatus.SCHEDULED
    assert [s.batting_order for s in raw.home_lineup.starters] == list(range(1, 10))
    assert raw.home_lineup.pitcher_confirmed and raw.home_lineup.starting_pitcher.name == "Gerrit Local"
    assert validate_lineups(Match.from_raw(raw, MatchStatus.SCHEDULED)).ok


def test_mlb_probable_pitcher_without_lineup_is_not_official():
    raw = mlb.parse_game(fx.mlb_game(lineups=False))
    assert not raw.home_lineup.is_official and raw.home_lineup.starting_pitcher is not None and not raw.home_lineup.pitcher_confirmed
    assert not validate_lineups(Match.from_raw(raw, MatchStatus.SCHEDULED)).ok
    assert mlb.parse_game(fx.mlb_game(lineups=False, pitchers=False)).home_lineup is None


@pytest.mark.parametrize("abstract,detailed,expected", [
    ("Preview", "Pre-Game", MatchStatus.SCHEDULED), ("Live", "In Progress", MatchStatus.LIVE), ("Live", "Delayed: Rain", MatchStatus.LIVE),
    ("Final", "Final", MatchStatus.FINISHED), ("Final", "Game Over", MatchStatus.FINISHED), ("Preview", "Postponed", MatchStatus.FINISHED),
    ("Final", "Cancelled", MatchStatus.FINISHED),
])
def test_mlb_status_normalization(abstract, detailed, expected):
    raw = mlb.parse_game(fx.mlb_game(abstract=abstract, detailed=detailed, scores=(3, 2) if abstract != "Preview" else None))
    assert normalize_status(raw.raw_status) is expected


def test_mlb_live_score_and_inning_clock():
    raw = mlb.parse_game(fx.mlb_game(abstract="Live", detailed="In Progress", scores=(3, 2), inning=(7, "Top")))
    assert (raw.score.home, raw.score.away, raw.clock.label) == (3, 2, "▲ 7")


def test_mlb_finished_parsing_and_helpers():
    data = {"dates": [{"games": [
        {"gamePk": 1, "gameDate": "2026-07-01T23:00:00Z", "status": {"abstractGameState": "Final", "detailedState": "Final"},
         "teams": {"home": {"team": {"id": 147}, "score": 5}, "away": {"team": {"id": 111}, "score": 3}}},
        {"gamePk": 2, "gameDate": "2026-07-02T23:00:00Z", "status": {"abstractGameState": "Final", "detailedState": "Postponed"},
         "teams": {"home": {"team": {"id": 147}}, "away": {"team": {"id": 111}}}}]}]}
    assert [(g.event_id, g.home_id, g.home_score) for g in mlb.parse_finished(data)] == [("1", "147", 5.0)]
    assert mlb.innings("6.2") == pytest.approx(6.6667, abs=1e-3) and mlb.innings("garbage") == 0.0
    assert mlb.parse_wind("12 mph, Out To CF") > 0 > mlb.parse_wind("12 mph, In From LF") and mlb.parse_wind("8 mph, L To R") == 0.0


def test_fip_xfip_and_ops_plus_formulas():
    pitching = {"1": {"inningsPitched": "1000.0", "homeRuns": 150, "baseOnBalls": 350, "hitBatsmen": 40, "strikeOuts": 1000, "earnedRuns": 450, "airOuts": 1050},
                "2": {"inningsPitched": "1000.0", "homeRuns": 150, "baseOnBalls": 350, "hitBatsmen": 40, "strikeOuts": 1000, "earnedRuns": 450, "airOuts": 1050}}
    c = mlb.fip_constants(pitching)
    assert c["lg_era"] == pytest.approx(4.05) and c["c_fip"] == pytest.approx(4.05 - (13 * 150 + 3 * 390 - 2000) / 1000)
    league_like = mlb.pitcher_metrics(pitching["1"], c)
    assert league_like["fip"] == pytest.approx(c["lg_era"])  # el FIP de un equipo promedio = ERA de liga por construcción
    assert league_like["xfip"] == pytest.approx(c["lg_era"], abs=0.01)  # HR/FB de liga aplicado a sí mismo
    ace = {"inningsPitched": "180.0", "homeRuns": 14, "baseOnBalls": 30, "hitBatsmen": 4, "strikeOuts": 220, "airOuts": 200, "gamesStarted": 30}
    m = mlb.pitcher_metrics(ace, c)
    assert m["fip"] < 3.0 and m["ip_per_start"] == pytest.approx(6.0)
    lg = {"lg_obp": 0.320, "lg_slg": 0.410}
    assert mlb.ops_plus({"obp": ".320", "slg": ".410"}, lg) == pytest.approx(100.0)
    assert mlb.ops_plus({"obp": ".360", "slg": ".480"}, lg) > 115 and mlb.ops_plus({}, lg) is None


class FakeMlbClient(mlb.MlbClient):
    def __init__(self, schedule_data):
        self.data, self.workers = schedule_data, 1
    def schedule(self, start, end, **kw):
        return self.data


def test_mlb_provider_joins_espn_odds_by_team_names():
    sched = {"dates": [{"games": [fx.mlb_game()]}]}
    espn_ev = fx.espn_event("9", home=("10", "New York Yankees", "NYY"), away=("2", "Boston Red Sox", "BOS"), date="2026-07-04T23:05Z",
                            league_odds=[{"provider": {"name": "DK"}, "homeTeamOdds": {"current": {"moneyLine": {"decimal": 1.6}}},
                                          "awayTeamOdds": {"current": {"moneyLine": {"decimal": 2.4}}}}])
    odds_client = FakeEspnClient(boards={"mlb": fx.scoreboard(espn_ev)})
    raws = mlb.MlbProvider(FakeMlbClient(sched), odds_client).fetch_matches(Sport.BASEBALL, date(2026, 7, 4))
    assert [(o.selection, o.decimal_odds, o.market) for o in raws[0].odds] == [("HOME", 1.6, "ML"), ("AWAY", 2.4, "ML")]
    no_odds = mlb.MlbProvider(FakeMlbClient(sched), FakeEspnClient()).fetch_matches(Sport.BASEBALL, date(2026, 7, 4))
    assert no_odds[0].odds == ()  # ESPN caído: sigue funcionando sin cuotas
