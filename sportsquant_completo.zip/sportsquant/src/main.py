"""Punto de entrada de Flet (`flet run` / `flet build apk`)."""
import logging

import flet as ft

from sportsquant.services import create_services
from sportsquant.ui.app import SportsQuantApp

logging.basicConfig(level=logging.INFO)


def main(page: ft.Page) -> None:
    services = create_services()
    app = SportsQuantApp(page, services)
    page.on_close = lambda e: (app.stop(), services.close())
    app.start()


ft.run(main)
