"""Ejecución de proyecciones bajo demanda, un partido a la vez y en un hilo aparte.

Nunca se proyecta la cartelera completa: solo `submit(match_id)` tras pulsar «Proyectar».
Un único hilo de trabajo serializa las solicitudes para no saturar el teléfono.
"""
from __future__ import annotations

import logging
import threading
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum

from ..data.context import ContextFactory
from ..data.storage import Storage
from ..matches.gate import projection_gate
from ..matches.providers.base import ProviderError
from ..matches.service import MatchService
from ..projection.engine import ProjectionEngine, ProjectionError
from ..projection.results import ProjectionResult, clamp_simulations

log = logging.getLogger(__name__)


class ProjState(str, Enum):
    IDLE = "IDLE"
    QUEUED = "QUEUED"
    RUNNING = "RUNNING"
    DONE = "DONE"
    ERROR = "ERROR"
    BLOCKED = "BLOCKED"


@dataclass(frozen=True, slots=True)
class ProjStatus:
    state: ProjState = ProjState.IDLE
    message: str = ""
    result: ProjectionResult | None = None

    @property
    def busy(self) -> bool:
        return self.state in (ProjState.QUEUED, ProjState.RUNNING)


Listener = Callable[[str, ProjStatus], None]


class ProjectionWorker:
    def __init__(self, service: MatchService, factory: ContextFactory, engine: ProjectionEngine, storage: Storage,
                 clock: Callable[[], datetime] | None = None) -> None:
        self._service, self._factory, self._engine, self._storage = service, factory, engine, storage
        self._clock = clock or (lambda: datetime.now(timezone.utc))
        self._pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="projection")
        self._status: dict[str, ProjStatus] = {}
        self._lock = threading.Lock()

    def status(self, match_id: str) -> ProjStatus:
        with self._lock:
            return self._status.get(match_id, ProjStatus())

    def _set(self, match_id: str, status: ProjStatus, listener: Listener | None) -> ProjStatus:
        with self._lock:
            self._status[match_id] = status
        if listener is not None:
            try:
                listener(match_id, status)
            except Exception:  # un fallo de la UI no debe romper el cálculo
                log.exception("Error en el listener de proyección")
        return status

    def submit(self, match_id: str, n_simulations: int, listener: Listener | None = None, *, seed: int | None = None,
               wait: bool = False) -> ProjStatus:
        n = clamp_simulations(n_simulations)
        with self._lock:
            current = self._status.get(match_id, ProjStatus())
            if current.busy:  # doble toque: se ignora
                return current
        gate = self._service.gate(match_id)
        if not gate.allowed:
            return self._set(match_id, ProjStatus(ProjState.BLOCKED, gate.reason), listener)
        status = self._set(match_id, ProjStatus(ProjState.QUEUED, "En cola…"), listener)
        future = self._pool.submit(self._run, match_id, n, listener, seed)
        if wait:
            future.result()
            return self.status(match_id)
        return status

    def _run(self, match_id: str, n: int, listener: Listener | None, seed: int | None) -> None:
        try:
            self._set(match_id, ProjStatus(ProjState.RUNNING, "Calculando…"), listener)
            gate = self._service.gate(match_id)  # el reloj pudo avanzar mientras estaba en cola
            match = self._service.get(match_id)
            if match is None or not gate.allowed:
                reason = gate.reason if match is not None else "El partido ya no está disponible."
                self._set(match_id, ProjStatus(ProjState.BLOCKED, reason), listener)
                return
            asof = self._clock()
            ctx = self._factory.build(match, asof)  # E/S de red: puede tardar
            fresh = self._service.get(match_id) or match
            gate = projection_gate(fresh, self._clock())  # t < T de nuevo, justo antes de simular
            if not gate.allowed:
                self._set(match_id, ProjStatus(ProjState.BLOCKED, gate.reason), listener)
                return
            result = self._engine.project(ctx, n, seed=seed, now=self._clock())
            self._storage.save_projection(result)
            self._set(match_id, ProjStatus(ProjState.DONE, "Proyección lista", result), listener)
        except (ProjectionError, ProviderError) as exc:
            self._set(match_id, ProjStatus(ProjState.ERROR, str(exc)), listener)
        except Exception as exc:  # noqa: BLE001 — se informa a la UI en vez de matar el hilo
            log.exception("Fallo inesperado proyectando %s", match_id)
            self._set(match_id, ProjStatus(ProjState.ERROR, f"Error inesperado: {exc}"), listener)

    def shutdown(self) -> None:
        self._pool.shutdown(wait=False, cancel_futures=True)
