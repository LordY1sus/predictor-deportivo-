"""Datos de entrada del motor de proyección (independientes de la fuente de datos)."""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime

from .models import Match


@dataclass(frozen=True, slots=True)
class LeagueGame:
    """Resultado terminado usado para ajustar fuerzas por rival (IPF)."""

    home_id: str
    away_id: str
    home_score: float
    away_score: float
    played_at: datetime  # aware
    neutral: bool = False


@dataclass(frozen=True, slots=True)
class PastGame:
    """Partido ya jugado visto desde un equipo."""

    game_id: str
    played_at: datetime  # aware
    opponent_id: str
    is_home: bool
    scored: float
    conceded: float
    neutral: bool = False
    weight: float = 1.0  # peso de competición (liga 1.0, copa < 1.0)
    xg_for: float | None = None  # xG o proxy por tiros
    xg_against: float | None = None


@dataclass(frozen=True, slots=True)
class PlayerValue:
    player_id: str
    name: str
    group: str  # GK/DEF/MID/FWD | G/F/C | BAT/SP/RP
    usage: float = 0.0  # 0..1: fracción de partidos como titular / PA relativos
    off_value: float = 0.0
    def_value: float = 0.0
    minutes: float = 0.0  # baloncesto: minutos por partido del equipo


@dataclass(frozen=True, slots=True)
class TeamData:
    team_id: str
    history: tuple[PastGame, ...] = ()
    players: tuple[PlayerValue, ...] = ()
    active_ids: tuple[str, ...] = ()  # titulares oficiales hoy (en orden al bate en béisbol)
    availability: Mapping[str, float] = field(default_factory=dict)  # prob. de jugar (OUT=0)
    metrics: Mapping[str, float] = field(default_factory=dict)  # ver cada capa/constructor


@dataclass(frozen=True, slots=True)
class LeagueData:
    avg_home: float  # promedio de anotación del local (goles/puntos/carreras)
    avg_away: float
    att: Mapping[str, float] = field(default_factory=dict)  # fuerza ofensiva (media = 1)
    defn: Mapping[str, float] = field(default_factory=dict)  # permisividad defensiva (media = 1; <1 = mejor)
    n_games: int = 0
    metrics: Mapping[str, float] = field(default_factory=dict)  # pace, ortg, lg_fip, runs_pg...


@dataclass(frozen=True, slots=True)
class Venue:
    name: str | None = None
    city: str | None = None
    lat: float | None = None
    lon: float | None = None
    neutral: bool = False
    roof: str = "open"  # open | retractable | dome
    park_factor: float | None = None  # factor de carreras (béisbol), 1.0 = neutro


@dataclass(frozen=True, slots=True)
class Weather:
    temp_c: float | None = None
    wind_ms: float | None = None
    wind_out_ms: float | None = None  # béisbol: positivo = viento hacia afuera del campo
    precip_mm: float | None = None
    precip_prob: float | None = None


@dataclass(frozen=True, slots=True)
class MatchContext:
    match: Match
    home: TeamData
    away: TeamData
    league: LeagueData
    venue: Venue = field(default_factory=Venue)
    weather: Weather | None = None
    asof: datetime | None = None  # instante t de corte (debe ser < inicio T)
    notes: tuple[str, ...] = ()  # avisos de la construcción de datos
