"""Enumeraciones compartidas por todo el proyecto."""
from __future__ import annotations

from enum import Enum


class Sport(str, Enum):
    FOOTBALL = "football"
    BASKETBALL = "basketball"
    BASEBALL = "baseball"


class MatchStatus(str, Enum):
    SCHEDULED = "SCHEDULED"
    LIVE = "LIVE"
    FINISHED = "FINISHED"


class Side(str, Enum):
    HOME = "home"
    AWAY = "away"


class InjuryStatus(str, Enum):
    AVAILABLE = "AVAILABLE"
    QUESTIONABLE = "QUESTIONABLE"
    DOUBTFUL = "DOUBTFUL"
    OUT = "OUT"


class LineupStatus(str, Enum):
    OK = "OK"
    LINEUP_REQUIRED = "LINEUP_REQUIRED"


class GateCode(str, Enum):
    """Resultado de la compuerta que habilita (o no) el botón «Proyectar»."""

    OK = "OK"
    NOT_SCHEDULED = "NOT_SCHEDULED"
    KICKOFF_PASSED = "KICKOFF_PASSED"  # regla t < T
    LINEUP_REQUIRED = "LINEUP_REQUIRED"


class IssueCode(str, Enum):
    LINEUP_MISSING = "LINEUP_MISSING"
    TEAM_MISMATCH = "TEAM_MISMATCH"
    NOT_OFFICIAL = "NOT_OFFICIAL"
    PUBLISHED_AFTER_KICKOFF = "PUBLISHED_AFTER_KICKOFF"
    WRONG_STARTER_COUNT = "WRONG_STARTER_COUNT"
    DUPLICATE_PLAYER = "DUPLICATE_PLAYER"
    GOALKEEPER_INVALID = "GOALKEEPER_INVALID"
    INJURY_REPORT_MISSING = "INJURY_REPORT_MISSING"
    BATTING_ORDER_INVALID = "BATTING_ORDER_INVALID"
    PITCHER_MISSING = "PITCHER_MISSING"
    PITCHER_NOT_CONFIRMED = "PITCHER_NOT_CONFIRMED"
    STARTER_RULED_OUT = "STARTER_RULED_OUT"  # bloqueante
    STARTER_UNCERTAIN = "STARTER_UNCERTAIN"  # solo aviso
