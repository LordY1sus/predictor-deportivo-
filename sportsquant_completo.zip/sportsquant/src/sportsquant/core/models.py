"""Modelos de dominio inmutables (seguros para pasar entre hilos sin locks)."""
from __future__ import annotations

import math
from dataclasses import dataclass, fields
from datetime import datetime, timedelta

from .enums import InjuryStatus, MatchStatus, Side, Sport
from .timeutil import to_utc


@dataclass(frozen=True, slots=True)
class Team:
    team_id: str
    name: str
    short_name: str = ""

    @property
    def label(self) -> str:
        return self.short_name or self.name


@dataclass(frozen=True, slots=True)
class PlayerSlot:
    player_id: str
    name: str
    position: str | None = None  # "GK", "PG", "SS", "P"...
    batting_order: int | None = None  # béisbol: 1-9


@dataclass(frozen=True, slots=True)
class InjuryEntry:
    player_id: str
    name: str
    status: InjuryStatus


@dataclass(frozen=True, slots=True)
class TeamLineup:
    team_id: str
    starters: tuple[PlayerSlot, ...] = ()
    bench: tuple[PlayerSlot, ...] = ()
    is_official: bool = False  # False = alineación probable / proyectada
    published_at: datetime | None = None  # debe ser aware
    source: str = ""
    # Béisbol
    starting_pitcher: PlayerSlot | None = None
    pitcher_confirmed: bool = False
    # Baloncesto (y cualquier deporte que publique reporte)
    injury_report_published: bool = False
    injury_report: tuple[InjuryEntry, ...] = ()

    def __post_init__(self) -> None:
        if self.published_at is not None and self.published_at.utcoffset() is None:
            raise ValueError("published_at debe incluir zona horaria")


@dataclass(frozen=True, slots=True)
class OddsLine:
    market: str  # "1X2" (fútbol), "ML" (baloncesto/béisbol)
    selection: str  # "HOME" | "DRAW" | "AWAY"
    decimal_odds: float
    bookmaker: str = ""

    def __post_init__(self) -> None:
        if not (math.isfinite(self.decimal_odds) and self.decimal_odds > 1.0):
            raise ValueError(f"Cuota decimal inválida: {self.decimal_odds!r} (debe ser > 1.0)")

    @property
    def implied_probability(self) -> float:
        return 1.0 / self.decimal_odds


@dataclass(frozen=True, slots=True)
class Score:
    home: int
    away: int


@dataclass(frozen=True, slots=True)
class LiveClock:
    label: str  # texto listo para la UI: "67'", "Q3 05:12", "▲ 7"
    period: int | None = None  # cuarto o inning


@dataclass(frozen=True, slots=True)
class RawMatch:
    """Lo que entrega un proveedor: aún sin normalizar el estado."""

    match_id: str
    sport: Sport
    competition: str
    kickoff: datetime  # aware, en cualquier zona
    home: Team
    away: Team
    raw_status: str
    score: Score | None = None
    clock: LiveClock | None = None
    odds: tuple[OddsLine, ...] = ()
    home_lineup: TeamLineup | None = None
    away_lineup: TeamLineup | None = None
    venue: str | None = None
    neutral_venue: bool = False


@dataclass(frozen=True, slots=True)
class Match:
    match_id: str
    sport: Sport
    competition: str
    kickoff_utc: datetime
    home: Team
    away: Team
    status: MatchStatus
    raw_status: str = ""
    score: Score | None = None
    clock: LiveClock | None = None
    odds: tuple[OddsLine, ...] = ()
    home_lineup: TeamLineup | None = None
    away_lineup: TeamLineup | None = None
    venue: str | None = None
    neutral_venue: bool = False

    def __post_init__(self) -> None:
        offset = self.kickoff_utc.utcoffset()
        if offset is None or offset != timedelta(0):
            raise ValueError("kickoff_utc debe ser un datetime aware en UTC")

    @property
    def title(self) -> str:
        return f"{self.home.label} vs {self.away.label}"

    def team_for(self, side: Side) -> Team:
        return self.home if side is Side.HOME else self.away

    def lineup_for(self, side: Side) -> TeamLineup | None:
        return self.home_lineup if side is Side.HOME else self.away_lineup

    @classmethod
    def from_raw(cls, raw: RawMatch, status: MatchStatus) -> Match:
        data = {f.name: getattr(raw, f.name) for f in fields(raw)}
        data["kickoff_utc"] = to_utc(data.pop("kickoff"))
        return cls(status=status, **data)
