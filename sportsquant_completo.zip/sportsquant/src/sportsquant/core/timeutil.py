"""Utilidades de tiempo. Todo instante interno es UTC y consciente de zona."""
from __future__ import annotations

from datetime import date, datetime, timezone, tzinfo


def ensure_aware(dt: datetime, name: str = "datetime") -> datetime:
    if dt.tzinfo is None or dt.utcoffset() is None:
        raise ValueError(f"{name} debe incluir zona horaria (datetime 'naive' no permitido)")
    return dt


def to_utc(dt: datetime) -> datetime:
    return ensure_aware(dt).astimezone(timezone.utc)


def resolve_tz(name: str | None) -> tzinfo:
    """Zona del usuario. Sin nombre -> zona local del dispositivo (no requiere tzdata)."""
    if name:
        from zoneinfo import ZoneInfo

        return ZoneInfo(name)
    return datetime.now().astimezone().tzinfo or timezone.utc


def local_date(dt: datetime, tz: tzinfo) -> date:
    return to_utc(dt).astimezone(tz).date()
