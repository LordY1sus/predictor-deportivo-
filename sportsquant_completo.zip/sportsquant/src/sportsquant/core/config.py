"""Ajustes del módulo de partidos."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import tzinfo

from .timeutil import resolve_tz


@dataclass(frozen=True, slots=True)
class Settings:
    # None -> zona local del dispositivo. Ej.: "America/Caracas" (requiere tzdata en Android).
    timezone: str | None = None
    # Mantiene visible un partido LIVE que empezó "ayer" local y cruza la medianoche.
    include_live_carryover: bool = True

    def tz(self) -> tzinfo:
        # Se resuelve en cada uso: así un cambio de zona/horario del teléfono se respeta.
        return resolve_tz(self.timezone)
