"""Componentes visuales puros (sin estado): tarjeta de partido, ranking y panel de resultado."""
from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass

import flet as ft

from ..betting.ranking import BetCandidate, selection_label
from ..core.enums import GateCode, MatchStatus, Side, Sport
from ..core.models import Match, OddsLine
from ..matches.gate import ProjectionGate
from ..projection.results import ProjectionResult
from ..workers.projection_worker import ProjState, ProjStatus

SPORT_LABELS = {Sport.FOOTBALL: "Fútbol", Sport.BASKETBALL: "Baloncesto", Sport.BASEBALL: "Béisbol"}
SELECTION_ORDER = ("HOME", "DRAW", "AWAY")


@dataclass(frozen=True)
class MatchView:
    match: Match
    gate: ProjectionGate
    proj: ProjStatus
    result: ProjectionResult | None
    odds: tuple[OddsLine, ...]
    bets: tuple[BetCandidate, ...]
    local_time: str


@dataclass(frozen=True)
class CardHandlers:
    on_project: Callable[[str], None]
    on_edit_odds: Callable[[str], None]


def pct(x: float, digits: int = 1) -> str:
    return f"{100 * x:.{digits}f}%"


def chip(text: str, color: str, *, text_color: str = ft.Colors.WHITE) -> ft.Container:
    return ft.Container(
        content=ft.Text(text, size=11, weight=ft.FontWeight.BOLD, color=text_color),
        bgcolor=color, padding=ft.Padding.symmetric(horizontal=8, vertical=2), border_radius=ft.BorderRadius.all(10),
    )


def status_chip(match: Match) -> ft.Container:
    return {
        MatchStatus.LIVE: chip("LIVE", ft.Colors.RED_700),
        MatchStatus.SCHEDULED: chip("SCHEDULED", ft.Colors.BLUE_GREY_700),
        MatchStatus.FINISHED: chip("FINISHED", ft.Colors.GREY_800),
    }[match.status]


def lineup_chip(gate: ProjectionGate) -> ft.Container:
    ok = gate.lineup is not None and gate.lineup.ok
    return chip("ALINEACIÓN OFICIAL" if ok else "ALINEACIÓN PENDIENTE", ft.Colors.GREEN_700 if ok else ft.Colors.AMBER_800)


def pitchers_text(match: Match) -> str | None:
    if match.sport is not Sport.BASEBALL:
        return None
    names = []
    for side in (Side.HOME, Side.AWAY):
        lu = match.lineup_for(side)
        sp = lu.starting_pitcher if lu else None
        mark = "" if (lu and lu.pitcher_confirmed) else " (prob.)"
        names.append(f"{sp.name}{mark}" if sp else "por confirmar")
    return f"Abridores: {names[0]} vs {names[1]}"


def odds_text(match: Match, odds: Sequence[OddsLine]) -> str:
    if not odds:
        return "Sin cuotas · toca ✎ para ingresarlas"
    by = {o.selection: o for o in odds}
    parts = [f"{selection_label(match, s).replace('Gana ', '')} {by[s].decimal_odds:.2f}" for s in SELECTION_ORDER if s in by]
    books = {o.bookmaker for o in odds if o.bookmaker}
    return "Cuotas: " + " · ".join(parts) + (f" ({', '.join(sorted(books))})" if books else "")


def score_line(match: Match) -> str:
    if match.score is None:
        return ""
    clock = f" · {match.clock.label}" if match.clock else ""
    return f"{match.score.home} – {match.score.away}{clock}"


def prob_row(label: str, p: float, se: float, bet: BetCandidate | None) -> ft.Control:
    extra = f"  ·  implícita {pct(bet.p_implied)}  ·  EV {bet.ev:+.1%}" if bet else ""
    return ft.Column(spacing=2, controls=[
        ft.Text(f"{label}: {pct(p)} ±{pct(se)}{extra}", size=12),
        ft.ProgressBar(value=max(0.0, min(1.0, p)), bar_height=6),
    ])


def result_panel(match: Match, result: ProjectionResult, bets: Sequence[BetCandidate]) -> ft.ExpansionTile:
    by_sel = {b.selection: b for b in bets}
    rows: list[ft.Control] = [
        prob_row(selection_label(match, s), result.probs[s], result.mc_se.get(s, 0.0), by_sel.get(s))
        for s in SELECTION_ORDER if s in result.probs
    ]
    unit = {"football": "goles", "basketball": "puntos", "baseball": "carreras"}[result.sport]
    rows.append(ft.Text(f"Marcador esperado: {result.exp_home:.2f} – {result.exp_away:.2f} ({unit}); total {result.exp_total:.2f}", size=12))
    if result.top_scores:
        top = ", ".join(f"{h}-{a} ({pct(p)})" for h, a, p in result.top_scores[:3])
        rows.append(ft.Text(f"Marcadores más probables: {top}", size=12))
    rows.append(ft.Text(f"{result.n_simulations:,} simulaciones · cobertura de datos {pct(result.coverage, 0)}", size=11, italic=True))
    for l in result.layers:
        rows.append(ft.Text(f"{l.name}: local ×{l.home_mult:.3f} · visita ×{l.away_mult:.3f} · cobertura {pct(l.coverage, 0)}",
                            size=11, weight=ft.FontWeight.BOLD))
        rows += [ft.Text(f"   • {n}", size=10, color=ft.Colors.GREY_400) for n in l.notes]
    rows += [ft.Text(f"⚠ {n}", size=10, color=ft.Colors.AMBER_400) for n in result.notes]
    best = max(bets, key=lambda b: b.ev, default=None)
    title = (f"Resultado · mejor EV: {best.label} {best.ev:+.1%}" if best else "Resultado de la proyección")
    return ft.ExpansionTile(title=ft.Text(title, size=13), controls=[ft.Container(padding=8, content=ft.Column(rows, spacing=4))])


def match_card(view: MatchView, handlers: CardHandlers) -> ft.Card:
    m, proj = view.match, view.proj
    header = ft.Row(
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN, vertical_alignment=ft.CrossAxisAlignment.CENTER,
        controls=[ft.Row(spacing=6, controls=[status_chip(m), ft.Text(m.competition, size=11, color=ft.Colors.GREY_400)]),
                  ft.Text(view.local_time if m.status is MatchStatus.SCHEDULED else score_line(m), size=14, weight=ft.FontWeight.BOLD)],
    )
    body: list[ft.Control] = [header, ft.Text(f"{m.home.name}  vs  {m.away.name}", size=15, weight=ft.FontWeight.BOLD)]
    if (p := pitchers_text(m)):
        body.append(ft.Text(p, size=12, color=ft.Colors.GREY_300))
    if m.status is MatchStatus.LIVE and m.score is not None:
        body.append(ft.Text(score_line(m), size=22, weight=ft.FontWeight.BOLD))
    body.append(ft.Row(spacing=6, vertical_alignment=ft.CrossAxisAlignment.CENTER, controls=[
        ft.Text(odds_text(m, view.odds), size=12, expand=True),
        ft.IconButton(icon=ft.Icons.EDIT, tooltip="Editar cuotas", on_click=lambda e, i=m.match_id: handlers.on_edit_odds(i)),
    ]))
    if m.status is MatchStatus.SCHEDULED:
        body.append(lineup_chip(view.gate))
        busy = proj.busy
        allowed = view.gate.allowed and not busy
        controls: list[ft.Control] = [ft.Button(
            content="Proyectar" if not busy else "Calculando…", icon=ft.Icons.PLAY_ARROW, disabled=not allowed,
            tooltip=None if view.gate.allowed else view.gate.reason,
            on_click=lambda e, i=m.match_id: handlers.on_project(i))]
        if busy:
            controls.append(ft.ProgressRing(width=18, height=18, stroke_width=2))
        body.append(ft.Row(spacing=10, vertical_alignment=ft.CrossAxisAlignment.CENTER, controls=controls))
        if not view.gate.allowed:
            color = ft.Colors.AMBER_300 if view.gate.code is GateCode.LINEUP_REQUIRED else ft.Colors.GREY_400
            body.append(ft.Text(view.gate.reason, size=11, color=color))
        if proj.state in (ProjState.ERROR, ProjState.BLOCKED) and proj.message and proj.message != view.gate.reason:
            body.append(ft.Text(proj.message, size=11, color=ft.Colors.RED_300))
        if view.result is not None:
            body.append(result_panel(m, view.result, view.bets))
    return ft.Card(content=ft.Container(padding=12, content=ft.Column(body, spacing=6)))


def ranking_tile(rank: int, bet: BetCandidate) -> ft.Card:
    return ft.Card(content=ft.Container(padding=10, content=ft.Column(spacing=2, controls=[
        ft.Text(f"{rank}. {bet.label} @ {bet.odds:.2f}", size=14, weight=ft.FontWeight.BOLD),
        ft.Text(bet.title, size=12, color=ft.Colors.GREY_300),
        ft.Text(f"P modelo {pct(bet.p_model)} (±{pct(bet.mc_se)}) vs implícita {pct(bet.p_implied)} · EV {bet.ev:+.1%}", size=12),
        ft.Text(f"Kelly fraccionado: {pct(bet.stake_fraction, 2)} de la banca · crecimiento log. esperado {bet.log_growth:.4f}", size=11,
                color=ft.Colors.GREEN_300),
    ])))
