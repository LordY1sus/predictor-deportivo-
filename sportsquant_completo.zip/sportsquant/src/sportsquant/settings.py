"""Preferencias del usuario persistidas en SQLite."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field

from .betting.ev import DEFAULT_KELLY_MULTIPLIER, DEFAULT_STAKE_CAP
from .core.enums import Sport
from .data.espn import DEFAULT_FOOTBALL_LEAGUES
from .data.storage import Storage
from .projection.results import DEFAULT_SIMULATIONS, clamp_simulations


@dataclass
class UserSettings:
    sport: str = Sport.FOOTBALL.value
    n_simulations: int = DEFAULT_SIMULATIONS
    kelly_multiplier: float = DEFAULT_KELLY_MULTIPLIER
    stake_cap: float = DEFAULT_STAKE_CAP
    football_leagues: list[str] = field(default_factory=lambda: list(DEFAULT_FOOTBALL_LEAGUES))
    auto_refresh_seconds: int = 60

    def sanitized(self) -> UserSettings:
        self.n_simulations = clamp_simulations(self.n_simulations)
        self.kelly_multiplier = min(1.0, max(0.05, float(self.kelly_multiplier)))
        self.stake_cap = min(0.25, max(0.005, float(self.stake_cap)))
        self.auto_refresh_seconds = max(20, int(self.auto_refresh_seconds))
        if self.sport not in {s.value for s in Sport}:
            self.sport = Sport.FOOTBALL.value
        self.football_leagues = [x.strip() for x in self.football_leagues if x.strip()] or list(DEFAULT_FOOTBALL_LEAGUES)
        return self


def load_settings(storage: Storage) -> UserSettings:
    raw = storage.kv_get("user_settings", {}) or {}
    known = {k: v for k, v in raw.items() if k in UserSettings.__dataclass_fields__}
    return UserSettings(**known).sanitized()


def save_settings(storage: Storage, s: UserSettings) -> None:
    storage.kv_set("user_settings", asdict(s.sanitized()))
