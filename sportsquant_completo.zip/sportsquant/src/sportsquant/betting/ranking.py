"""Candidatas de apuesta y ranking por retorno ajustado al riesgo (Kelly fraccionado)."""
from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass

from ..core.models import Match, OddsLine
from ..projection.results import ProjectionResult
from .ev import (
    DEFAULT_KELLY_MULTIPLIER, DEFAULT_STAKE_CAP, expected_log_growth, expected_value,
    fractional_kelly, implied_probability, kelly_fraction,
)


@dataclass(frozen=True, slots=True)
class BetCandidate:
    match_id: str
    sport: str
    title: str
    selection: str  # HOME | DRAW | AWAY
    label: str
    odds: float
    bookmaker: str
    p_model: float
    p_implied: float
    ev: float
    kelly_full: float
    stake_fraction: float  # Kelly fraccionado con tope
    log_growth: float  # crecimiento logarítmico esperado con esa fracción (métrica de riesgo-retorno)
    mc_se: float


def selection_label(match: Match, selection: str) -> str:
    return {"HOME": f"Gana {match.home.label}", "AWAY": f"Gana {match.away.label}", "DRAW": "Empate"}.get(selection, selection)


def merge_odds(provider: Iterable[OddsLine], manual: Mapping[str, float]) -> list[OddsLine]:
    """La cuota manual del usuario reemplaza a la del proveedor para esa selección."""
    out = {l.selection: l for l in provider}
    for sel, price in manual.items():
        if price and price > 1.0:
            base = out.get(sel)
            out[sel] = OddsLine(base.market if base else "MANUAL", sel, float(price), "manual")
    return list(out.values())


def build_candidates(
    match: Match,
    result: ProjectionResult,
    odds: Sequence[OddsLine],
    *,
    kelly_multiplier: float = DEFAULT_KELLY_MULTIPLIER,
    stake_cap: float = DEFAULT_STAKE_CAP,
) -> list[BetCandidate]:
    out: list[BetCandidate] = []
    for line in odds:
        p = result.probs.get(line.selection)
        if p is None:
            continue
        o = line.decimal_odds
        stake = fractional_kelly(p, o, kelly_multiplier, stake_cap)
        out.append(BetCandidate(
            match_id=match.match_id, sport=match.sport.value, title=match.title,
            selection=line.selection, label=selection_label(match, line.selection), odds=o,
            bookmaker=line.bookmaker, p_model=p, p_implied=implied_probability(o),
            ev=expected_value(p, o), kelly_full=kelly_fraction(p, o), stake_fraction=stake,
            log_growth=expected_log_growth(p, o, stake), mc_se=result.mc_se.get(line.selection, 0.0),
        ))
    return out


def rank_bets(candidates: Iterable[BetCandidate], *, best_per_match: bool = True) -> list[BetCandidate]:
    """Descarta EV ≤ 0 y ordena por crecimiento logarítmico esperado (desempate: EV)."""
    pos = [c for c in candidates if c.ev > 0]
    pos.sort(key=lambda c: (c.log_growth, c.ev), reverse=True)
    if not best_per_match:
        return pos
    seen: set[str] = set()
    out: list[BetCandidate] = []
    for c in pos:
        if c.match_id not in seen:
            seen.add(c.match_id)
            out.append(c)
    return out
