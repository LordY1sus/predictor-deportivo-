"""Valor esperado y criterio de Kelly con cuotas decimales."""
from __future__ import annotations

import math

DEFAULT_KELLY_MULTIPLIER = 0.25  # Kelly fraccionado (1/4)
DEFAULT_STAKE_CAP = 0.05  # tope de la fracción de banca por apuesta


def implied_probability(odds: float) -> float:
    """P_implícita = 1 / O."""
    return 1.0 / odds


def expected_value(p_model: float, odds: float) -> float:
    """EV por unidad apostada = P_modelo · O − 1."""
    return p_model * odds - 1.0


def kelly_fraction(p_model: float, odds: float) -> float:
    """Kelly completo f* = (P·O − 1)/(O − 1), nunca negativo."""
    if odds <= 1.0:
        return 0.0
    return max(0.0, (p_model * odds - 1.0) / (odds - 1.0))


def fractional_kelly(
    p_model: float, odds: float, multiplier: float = DEFAULT_KELLY_MULTIPLIER, cap: float = DEFAULT_STAKE_CAP
) -> float:
    return min(cap, multiplier * kelly_fraction(p_model, odds))


def expected_log_growth(p_model: float, odds: float, stake: float) -> float:
    """E[ln(banca final / banca inicial)] apostando la fracción `stake`."""
    if stake <= 0:
        return 0.0
    if stake >= 1.0:
        return -math.inf
    return p_model * math.log(1 + stake * (odds - 1)) + (1 - p_model) * math.log(1 - stake)
