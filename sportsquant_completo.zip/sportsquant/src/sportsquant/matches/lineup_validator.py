"""Validación de alineaciones oficiales (regla LINEUP_REQUIRED) por deporte."""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime

from ..core.enums import InjuryStatus, IssueCode, LineupStatus, Side, Sport
from ..core.models import Match, TeamLineup
from ..core.timeutil import to_utc


@dataclass(frozen=True, slots=True)
class Issue:
    code: IssueCode
    message: str  # texto en español para la UI
    side: Side | None = None


@dataclass(frozen=True, slots=True)
class TeamLineupCheck:
    side: Side
    issues: tuple[Issue, ...] = ()  # bloqueantes
    warnings: tuple[Issue, ...] = ()  # informativos, no bloquean

    @property
    def ok(self) -> bool:
        return not self.issues


@dataclass(frozen=True, slots=True)
class LineupCheck:
    home: TeamLineupCheck
    away: TeamLineupCheck

    @property
    def ok(self) -> bool:
        return self.home.ok and self.away.ok

    @property
    def status(self) -> LineupStatus:
        return LineupStatus.OK if self.ok else LineupStatus.LINEUP_REQUIRED

    @property
    def issues(self) -> tuple[Issue, ...]:
        return self.home.issues + self.away.issues

    @property
    def warnings(self) -> tuple[Issue, ...]:
        return self.home.warnings + self.away.warnings

    @property
    def badge(self) -> str:
        """Texto corto para la tarjeta del partido."""
        return "OFICIAL" if self.ok else "PENDIENTE"

    def summary(self) -> str:
        if self.ok:
            return "Alineaciones oficiales confirmadas"
        parts = [
            f"{label}: {check.issues[0].message}"
            for check, label in ((self.home, "local"), (self.away, "visitante"))
            if not check.ok
        ]
        return "LINEUP_REQUIRED · " + " | ".join(parts)


Emit = Callable[[IssueCode, str], None]

_GOALKEEPER = frozenset({"GK", "G", "GKP", "GOALKEEPER", "POR"})


def _check_count(lineup: TeamLineup, expected: int, label: str, issue: Emit) -> bool:
    n = len(lineup.starters)
    if n != expected:
        issue(IssueCode.WRONG_STARTER_COUNT, f"Se requieren {expected} {label} y hay {n}.")
        return False
    return True


def _check_unique(lineup: TeamLineup, issue: Emit) -> None:
    ids = [p.player_id for p in lineup.starters]
    if len(set(ids)) != len(ids):
        issue(IssueCode.DUPLICATE_PLAYER, "Hay jugadores repetidos en la alineación titular.")


def _football(lineup: TeamLineup, issue: Emit, warn: Emit) -> None:
    _check_count(lineup, 11, "titulares", issue)
    _check_unique(lineup, issue)
    starters = lineup.starters
    # Solo se audita al portero si el proveedor informa la posición de todos.
    if starters and all(p.position for p in starters):
        keepers = sum(1 for p in starters if (p.position or "").upper() in _GOALKEEPER)
        if keepers != 1:
            issue(IssueCode.GOALKEEPER_INVALID, f"Debe haber exactamente 1 portero titular y hay {keepers}.")


def _basketball(lineup: TeamLineup, issue: Emit, warn: Emit) -> None:
    _check_count(lineup, 5, "titulares (quinteto)", issue)
    _check_unique(lineup, issue)
    if not lineup.injury_report_published:
        issue(IssueCode.INJURY_REPORT_MISSING, "Falta el reporte oficial de lesiones.")


def _baseball(lineup: TeamLineup, issue: Emit, warn: Emit) -> None:
    if _check_count(lineup, 9, "bateadores en el lineup", issue):
        _check_unique(lineup, issue)
        orders = [p.batting_order for p in lineup.starters]
        if None in orders or sorted(orders) != list(range(1, 10)):  # type: ignore[type-var]
            issue(IssueCode.BATTING_ORDER_INVALID, "El orden al bate debe ser 1-9, sin huecos ni repetidos.")
    if lineup.starting_pitcher is None:
        issue(IssueCode.PITCHER_MISSING, "Falta el lanzador abridor.")
    elif not lineup.pitcher_confirmed:
        issue(IssueCode.PITCHER_NOT_CONFIRMED, "El abridor es solo probable, no confirmado.")


def _availability(lineup: TeamLineup, issue: Emit, warn: Emit) -> None:
    """Cruza la alineación titular con el reporte de lesiones (todos los deportes)."""
    status_by_id = {e.player_id: e.status for e in lineup.injury_report}
    if not status_by_id:
        return
    players = {p.player_id: p for p in lineup.starters}
    if lineup.starting_pitcher is not None:
        players.setdefault(lineup.starting_pitcher.player_id, lineup.starting_pitcher)
    for pid, player in players.items():
        status = status_by_id.get(pid)
        if status is InjuryStatus.OUT:
            issue(IssueCode.STARTER_RULED_OUT, f"{player.name} figura como baja (OUT) pero está en la alineación titular.")
        elif status in (InjuryStatus.QUESTIONABLE, InjuryStatus.DOUBTFUL):
            warn(IssueCode.STARTER_UNCERTAIN, f"{player.name} figura como {status.value} en el reporte de lesiones.")


_SPORT_RULES: dict[Sport, Callable[[TeamLineup, Emit, Emit], None]] = {
    Sport.FOOTBALL: _football,
    Sport.BASKETBALL: _basketball,
    Sport.BASEBALL: _baseball,
}


def validate_team_lineup(
    sport: Sport,
    side: Side,
    lineup: TeamLineup | None,
    *,
    team_id: str,
    kickoff_utc: datetime,
) -> TeamLineupCheck:
    issues: list[Issue] = []
    warnings: list[Issue] = []

    def issue(code: IssueCode, message: str) -> None:
        issues.append(Issue(code, message, side))

    def warn(code: IssueCode, message: str) -> None:
        warnings.append(Issue(code, message, side))

    if lineup is None:
        issue(IssueCode.LINEUP_MISSING, "Aún no hay alineación publicada.")
    elif lineup.team_id != team_id:
        issue(IssueCode.TEAM_MISMATCH, "La alineación recibida pertenece a otro equipo (¿lados invertidos?).")
    elif not lineup.is_official:
        issue(IssueCode.NOT_OFFICIAL, "La alineación es probable/proyectada, todavía no oficial.")
    else:
        if lineup.published_at is not None and to_utc(lineup.published_at) > kickoff_utc:
            issue(IssueCode.PUBLISHED_AFTER_KICKOFF, "La alineación figura publicada después del inicio (t ≥ T); no es utilizable.")
        _SPORT_RULES[sport](lineup, issue, warn)
        _availability(lineup, issue, warn)
    return TeamLineupCheck(side, tuple(issues), tuple(warnings))


def validate_lineups(match: Match) -> LineupCheck:
    return LineupCheck(
        home=validate_team_lineup(
            match.sport, Side.HOME, match.home_lineup,
            team_id=match.home.team_id, kickoff_utc=match.kickoff_utc,
        ),
        away=validate_team_lineup(
            match.sport, Side.AWAY, match.away_lineup,
            team_id=match.away.team_id, kickoff_utc=match.kickoff_utc,
        ),
    )
