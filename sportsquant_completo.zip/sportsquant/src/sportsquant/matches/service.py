"""Servicio de partidos: refresco, caché por deporte, cartelera de hoy y compuerta."""
from __future__ import annotations

import logging
import threading
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timezone

from ..core.config import Settings
from ..core.enums import GateCode, Sport
from ..core.models import Match
from ..core.timeutil import local_date
from .gate import ProjectionGate, projection_gate
from .lifecycle import (
    UnknownStatusError,
    is_visible_today,
    merge_match,
    normalize_status,
    sort_for_display,
)
from .providers.base import MatchProvider, ProviderError

log = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class RefreshReport:
    sport: Sport
    refreshed_at: datetime
    fetched: int
    visible: int
    skipped: tuple[str, ...] = ()  # "match_id: motivo" de partidos descartados
    error: str | None = None  # si no es None, la caché anterior se conservó


class MatchService:
    def __init__(
        self,
        provider: MatchProvider,
        settings: Settings | None = None,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        self._provider = provider
        self._settings = settings or Settings()
        self._clock = clock or (lambda: datetime.now(timezone.utc))
        self._by_sport: dict[Sport, dict[str, Match]] = {s: {} for s in Sport}
        self._lock = threading.RLock()

    # -- Escritura (hilo de trabajo) ----------------------------------------------
    def refresh(self, sport: Sport) -> RefreshReport:
        """Descarga y fusiona los partidos del deporte. Bloqueante: llamar desde un hilo."""
        now = self._clock()
        tz = self._settings.tz()
        try:
            raws = list(self._provider.fetch_matches(sport, local_date(now, tz)))
        except ProviderError as exc:
            log.warning("Fallo del proveedor %s: %s", self._provider.name, exc)
            return RefreshReport(sport, now, 0, len(self.today_matches(sport)), error=str(exc))

        with self._lock:
            previous = dict(self._by_sport[sport])

        fresh: dict[str, Match] = {}
        skipped: list[str] = []
        for raw in raws:
            if raw.sport is not sport:
                skipped.append(f"{raw.match_id}: deporte {raw.sport.value} en consulta de {sport.value}")
                continue
            try:
                status = normalize_status(raw.raw_status, self._provider.status_map)
                match = Match.from_raw(raw, status)
            except (UnknownStatusError, ValueError) as exc:
                log.warning("Partido descartado %s: %s", raw.match_id, exc)
                skipped.append(f"{raw.match_id}: {exc}")
                continue
            fresh[match.match_id] = merge_match(previous.get(match.match_id), match)

        with self._lock:
            self._by_sport[sport] = fresh
        return RefreshReport(sport, now, len(raws), len(self.today_matches(sport)), tuple(skipped))

    def now(self) -> datetime:
        """Reloj único de la aplicación (UTC): gate, cartelera y UI deben coincidir en 't'."""
        return self._clock()

    # -- Lectura (cualquier hilo; los Match son inmutables) -------------------------
    def today_matches(self, sport: Sport) -> list[Match]:
        """Partidos de hoy (fecha local) no terminados; los FINISHED desaparecen solos."""
        now, tz = self._clock(), self._settings.tz()
        with self._lock:
            matches = list(self._by_sport[sport].values())
        carry = self._settings.include_live_carryover
        return sort_for_display(m for m in matches if is_visible_today(m, now, tz, carry))

    def get(self, match_id: str) -> Match | None:
        with self._lock:
            for matches in self._by_sport.values():
                if match_id in matches:
                    return matches[match_id]
        return None

    def gate(self, match_id: str) -> ProjectionGate:
        match = self.get(match_id)
        if match is None:
            return ProjectionGate(False, GateCode.NOT_SCHEDULED, "El partido ya no está disponible.")
        return projection_gate(match, self._clock())
