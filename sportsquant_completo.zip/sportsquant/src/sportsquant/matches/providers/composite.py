"""Enruta cada deporte a su proveedor (ESPN: fútbol y NBA; MLB StatsAPI: béisbol)."""
from __future__ import annotations

from collections.abc import Mapping
from datetime import date

from ...core.enums import MatchStatus, Sport
from ...core.models import RawMatch
from .base import MatchProvider, ProviderError


class CompositeProvider:
    name = "composite"
    status_map: Mapping[str, MatchStatus] = {}

    def __init__(self, routes: Mapping[Sport, MatchProvider]) -> None:
        self._routes = dict(routes)

    def fetch_matches(self, sport: Sport, local_day: date) -> list[RawMatch]:
        provider = self._routes.get(sport)
        if provider is None:
            raise ProviderError(f"No hay proveedor configurado para {sport.value}")
        return list(provider.fetch_matches(sport, local_day))
