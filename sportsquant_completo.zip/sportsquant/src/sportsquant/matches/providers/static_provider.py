"""Proveedor en memoria: pruebas, modo demo y desarrollo de UI sin red."""
from __future__ import annotations

from collections.abc import Iterable, Mapping
from datetime import date

from ...core.enums import MatchStatus, Sport
from ...core.models import RawMatch
from .base import ProviderError


class StaticProvider:
    name = "static"

    def __init__(
        self,
        matches: Iterable[RawMatch] = (),
        status_map: Mapping[str, MatchStatus] | None = None,
        *,
        fail_with: str | None = None,
    ) -> None:
        self.matches: list[RawMatch] = list(matches)
        self.status_map: Mapping[str, MatchStatus] = dict(status_map or {})
        self.fail_with = fail_with

    def set_matches(self, matches: Iterable[RawMatch]) -> None:
        self.matches = list(matches)

    def fetch_matches(self, sport: Sport, local_day: date) -> list[RawMatch]:
        if self.fail_with:
            raise ProviderError(self.fail_with)
        return [m for m in self.matches if m.sport is sport]
