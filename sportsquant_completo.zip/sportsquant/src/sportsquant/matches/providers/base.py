"""Contrato que deben cumplir los adaptadores de datos (APIs reales llegan después)."""
from __future__ import annotations

from collections.abc import Iterable, Mapping
from datetime import date
from typing import Protocol

from ...core.enums import MatchStatus, Sport
from ...core.models import RawMatch


class ProviderError(RuntimeError):
    """Fallo recuperable del proveedor (red, cuota, formato). El servicio conserva la caché."""


class MatchProvider(Protocol):
    name: str
    # Códigos de estado propios del proveedor que difieren del mapeo genérico.
    status_map: Mapping[str, MatchStatus]

    def fetch_matches(self, sport: Sport, local_day: date) -> Iterable[RawMatch]:
        """Operación bloqueante (I/O): se llama siempre desde un hilo, nunca desde la UI.

        Debe cubrir el día local completo (consultando por rango UTC con margen) y puede
        incluir partidos LIVE que cruzan la medianoche; el servicio filtra la visibilidad.
        Debe lanzar ProviderError ante cualquier fallo recuperable.
        """
        ...
