"""Ciclo de vida de partidos: normalización de estado, transiciones y visibilidad."""
from __future__ import annotations

import logging
import re
from collections.abc import Iterable, Mapping
from dataclasses import replace
from datetime import datetime, tzinfo

from ..core.enums import MatchStatus
from ..core.models import LiveClock, Match, TeamLineup
from ..core.timeutil import to_utc

log = logging.getLogger(__name__)


class UnknownStatusError(ValueError):
    """El proveedor envió un estado que no sabemos clasificar (nunca se adivina)."""


# --- Normalización -----------------------------------------------------------------
# Los tokens se comparan en minúsculas con todo lo no alfanumérico convertido en "_".
# Códigos ambiguos entre proveedores (p. ej. "P": penales en API-Football, pre-juego en
# otros) NO están aquí: cada proveedor los declara en su propio `status_map`.
_SCHEDULED = frozenset({
    "ns", "tbd", "tba", "scheduled", "status_scheduled", "pre", "pre_game", "pregame",
    "not_started", "upcoming", "timed", "fixture", "preview", "warmup", "warm_up",
})
_LIVE = frozenset({
    "1h", "2h", "ht", "et", "bt", "live", "in_play", "inplay", "in_progress",
    "status_in_progress", "status_halftime", "status_end_period", "halftime", "half_time",
    "extra_time", "penalties", "break", "int", "interrupted", "susp", "suspended",
    "delayed", "delay", "rain_delay", "status_delayed", "status_rain_delay",
    "status_suspended", "overtime", "ot", "end_period", "end_of_period",
})
# Estados terminales. Incluye "postponed/cancelled/abandoned": el partido de hoy ya no
# se jugará, así que sale de la vista igual que uno finalizado.
_FINISHED = frozenset({
    "ft", "aet", "pen", "finished", "final", "status_final", "full_time", "fulltime",
    "ended", "completed", "game_over", "final_ot", "final_aet", "status_final_ot",
    "status_full_time", "postponed", "pst", "canc", "cancelled", "canceled", "abd",
    "abandoned", "awd", "wo", "walkover", "forfeit", "status_postponed",
    "status_canceled", "status_cancelled", "status_forfeit", "status_abandoned",
})
_LIVE_PATTERNS = (
    re.compile(r"^q[1-4]$"),
    re.compile(r"^end_(of_)?q[1-4]$"),
    re.compile(r"^[1-4](st|nd|rd|th)_(quarter|period)$"),
    re.compile(r"^\d*ot\d*$"),
    re.compile(r"^(top|bot|bottom|mid|middle|end)_\d+(st|nd|rd|th)?$"),  # béisbol
)


def _token(raw: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", raw.strip().lower()).strip("_")


def normalize_status(
    raw_status: str, extra: Mapping[str, MatchStatus] | None = None
) -> MatchStatus:
    """Convierte el estado crudo del proveedor a SCHEDULED / LIVE / FINISHED."""
    token = _token(raw_status or "")
    if not token:
        raise UnknownStatusError("estado vacío")
    if extra:
        overrides = {_token(k): v for k, v in extra.items()}
        if token in overrides:
            return overrides[token]
    if token in _SCHEDULED:
        return MatchStatus.SCHEDULED
    if token in _LIVE or any(p.match(token) for p in _LIVE_PATTERNS):
        return MatchStatus.LIVE
    if token in _FINISHED:
        return MatchStatus.FINISHED
    raise UnknownStatusError(f"estado desconocido: {raw_status!r}")


# --- Transiciones monótonas --------------------------------------------------------
# SCHEDULED -> LIVE -> FINISHED. Un feed que "retrocede" (p. ej. vuelve a decir NS con el
# partido ya iniciado) es ruido: se ignora esa lectura completa.
_RANK = {MatchStatus.SCHEDULED: 0, MatchStatus.LIVE: 1, MatchStatus.FINISHED: 2}


def merge_status(previous: MatchStatus, incoming: MatchStatus) -> MatchStatus:
    return incoming if _RANK[incoming] >= _RANK[previous] else previous


def _merge_lineup(prev: TeamLineup | None, inc: TeamLineup | None) -> TeamLineup | None:
    # Una alineación oficial no se "degrada" a probable/ausente por un fallo del feed.
    # Si llega otra oficial distinta (baja de último minuto) sí reemplaza a la anterior.
    if prev is not None and prev.is_official and (inc is None or not inc.is_official):
        return prev
    return inc


def merge_match(previous: Match | None, incoming: Match) -> Match:
    if previous is None:
        return incoming
    if _RANK[incoming.status] < _RANK[previous.status]:
        log.warning(
            "Retroceso de estado ignorado en %s: %s -> %s",
            incoming.match_id, previous.status.value, incoming.status.value,
        )
        return previous
    return replace(
        incoming,
        home_lineup=_merge_lineup(previous.home_lineup, incoming.home_lineup),
        away_lineup=_merge_lineup(previous.away_lineup, incoming.away_lineup),
    )


# --- Visibilidad (cartelera de hoy) ------------------------------------------------
def is_visible_today(
    match: Match, now: datetime, tz: tzinfo, include_live_carryover: bool = True
) -> bool:
    """fecha_local == hoy y no terminado. Un LIVE iniciado ayer sigue visible (opcional)."""
    if match.status is MatchStatus.FINISHED:
        return False
    today = to_utc(now).astimezone(tz).date()
    kickoff_day = match.kickoff_utc.astimezone(tz).date()
    if kickoff_day == today:
        return True
    return include_live_carryover and match.status is MatchStatus.LIVE and kickoff_day < today


def sort_for_display(matches: Iterable[Match]) -> list[Match]:
    """En vivo primero; luego por hora de inicio."""
    return sorted(matches, key=lambda m: (m.status is not MatchStatus.LIVE, m.kickoff_utc, m.match_id))


# --- Etiquetas de reloj para la UI (minuto / cuarto / inning) -----------------------
def football_clock(minute: int, added: int | None = None, *, halftime: bool = False) -> LiveClock:
    if halftime:
        return LiveClock("Descanso")
    return LiveClock(f"{minute}+{added}'" if added else f"{minute}'")


def basketball_clock(period: int, remaining: str | None = None) -> LiveClock:
    name = f"Q{period}" if period <= 4 else ("OT" if period == 5 else f"{period - 4}OT")
    return LiveClock(f"{name} {remaining}" if remaining else name, period)


_BASEBALL_HALF = {"top": "▲", "bottom": "▼", "middle": "Med", "end": "Fin"}


def baseball_clock(inning: int, half: str | None = None) -> LiveClock:
    prefix = _BASEBALL_HALF.get((half or "").lower())
    return LiveClock(f"{prefix} {inning}" if prefix else f"Inning {inning}", inning)
