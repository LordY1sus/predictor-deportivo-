"""Compuerta de proyección: decide si el botón «Proyectar» puede ejecutarse."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from ..core.enums import GateCode, MatchStatus
from ..core.models import Match
from ..core.timeutil import to_utc
from .lineup_validator import LineupCheck, validate_lineups


@dataclass(frozen=True, slots=True)
class ProjectionGate:
    allowed: bool
    code: GateCode
    reason: str  # texto en español para la UI
    lineup: LineupCheck | None = None


def projection_gate(match: Match, now: datetime) -> ProjectionGate:
    """Orden de las reglas: estado -> t < T -> alineaciones oficiales.

    Debe evaluarse al pulsar «Proyectar» y de nuevo dentro del hilo de cálculo justo
    antes de simular: entre ambos momentos puede haber pasado el inicio del partido.
    """
    if match.status is not MatchStatus.SCHEDULED:
        return ProjectionGate(False, GateCode.NOT_SCHEDULED, "Solo se proyectan partidos programados.")
    if to_utc(now) >= match.kickoff_utc:
        return ProjectionGate(False, GateCode.KICKOFF_PASSED, "El partido ya debió comenzar (se exige t < T).")
    check = validate_lineups(match)
    if not check.ok:
        return ProjectionGate(False, GateCode.LINEUP_REQUIRED, check.summary(), check)
    return ProjectionGate(True, GateCode.OK, check.summary(), check)
