"""Módulo de partidos: estados, cartelera de hoy y validación de alineaciones."""
from .gate import ProjectionGate, projection_gate
from .lifecycle import UnknownStatusError, normalize_status
from .lineup_validator import LineupCheck, validate_lineups
from .providers.base import MatchProvider, ProviderError
from .service import MatchService, RefreshReport

__all__ = [
    "LineupCheck", "MatchProvider", "MatchService", "ProjectionGate", "ProviderError",
    "RefreshReport", "UnknownStatusError", "normalize_status", "projection_gate",
    "validate_lineups",
]
