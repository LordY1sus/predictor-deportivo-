"""Clima del recinto a la hora de inicio (Open-Meteo, sin clave)."""
from __future__ import annotations

import logging
from datetime import datetime, timezone

from ..core.stats import Weather
from ..matches.providers.base import ProviderError
from .http import HttpClient

log = logging.getLogger(__name__)
GEOCODE = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST = "https://api.open-meteo.com/v1/forecast"
DAY, MONTH = 86400.0, 30 * 86400.0


class WeatherClient:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def geocode(self, city: str, country: str | None = None) -> tuple[float, float] | None:
        data = self._http.get_json(GEOCODE, {"name": city, "count": 5, "language": "en", "format": "json"}, ttl=MONTH)
        results = data.get("results") or []
        if country:
            matching = [r for r in results if country.lower() in (str(r.get("country", "")).lower(), str(r.get("country_code", "")).lower())]
            results = matching or results
        if not results:
            return None
        return float(results[0]["latitude"]), float(results[0]["longitude"])

    def forecast_at(self, lat: float, lon: float, when: datetime) -> Weather | None:
        data = self._http.get_json(
            FORECAST,
            {"latitude": round(lat, 3), "longitude": round(lon, 3), "timezone": "GMT", "forecast_days": 14,
             "wind_speed_unit": "ms", "hourly": "temperature_2m,precipitation,precipitation_probability,wind_speed_10m"},
            ttl=1800.0,
        )
        return pick_hour(data, when)


def pick_hour(data: dict, when: datetime) -> Weather | None:
    hourly = data.get("hourly") or {}
    times = hourly.get("time") or []
    if not times:
        return None
    target = when.astimezone(timezone.utc)
    best, best_gap = None, 1e12
    for i, t in enumerate(times):
        dt = datetime.fromisoformat(t).replace(tzinfo=timezone.utc)
        gap = abs((dt - target).total_seconds())
        if gap < best_gap:
            best, best_gap = i, gap
    if best is None or best_gap > 3600 * 1.5:  # fuera del rango de pronóstico
        return None
    def at(key: str):
        vals = hourly.get(key) or []
        return vals[best] if best < len(vals) else None
    return Weather(temp_c=at("temperature_2m"), wind_ms=at("wind_speed_10m"),
                   precip_mm=at("precipitation"), precip_prob=at("precipitation_probability"))


def safe_weather(client: WeatherClient | None, city: str | None, country: str | None, when: datetime,
                 lat: float | None = None, lon: float | None = None) -> tuple[Weather | None, str | None]:
    """Clima o (None, motivo): un fallo de clima nunca debe impedir la proyección."""
    if client is None:
        return None, None
    try:
        if lat is None or lon is None:
            if not city:
                return None, "sin ciudad del recinto para consultar el clima"
            coords = client.geocode(city, country)
            if coords is None:
                return None, f"no se encontró la ciudad {city!r} para el clima"
            lat, lon = coords
        w = client.forecast_at(lat, lon, when)
        return (w, None) if w else (None, "pronóstico no disponible para la hora de inicio")
    except (ProviderError, KeyError, ValueError) as exc:
        log.warning("Clima no disponible: %s", exc)
        return None, f"clima no disponible ({exc})"
