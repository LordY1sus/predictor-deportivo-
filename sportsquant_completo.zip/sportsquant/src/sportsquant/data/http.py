"""Cliente HTTP con caché en SQLite, reintentos y respaldo con caché vencida."""
from __future__ import annotations

import json
import logging
import time
from collections.abc import Callable, Mapping
from typing import Any
from urllib.parse import urlencode

import httpx

from ..matches.providers.base import ProviderError
from .storage import Storage

log = logging.getLogger(__name__)
USER_AGENT = "SportsQuant/0.1 (uso personal)"


class HttpClient:
    def __init__(
        self,
        storage: Storage | None = None,
        *,
        timeout: float = 12.0,
        retries: int = 2,
        transport: httpx.BaseTransport | None = None,
        sleep: Callable[[float], None] = time.sleep,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self._storage = storage
        self._retries = retries
        self._sleep = sleep
        self._clock = clock
        self._client = httpx.Client(
            timeout=timeout, follow_redirects=True, transport=transport,
            headers={"User-Agent": USER_AGENT, "Accept": "application/json"},
        )

    def close(self) -> None:
        self._client.close()

    @staticmethod
    def _key(url: str, params: Mapping[str, Any] | None) -> str:
        return url + ("?" + urlencode(sorted((str(k), str(v)) for k, v in params.items())) if params else "")

    def get_json(
        self, url: str, params: Mapping[str, Any] | None = None, *, ttl: float | None = 300.0, refresh: bool = False
    ) -> Any:
        """ttl=None → inmutable (se cachea para siempre); ttl=0 → sin caché."""
        key = self._key(url, params)
        stale: str | None = None
        if self._storage is not None and ttl != 0:
            hit = self._storage.cache_get(key)
            if hit is not None:
                fetched, body = hit
                if not refresh and (ttl is None or self._clock() - fetched <= ttl):
                    return json.loads(body)
                stale = body
        last: Exception | None = None
        for attempt in range(self._retries + 1):
            try:
                resp = self._client.get(url, params=params)
                if resp.status_code >= 400:
                    raise ProviderError(f"HTTP {resp.status_code} en {url}")
                data = resp.json()
                if self._storage is not None and ttl != 0:
                    self._storage.cache_put(key, resp.text, self._clock())
                return data
            except ProviderError as exc:
                last = exc
                if "HTTP 4" in str(exc) and "HTTP 429" not in str(exc):
                    break  # 4xx definitivo: no se reintenta
            except (httpx.HTTPError, ValueError) as exc:
                last = exc
            if attempt < self._retries:
                self._sleep(0.5 * (attempt + 1))
        if stale is not None:
            log.warning("Usando caché vencida de %s (%s)", url, last)
            return json.loads(stale)
        raise ProviderError(f"No se pudo obtener {url}: {last}") from last
