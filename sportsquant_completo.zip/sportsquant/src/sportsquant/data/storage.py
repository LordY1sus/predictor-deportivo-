"""Persistencia local (SQLite): ajustes, cuotas manuales, proyecciones y caché HTTP."""
from __future__ import annotations

import json
import sqlite3
import threading
import time
import zlib
from datetime import datetime, timezone
from pathlib import Path

from ..projection.results import ProjectionResult

SCHEMA = """
CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS manual_odds (
    match_id TEXT NOT NULL, selection TEXT NOT NULL, odds REAL NOT NULL, updated REAL NOT NULL,
    PRIMARY KEY (match_id, selection));
CREATE TABLE IF NOT EXISTS projections (
    match_id TEXT PRIMARY KEY, sport TEXT NOT NULL, created REAL NOT NULL,
    kickoff REAL NOT NULL, payload TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS http_cache (
    key TEXT PRIMARY KEY, fetched REAL NOT NULL, body BLOB NOT NULL);
"""


class Storage:
    def __init__(self, path: str | Path = ":memory:") -> None:
        if str(path) != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(str(path), check_same_thread=False)
        self._lock = threading.RLock()
        with self._lock:
            self._db.executescript(SCHEMA)
            self._db.commit()

    def close(self) -> None:
        with self._lock:
            self._db.close()

    def _run(self, sql: str, args: tuple = (), *, fetch: str | None = None):
        with self._lock:
            cur = self._db.execute(sql, args)
            out = cur.fetchone() if fetch == "one" else cur.fetchall() if fetch == "all" else None
            self._db.commit()
            return out

    # -- ajustes
    def kv_get(self, key: str, default=None):
        row = self._run("SELECT value FROM kv WHERE key=?", (key,), fetch="one")
        return json.loads(row[0]) if row else default

    def kv_set(self, key: str, value) -> None:
        self._run("INSERT INTO kv(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                  (key, json.dumps(value)))

    # -- cuotas manuales
    def set_manual_odds(self, match_id: str, selection: str, odds: float | None) -> None:
        if odds is None:
            self._run("DELETE FROM manual_odds WHERE match_id=? AND selection=?", (match_id, selection))
            return
        if not odds > 1.0:
            raise ValueError("La cuota decimal debe ser mayor que 1.0")
        self._run("INSERT INTO manual_odds VALUES(?,?,?,?) ON CONFLICT(match_id,selection) "
                  "DO UPDATE SET odds=excluded.odds, updated=excluded.updated",
                  (match_id, selection, float(odds), time.time()))

    def manual_odds(self, match_id: str) -> dict[str, float]:
        rows = self._run("SELECT selection, odds FROM manual_odds WHERE match_id=?", (match_id,), fetch="all")
        return {s: o for s, o in rows}

    # -- proyecciones
    def save_projection(self, result: ProjectionResult) -> None:
        self._run(
            "INSERT INTO projections VALUES(?,?,?,?,?) ON CONFLICT(match_id) DO UPDATE SET "
            "sport=excluded.sport, created=excluded.created, kickoff=excluded.kickoff, payload=excluded.payload",
            (result.match_id, result.sport, result.created_at.timestamp(), result.kickoff_utc.timestamp(),
             json.dumps(result.to_dict())),
        )

    def load_projection(self, match_id: str) -> ProjectionResult | None:
        row = self._run("SELECT payload FROM projections WHERE match_id=?", (match_id,), fetch="one")
        return ProjectionResult.from_dict(json.loads(row[0])) if row else None

    def load_projections(self, sport: str | None = None, kickoff_after: datetime | None = None) -> list[ProjectionResult]:
        sql, args = "SELECT payload FROM projections WHERE 1=1", []
        if sport:
            sql += " AND sport=?"
            args.append(sport)
        if kickoff_after is not None:
            sql += " AND kickoff>=?"
            args.append(kickoff_after.astimezone(timezone.utc).timestamp())
        rows = self._run(sql, tuple(args), fetch="all")
        return [ProjectionResult.from_dict(json.loads(r[0])) for r in rows]

    # -- caché HTTP
    def cache_get(self, key: str) -> tuple[float, str] | None:
        row = self._run("SELECT fetched, body FROM http_cache WHERE key=?", (key,), fetch="one")
        return (row[0], zlib.decompress(row[1]).decode("utf-8")) if row else None

    def cache_put(self, key: str, body: str, fetched: float | None = None) -> None:
        self._run("INSERT INTO http_cache VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET "
                  "fetched=excluded.fetched, body=excluded.body",
                  (key, fetched if fetched is not None else time.time(), zlib.compress(body.encode("utf-8"), 6)))

    def purge(self, *, cache_days: float = 45.0, projection_days: float = 30.0) -> None:
        now = time.time()
        self._run("DELETE FROM http_cache WHERE fetched<?", (now - cache_days * 86400,))
        self._run("DELETE FROM projections WHERE kickoff<?", (now - projection_days * 86400,))
        self._run("DELETE FROM manual_odds WHERE updated<?", (now - projection_days * 86400,))
