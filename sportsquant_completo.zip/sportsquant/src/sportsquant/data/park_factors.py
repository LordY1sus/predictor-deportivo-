"""Park factors de carreras (1.00 = neutro) y tipo de techo por equipo local (abreviatura MLB).

VALORES APROXIMADOS (promedios de varias temporadas, de memoria): la capa 2 los contrae un 50 %
hacia 1.0. Edita este diccionario si quieres afinarlos con una fuente propia.
"""
PARK_FACTORS: dict[str, tuple[float, str]] = {
    "COL": (1.13, "open"), "CIN": (1.05, "open"), "BOS": (1.04, "open"), "KC": (1.03, "open"),
    "PHI": (1.02, "open"), "MIN": (1.01, "open"), "CWS": (1.01, "open"), "ARI": (1.01, "retractable"),
    "TEX": (1.00, "retractable"), "TOR": (1.00, "retractable"), "BAL": (1.00, "open"), "ATL": (1.00, "open"),
    "WSH": (1.00, "open"), "CHC": (1.00, "open"), "HOU": (1.00, "retractable"), "NYY": (1.00, "open"),
    "LAA": (0.99, "open"), "MIL": (0.99, "retractable"), "LAD": (0.99, "open"), "STL": (0.98, "open"),
    "CLE": (0.98, "open"), "DET": (0.98, "open"), "PIT": (0.98, "open"), "NYM": (0.97, "open"),
    "SD": (0.97, "open"), "TB": (0.97, "dome"), "OAK": (0.97, "open"), "ATH": (1.00, "open"),
    "MIA": (0.96, "retractable"), "SF": (0.95, "open"), "SEA": (0.94, "retractable"),
}
