"""MLB StatsAPI (oficial, sin clave): cartelera, alineaciones 1-9, abridores, resultados y estadísticas."""
from __future__ import annotations

import dataclasses
import logging
import re
from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta

from ..core.enums import Sport
from ..core.models import LiveClock, PlayerSlot, RawMatch, Score, Team, TeamLineup
from ..matches.lifecycle import baseball_clock
from ..matches.providers.base import ProviderError
from .espn import EspnClient, FinishedGame, date_windows, parse_event, parse_iso
from .http import HttpClient

log = logging.getLogger(__name__)
BASE = "https://statsapi.mlb.com/api/v1"
SCHEDULE_HYDRATE = "probablePitcher,lineups,team,venue(location),weather,linescore"
FINISHED_FIELDS = "dates,date,games,gamePk,gameDate,status,abstractGameState,detailedState,teams,away,home,team,id,score"
VENUE_SEP = " · "


# ------------------------------------------------------------------ utilidades
def innings(value) -> float:
    """'1423.1' (1423 entradas y 1 out) → 1423.333."""
    try:
        whole, _, frac = str(value).partition(".")
        return float(whole) + (int(frac or 0) / 3.0)
    except ValueError:
        return 0.0


def _f(stat: dict, key: str) -> float:
    try:
        return float(stat.get(key) or 0)
    except (TypeError, ValueError):
        return 0.0


def status_token(status: dict) -> str:
    detailed = str(status.get("detailedState", "")).lower()
    for key, token in (("postponed", "postponed"), ("cancel", "cancelled"), ("suspend", "suspended")):
        if key in detailed:
            return token
    return str(status.get("abstractGameState", "")).lower()


def parse_lineup(team_id: str, game_team: dict, players: list[dict] | None) -> TeamLineup | None:
    pp = game_team.get("probablePitcher") or {}
    pitcher = PlayerSlot(str(pp["id"]), pp.get("fullName", "?"), "P") if "id" in pp else None
    slots = tuple(
        PlayerSlot(str(p["id"]), p.get("fullName", "?"), (p.get("primaryPosition") or {}).get("abbreviation"), batting_order=i + 1)
        for i, p in enumerate(players or []) if "id" in p
    )
    if not slots and pitcher is None:
        return None
    official = len(slots) > 0  # la API publica `lineups` solo cuando el equipo entregó su alineación
    return TeamLineup(team_id=team_id, starters=slots, is_official=official, source="mlb",
                      starting_pitcher=pitcher, pitcher_confirmed=official and pitcher is not None)


def parse_game(game: dict) -> RawMatch | None:
    try:
        teams = game["teams"]
        h, a = teams["home"], teams["away"]

        def team(t: dict) -> Team:
            tm = t["team"]
            return Team(str(tm["id"]), tm.get("name", "?"), tm.get("abbreviation") or tm.get("teamName") or "")

        home, away = team(h), team(a)
        status = game.get("status") or {}
        token = status_token(status)
        score = None
        if token in ("live", "final") and "score" in h and "score" in a:
            score = Score(int(h["score"]), int(a["score"]))
        clock: LiveClock | None = None
        ls = game.get("linescore") or {}
        if token == "live" and ls.get("currentInning"):
            clock = baseball_clock(int(ls["currentInning"]), str(ls.get("inningState") or ls.get("inningHalf") or "").lower())
        lineups = game.get("lineups") or {}
        v = game.get("venue") or {}
        city = (v.get("location") or {}).get("city")
        return RawMatch(
            match_id=f"mlb:{game['gamePk']}", sport=Sport.BASEBALL, competition="MLB",
            kickoff=parse_iso(game["gameDate"]), home=home, away=away, raw_status=token, score=score, clock=clock,
            home_lineup=parse_lineup(home.team_id, h, lineups.get("homePlayers")),
            away_lineup=parse_lineup(away.team_id, a, lineups.get("awayPlayers")),
            venue=(v.get("name", "") + (VENUE_SEP + city if city else "")) or None,
        )
    except (KeyError, TypeError, ValueError):
        return None


def parse_finished(data: dict) -> list[FinishedGame]:
    out = []
    for d in data.get("dates") or []:
        for g in d.get("games") or []:
            try:
                st = g["status"]
                if str(st.get("abstractGameState")) != "Final" or "postponed" in str(st.get("detailedState", "")).lower():
                    continue
                h, a = g["teams"]["home"], g["teams"]["away"]
                if "score" not in h or "score" not in a:
                    continue
                out.append(FinishedGame(str(g["gamePk"]), "mlb", str(h["team"]["id"]), str(a["team"]["id"]),
                                        float(h["score"]), float(a["score"]), parse_iso(g["gameDate"])))
            except (KeyError, TypeError, ValueError):
                continue
    return out


def _names_match(a: str, b: str) -> bool:
    a, b = a.lower().strip(), b.lower().strip()
    return bool(a and b and (a == b or a.endswith(b) or b.endswith(a)))


# ------------------------------------------------------------------------ cliente
class MlbClient:
    def __init__(self, http: HttpClient, workers: int = 6) -> None:
        self.http = http
        self.workers = workers

    def schedule(self, start: date, end: date, *, hydrate: str | None = None, fields: str | None = None,
                 game_type: str | None = None, game_pk: str | None = None, ttl: float | None = 45.0) -> dict:
        params: dict = {"sportId": 1}
        if game_pk:
            params["gamePk"] = game_pk
        else:
            params.update(startDate=start.isoformat(), endDate=end.isoformat())
        for k, v in (("hydrate", hydrate), ("fields", fields), ("gameType", game_type)):
            if v:
                params[k] = v
        return self.http.get_json(f"{BASE}/schedule", params, ttl=ttl)

    def finished_games(self, until: date, lookback_days: int) -> list[FinishedGame]:
        def one(w: tuple[date, date]) -> list[FinishedGame]:
            a, b = w
            current = a <= until <= b
            try:
                data = self.schedule(a, b, fields=FINISHED_FIELDS, game_type="R", ttl=3 * 3600.0 if current else None)
            except ProviderError as exc:
                log.warning("Resultados MLB %s–%s no disponibles: %s", a, b, exc)
                return []
            return parse_finished(data)

        with ThreadPoolExecutor(max_workers=self.workers) as pool:
            chunks = list(pool.map(one, date_windows(until, lookback_days, size=60)))
        seen = {g.event_id: g for chunk in chunks for g in chunk}
        return sorted(seen.values(), key=lambda g: g.played_at)

    def team_stats(self, group: str, season: int) -> dict[str, dict]:
        data = self.http.get_json(f"{BASE}/teams/stats", {"stats": "season", "group": group, "season": season, "sportIds": 1}, ttl=6 * 3600.0)
        out = {}
        for blk in data.get("stats") or []:
            for sp in blk.get("splits") or []:
                tid = (sp.get("team") or {}).get("id")
                if tid is not None:
                    out[str(tid)] = sp.get("stat") or {}
        return out

    def roster(self, team_id: str, season: int) -> list[dict]:
        hyd = f"person(stats(type=season,group=[hitting,pitching],season={season}))"
        data = self.http.get_json(f"{BASE}/teams/{team_id}/roster", {"rosterType": "active", "hydrate": hyd}, ttl=6 * 3600.0)
        return data.get("roster") or []

    def person_stat(self, pid: str, group: str, season: int, *, stats: str = "season", sit_codes: str | None = None) -> list[dict]:
        params = {"stats": stats, "group": group, "season": season}
        if sit_codes:
            params["sitCodes"] = sit_codes
        data = self.http.get_json(f"{BASE}/people/{pid}/stats", params, ttl=12 * 3600.0)
        return [s for blk in data.get("stats") or [] for s in blk.get("splits") or []]

    def person(self, pid: str) -> dict:
        data = self.http.get_json(f"{BASE}/people/{pid}", None, ttl=30 * 86400.0)
        return (data.get("people") or [{}])[0]

    def boxscore(self, game_pk: str) -> dict:
        return self.http.get_json(f"{BASE}/game/{game_pk}/boxscore", None, ttl=None)


# ---------------------------------------------------------------------- proveedor
class MlbProvider:
    name = "mlb"
    status_map: dict = {}

    def __init__(self, client: MlbClient, odds_client: EspnClient | None = None) -> None:
        self.client = client
        self.odds_client = odds_client

    def fetch_matches(self, sport: Sport, local_day: date) -> list[RawMatch]:
        if sport is not Sport.BASEBALL:
            return []
        data = self.client.schedule(local_day - timedelta(days=1), local_day + timedelta(days=1), hydrate=SCHEDULE_HYDRATE)
        raws = [r for d in data.get("dates") or [] for g in d.get("games") or [] if (r := parse_game(g)) is not None]
        return self._attach_odds(raws, local_day)

    def _attach_odds(self, raws: list[RawMatch], day: date) -> list[RawMatch]:
        if self.odds_client is None or not raws:
            return raws
        try:
            dates = f"{day - timedelta(days=1):%Y%m%d}-{day + timedelta(days=1):%Y%m%d}"
            data = self.odds_client.scoreboard("baseball", "mlb", dates, 300, ttl=120.0)
        except ProviderError as exc:
            log.info("Cuotas ESPN de MLB no disponibles: %s", exc)
            return raws
        espn = [e for ev in data.get("events") or [] if (e := parse_event(Sport.BASEBALL, "baseball", "mlb", "MLB", ev)) and e.odds]
        out = []
        for r in raws:
            hit = next((e for e in espn if _names_match(e.home.name, r.home.name) and _names_match(e.away.name, r.away.name)
                        and abs((e.kickoff - r.kickoff).total_seconds()) < 6 * 3600), None)
            out.append(dataclasses.replace(r, odds=hit.odds) if hit else r)
        return out


# ------------------------------------------------------------- estadísticas (FIP/xFIP)
def fip_constants(pitching: dict[str, dict]) -> dict[str, float]:
    """Constantes de liga: ERA, cFIP, HR/FB (con outs aéreos + HR como proxy de bolas elevadas)."""
    ip = sum(innings(s.get("inningsPitched")) for s in pitching.values())
    if ip <= 0:
        return {}
    hr = sum(_f(s, "homeRuns") for s in pitching.values())
    bb = sum(_f(s, "baseOnBalls") for s in pitching.values())
    hbp = sum(_f(s, "hitBatsmen") for s in pitching.values())
    k = sum(_f(s, "strikeOuts") for s in pitching.values())
    er = sum(_f(s, "earnedRuns") for s in pitching.values())
    air = sum(_f(s, "airOuts") for s in pitching.values())
    era = 9 * er / ip
    raw = (13 * hr + 3 * (bb + hbp) - 2 * k) / ip
    return {"lg_era": era, "c_fip": era - raw, "lg_hr_fb": hr / (air + hr) if air + hr > 0 else 0.12, "lg_fip": era}


def pitcher_metrics(stat: dict, c: dict[str, float]) -> dict[str, float]:
    ip = innings(stat.get("inningsPitched"))
    if ip <= 0 or "c_fip" not in c:
        return {}
    hr, bb, hbp, k = _f(stat, "homeRuns"), _f(stat, "baseOnBalls"), _f(stat, "hitBatsmen"), _f(stat, "strikeOuts")
    fb = _f(stat, "airOuts") + hr
    fip = (13 * hr + 3 * (bb + hbp) - 2 * k) / ip + c["c_fip"]
    xfip = (13 * fb * c["lg_hr_fb"] + 3 * (bb + hbp) - 2 * k) / ip + c["c_fip"]
    gs = _f(stat, "gamesStarted")
    out = {"fip": fip, "xfip": xfip, "ip": ip}
    if gs > 0:
        out["ip_per_start"] = ip / gs
    return out


def team_offense(hitting: dict[str, dict]) -> dict[str, float]:
    pa = sum(_f(s, "plateAppearances") for s in hitting.values())
    games = sum(_f(s, "gamesPlayed") for s in hitting.values())
    if pa <= 0 or games <= 0:
        return {}
    w = lambda key: sum(_f(s, key) * _f(s, "plateAppearances") for s in hitting.values()) / pa
    return {"runs_pg": sum(_f(s, "runs") for s in hitting.values()) / games,
            "lg_obp": w("obp"), "lg_slg": w("slg"), "lg_ops": w("ops")}


def ops_plus(stat: dict, lg: dict[str, float]) -> float | None:
    """Proxy de wRC+: 100·(OBP/lgOBP + SLG/lgSLG − 1) (sin ajuste de parque)."""
    try:
        obp, slg = float(stat["obp"]), float(stat["slg"])
    except (KeyError, TypeError, ValueError):
        return None
    if not lg.get("lg_obp") or not lg.get("lg_slg"):
        return None
    return 100.0 * (obp / lg["lg_obp"] + slg / lg["lg_slg"] - 1.0)


def parse_wind(text: str | None) -> float | None:
    """'12 mph, Out To CF' → +5.4 m/s (hacia afuera); 'In From LF' → negativo; cruzado/calma → 0."""
    if not text:
        return None
    m = re.match(r"\s*(\d+(?:\.\d+)?)\s*mph", text, re.I)
    if not m:
        return None
    ms = float(m.group(1)) * 0.44704
    t = text.lower()
    return ms if "out to" in t else -ms if "in from" in t else 0.0
