"""ESPN (API pública no oficial, sin clave): cartelera, cuotas, alineaciones y resultados.

Fútbol (`soccer/<liga>`) y NBA (`basketball/nba`). Todo el parseo es defensivo: si falta un
campo, la alineación queda sin publicar (LINEUP_REQUIRED) en lugar de adivinar.
"""
from __future__ import annotations

import dataclasses
import logging
import re
from collections.abc import Callable, Iterable
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone

from ..core.enums import InjuryStatus, Sport
from ..core.models import InjuryEntry, LiveClock, OddsLine, PlayerSlot, RawMatch, Score, Team, TeamLineup
from ..matches.lifecycle import basketball_clock, football_clock
from ..matches.providers.base import ProviderError
from .http import HttpClient

log = logging.getLogger(__name__)

BASE = "https://site.api.espn.com/apis/site/v2/sports"
DEFAULT_FOOTBALL_LEAGUES = (
    "eng.1", "esp.1", "ita.1", "ger.1", "fra.1", "uefa.champions", "uefa.europa",
    "usa.1", "mex.1", "arg.1", "bra.1", "col.1",
)
NBA_PATH = ("basketball", "nba")
VENUE_SEP = " · "
_TERMINAL_NAMES = {"STATUS_POSTPONED", "STATUS_CANCELED", "STATUS_CANCELLED", "STATUS_ABANDONED",
                   "STATUS_FORFEIT", "STATUS_SUSPENDED"}


# ------------------------------------------------------------------ utilidades
def parse_iso(s: str) -> datetime:
    """ISO 8601 de ESPN ('2026-11-22T16:30Z', sin segundos) → datetime aware UTC."""
    s = s.strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    m = re.match(r"^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2})(:\d{2}(?:\.\d+)?)?(.*)$", s)
    if m:
        s = m.group(1) + (m.group(2) or ":00") + m.group(3)
    dt = datetime.fromisoformat(s)
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def american_to_decimal(value) -> float | None:
    try:
        if isinstance(value, str):
            v = value.strip().upper()
            if v in ("EVEN", "EV", "PK"):
                return 2.0
            value = float(v.replace("+", ""))
        value = float(value)
    except (TypeError, ValueError):
        return None
    if value == 0 or abs(value) < 100:
        return None
    return 1 + value / 100 if value > 0 else 1 + 100 / abs(value)


def _as_decimal(v) -> float | None:
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    if abs(f) >= 100:  # americana
        return american_to_decimal(f)
    return f if f > 1.0 else None


def odds_decimal(node) -> float | None:
    """Cuota decimal de un nodo `homeTeamOdds`/`awayTeamOdds`/`drawOdds` (formas conocidas de ESPN)."""
    if not isinstance(node, dict):
        return None
    cands = []
    cur = node.get("current")
    ml = cur.get("moneyLine") if isinstance(cur, dict) else None
    if isinstance(ml, dict):
        cands += [ml.get("decimal"), ml.get("value"), ml.get("american")]
    elif ml is not None:
        cands.append(ml)
    ml = node.get("moneyLine")
    if isinstance(ml, dict):
        cands += [ml.get("decimal"), ml.get("value"), ml.get("american")]
    elif ml is not None:
        cands.append(ml)
    o = node.get("odds")
    if isinstance(o, dict):
        cands.append(o.get("value"))
    for c in cands:
        d = _as_decimal(c) if not isinstance(c, str) else (american_to_decimal(c) or _as_decimal(c))
        if d:
            return d
    return None


def parse_odds(sport: Sport, comp: dict) -> tuple[OddsLine, ...]:
    market = "1X2" if sport is Sport.FOOTBALL else "ML"
    for o in comp.get("odds") or []:
        h, a = odds_decimal(o.get("homeTeamOdds")), odds_decimal(o.get("awayTeamOdds"))
        if not (h and a):
            continue
        book = ((o.get("provider") or {}).get("name")) or ""
        lines = [OddsLine(market, "HOME", h, book), OddsLine(market, "AWAY", a, book)]
        d = odds_decimal(o.get("drawOdds"))
        if sport is Sport.FOOTBALL and d:
            lines.insert(1, OddsLine(market, "DRAW", d, book))
        return tuple(lines)
    return ()


def status_token(status: dict) -> str:
    t = status.get("type") or {}
    name = str(t.get("name", ""))
    if name in _TERMINAL_NAMES:
        return name
    return {"pre": "scheduled", "in": "live", "post": "final"}.get(str(t.get("state", "")), name)


def make_match_id(sport_path: str, league: str, event_id: str) -> str:
    return f"espn:{sport_path}/{league}:{event_id}"


def parse_match_id(match_id: str) -> tuple[str, str, str] | None:
    m = re.match(r"^espn:([^/]+)/([^:]+):(.+)$", match_id)
    return (m.group(1), m.group(2), m.group(3)) if m else None


def parse_event(sport: Sport, sport_path: str, league: str, league_name: str, event: dict) -> RawMatch | None:
    try:
        comp = event["competitions"][0]
        sides = {c["homeAway"]: c for c in comp["competitors"]}
        home_c, away_c = sides["home"], sides["away"]
    except (KeyError, IndexError, TypeError):
        return None

    def team(c: dict) -> Team:
        t = c.get("team") or {}
        return Team(str(t.get("id", c.get("id"))), t.get("displayName") or t.get("name") or "?", t.get("abbreviation") or "")

    status = event.get("status") or comp.get("status") or {}
    stype = status.get("type") or {}
    state = stype.get("state")
    score = None
    if state in ("in", "post"):
        try:
            score = Score(int(home_c["score"]), int(away_c["score"]))
        except (KeyError, TypeError, ValueError):
            score = None
    clock: LiveClock | None = None
    if state == "in":
        if sport is Sport.BASKETBALL:
            clock = basketball_clock(int(status.get("period") or 1), status.get("displayClock"))
        elif stype.get("name") == "STATUS_HALFTIME":
            clock = football_clock(0, halftime=True)
        elif status.get("displayClock"):
            clock = LiveClock(str(status["displayClock"]))
    v = comp.get("venue") or {}
    city = (v.get("address") or {}).get("city")
    venue = (v.get("fullName") or "") + (VENUE_SEP + city if city else "") or None
    return RawMatch(
        match_id=make_match_id(sport_path, league, str(event["id"])), sport=sport,
        competition=league_name, kickoff=parse_iso(event.get("date") or comp["date"]),
        home=team(home_c), away=team(away_c), raw_status=status_token(status), score=score, clock=clock,
        odds=parse_odds(sport, comp), venue=venue, neutral_venue=bool(comp.get("neutralSite")),
    )


# ------------------------------------------------------------- alineaciones (fútbol)
@dataclass(frozen=True, slots=True)
class RosterRow:
    player_id: str
    name: str
    position: str | None
    starter: bool
    stats: dict[str, float] = field(default_factory=dict)


def parse_soccer_rosters(summary: dict) -> dict[str, list[RosterRow]]:
    out: dict[str, list[RosterRow]] = {}
    for r in summary.get("rosters") or []:
        tid = str((r.get("team") or {}).get("id", ""))
        rows = []
        for e in r.get("roster") or []:
            ath = e.get("athlete") or {}
            if "id" not in ath:
                continue
            stats = {}
            for s in e.get("stats") or []:
                try:
                    stats[s["name"]] = float(s["value"])
                except (KeyError, TypeError, ValueError):
                    continue
            rows.append(RosterRow(str(ath["id"]), ath.get("displayName") or ath.get("fullName") or "?",
                                  (e.get("position") or {}).get("abbreviation"), bool(e.get("starter")), stats))
        if tid:
            out[tid] = rows
    return out


def lineup_from_rows(team_id: str, rows: Iterable[RosterRow]) -> TeamLineup | None:
    rows = list(rows)
    starters = [r for r in rows if r.starter]
    if not starters:
        return None  # ESPN aún no publicó la alineación
    slot = lambda r: PlayerSlot(r.player_id, r.name, r.position)
    return TeamLineup(team_id=team_id, starters=tuple(slot(r) for r in starters),
                      bench=tuple(slot(r) for r in rows if not r.starter), is_official=True, source="espn")


# ------------------------------------------------------------------ baloncesto (NBA)
@dataclass(frozen=True, slots=True)
class NbaPlayerLine:
    player_id: str
    name: str
    starter: bool
    minutes: float
    pts: float = 0.0
    fgm: float = 0.0
    fga: float = 0.0
    tpm: float = 0.0
    tpa: float = 0.0
    ftm: float = 0.0
    fta: float = 0.0
    oreb: float = 0.0
    dreb: float = 0.0
    ast: float = 0.0
    tov: float = 0.0
    stl: float = 0.0
    blk: float = 0.0


def _num(x) -> float:
    try:
        return float(str(x).replace("+", ""))
    except (TypeError, ValueError):
        return 0.0


def _pair(x) -> tuple[float, float]:
    m = re.match(r"^\s*(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)\s*$", str(x))
    return (float(m.group(1)), float(m.group(2))) if m else (0.0, 0.0)


def parse_nba_players(summary: dict) -> dict[str, list[NbaPlayerLine]]:
    out: dict[str, list[NbaPlayerLine]] = {}
    for t in (summary.get("boxscore") or {}).get("players") or []:
        tid = str((t.get("team") or {}).get("id", ""))
        lines: list[NbaPlayerLine] = []
        for grp in t.get("statistics") or []:
            labels = [str(l).upper() for l in grp.get("labels") or []]
            ix = {l: i for i, l in enumerate(labels)}
            for a in grp.get("athletes") or []:
                ath = a.get("athlete") or {}
                st = a.get("stats") or []
                if "id" not in ath or not st:
                    continue
                g = lambda k: st[ix[k]] if k in ix and ix[k] < len(st) else None
                fgm, fga = _pair(g("FG"))
                tpm, tpa = _pair(g("3PT"))
                ftm, fta = _pair(g("FT"))
                lines.append(NbaPlayerLine(
                    str(ath["id"]), ath.get("displayName") or "?", bool(a.get("starter")), _num(g("MIN")),
                    _num(g("PTS")), fgm, fga, tpm, tpa, ftm, fta, _num(g("OREB")), _num(g("DREB")),
                    _num(g("AST")), _num(g("TO")), _num(g("STL")), _num(g("BLK")),
                ))
        if tid:
            out[tid] = lines
    return out


_INJ = {"out": InjuryStatus.OUT, "doubtful": InjuryStatus.DOUBTFUL, "questionable": InjuryStatus.QUESTIONABLE,
        "day-to-day": InjuryStatus.QUESTIONABLE, "probable": InjuryStatus.AVAILABLE, "available": InjuryStatus.AVAILABLE}


def parse_injuries(summary: dict) -> dict[str, list[InjuryEntry]]:
    out: dict[str, list[InjuryEntry]] = {}
    for t in summary.get("injuries") or []:
        tid = str((t.get("team") or {}).get("id", ""))
        entries = []
        for i in t.get("injuries") or []:
            ath = i.get("athlete") or {}
            if "id" not in ath:
                continue
            status = _INJ.get(str(i.get("status", "")).strip().lower(), InjuryStatus.QUESTIONABLE)
            entries.append(InjuryEntry(str(ath["id"]), ath.get("displayName") or "?", status))
        if tid:
            out[tid] = entries
    return out


def nba_lineup(team_id: str, lines: list[NbaPlayerLine], injuries: dict[str, list[InjuryEntry]], published: bool) -> TeamLineup | None:
    starters = [l for l in lines if l.starter]
    if not starters:
        return None
    return TeamLineup(
        team_id=team_id, starters=tuple(PlayerSlot(l.player_id, l.name) for l in starters),
        bench=tuple(PlayerSlot(l.player_id, l.name) for l in lines if not l.starter), is_official=True,
        source="espn", injury_report_published=published, injury_report=tuple(injuries.get(team_id, ())),
    )


# ------------------------------------------------------------------------ cliente
@dataclass(frozen=True, slots=True)
class FinishedGame:
    event_id: str
    league: str
    home_id: str
    away_id: str
    home_score: float
    away_score: float
    played_at: datetime
    neutral: bool = False


def parse_finished(data: dict, league: str) -> list[FinishedGame]:
    out = []
    for ev in data.get("events") or []:
        try:
            comp = ev["competitions"][0]
            st = (ev.get("status") or comp.get("status") or {}).get("type") or {}
            if st.get("state") != "post" or str(st.get("name", "")) in _TERMINAL_NAMES:
                continue
            sides = {c["homeAway"]: c for c in comp["competitors"]}
            out.append(FinishedGame(
                str(ev["id"]), league, str(sides["home"]["team"]["id"]), str(sides["away"]["team"]["id"]),
                float(sides["home"]["score"]), float(sides["away"]["score"]),
                parse_iso(ev.get("date") or comp["date"]), bool(comp.get("neutralSite")),
            ))
        except (KeyError, IndexError, TypeError, ValueError):
            continue
    return out


def date_windows(until: date, lookback_days: int, size: int = 90) -> list[tuple[date, date]]:
    """Ventanas alineadas al calendario: las pasadas son inmutables y se cachean para siempre."""
    first = (until - timedelta(days=lookback_days)).toordinal() // size
    last = until.toordinal() // size
    return [(date.fromordinal(max(w * size, 1)), date.fromordinal((w + 1) * size - 1)) for w in range(first, last + 1)]


class EspnClient:
    def __init__(self, http: HttpClient, workers: int = 6) -> None:
        self.http = http
        self.workers = workers

    def scoreboard(self, sport_path: str, league: str, dates: str | None = None, limit: int | None = None,
                   ttl: float | None = 45.0) -> dict:
        params = {k: v for k, v in (("dates", dates), ("limit", limit)) if v is not None}
        return self.http.get_json(f"{BASE}/{sport_path}/{league}/scoreboard", params or None, ttl=ttl)

    def summary(self, sport_path: str, league: str, event_id: str, *, final: bool = False) -> dict:
        return self.http.get_json(f"{BASE}/{sport_path}/{league}/summary", {"event": event_id},
                                  ttl=None if final else 120.0)

    def map(self, fn: Callable, items: list) -> list:
        with ThreadPoolExecutor(max_workers=self.workers) as pool:
            return list(pool.map(fn, items))

    def finished_games(self, sport_path: str, leagues: Iterable[str], until: date, lookback_days: int) -> list[FinishedGame]:
        tasks = [(lg, w) for lg in leagues for w in date_windows(until, lookback_days)]

        def one(task: tuple[str, tuple[date, date]]) -> list[FinishedGame]:
            lg, (a, b) = task
            current = a <= until <= b
            try:
                data = self.scoreboard(sport_path, lg, f"{a:%Y%m%d}-{b:%Y%m%d}", 1000, ttl=3 * 3600.0 if current else None)
            except ProviderError as exc:
                log.warning("Resultados %s %s–%s no disponibles: %s", lg, a, b, exc)
                return []
            return parse_finished(data, lg)

        seen: dict[str, FinishedGame] = {}
        for games in self.map(one, tasks):
            for g in games:
                seen[f"{g.league}:{g.event_id}"] = g
        return sorted(seen.values(), key=lambda g: g.played_at)


# ---------------------------------------------------------------------- proveedor
class EspnProvider:
    """MatchProvider de fútbol y NBA. Las alineaciones se consultan solo cerca del inicio."""

    name = "espn"
    status_map: dict = {}

    def __init__(self, client: EspnClient, football_leagues: Iterable[str] = DEFAULT_FOOTBALL_LEAGUES, *,
                 lineup_window_hours: float = 3.0, clock: Callable[[], datetime] | None = None) -> None:
        self.client = client
        self.football_leagues = tuple(football_leagues)
        self.lineup_window = timedelta(hours=lineup_window_hours)
        self._clock = clock or (lambda: datetime.now(timezone.utc))

    def _targets(self, sport: Sport) -> list[tuple[str, str]]:
        if sport is Sport.FOOTBALL:
            return [("soccer", lg) for lg in self.football_leagues]
        if sport is Sport.BASKETBALL:
            return [NBA_PATH]
        return []

    def fetch_matches(self, sport: Sport, local_day: date) -> list[RawMatch]:
        targets = self._targets(sport)
        if not targets:
            return []
        dates = f"{local_day - timedelta(days=1):%Y%m%d}-{local_day + timedelta(days=1):%Y%m%d}"

        def one(t: tuple[str, str]):
            try:
                return t, self.client.scoreboard(t[0], t[1], dates, 300, ttl=45.0), None
            except ProviderError as exc:
                return t, None, exc

        results = self.client.map(one, targets)
        if all(r[1] is None for r in results):
            raise ProviderError(f"ESPN no respondió: {results[0][2]}")
        raws: list[RawMatch] = []
        for (sp, lg), data, err in results:
            if data is None:
                log.warning("Liga %s omitida: %s", lg, err)
                continue
            league_name = ((data.get("leagues") or [{}])[0].get("name")) or lg
            for ev in data.get("events") or []:
                raw = parse_event(sport, sp, lg, league_name, ev)
                if raw is not None:
                    raws.append(raw)
        return self._attach_lineups(raws)

    def _attach_lineups(self, raws: list[RawMatch]) -> list[RawMatch]:
        now = self._clock()
        due = [r for r in raws if r.raw_status.lower() == "scheduled" and r.kickoff - now <= self.lineup_window]
        by_id = {r.match_id: r for r in due}

        def one(match_id: str):
            raw = by_id[match_id]
            parsed = parse_match_id(match_id)
            try:
                summary = self.client.summary(parsed[0], parsed[1], parsed[2])  # type: ignore[index]
            except (ProviderError, TypeError) as exc:
                log.info("Sin resumen para %s: %s", match_id, exc)
                return match_id, None, None
            return match_id, *lineups_from_summary(raw, summary)

        found = {mid: (h, a) for mid, h, a in self.client.map(one, list(by_id))}
        out = []
        for r in raws:
            h, a = found.get(r.match_id, (None, None))
            out.append(dataclasses.replace(r, home_lineup=h, away_lineup=a) if (h or a) else r)
        return out


def lineups_from_summary(raw: RawMatch, summary: dict) -> tuple[TeamLineup | None, TeamLineup | None]:
    hid, aid = raw.home.team_id, raw.away.team_id
    if raw.sport is Sport.FOOTBALL:
        rosters = parse_soccer_rosters(summary)
        return lineup_from_rows(hid, rosters.get(hid, ())), lineup_from_rows(aid, rosters.get(aid, ()))
    players = parse_nba_players(summary)
    injuries = parse_injuries(summary)
    published = bool(summary.get("injuries"))
    return (nba_lineup(hid, players.get(hid, []), injuries, published),
            nba_lineup(aid, players.get(aid, []), injuries, published))
