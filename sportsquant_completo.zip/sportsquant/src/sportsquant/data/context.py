"""Constructores de MatchContext (datos de entrada del motor) por deporte.

Cada fuente se consulta de forma aislada: si una falla, se anota en `notes`, baja la cobertura de
la capa correspondiente y la proyección continúa (excepto si falta toda la estadística base).
Todo dato usado es anterior al instante de corte `asof` (< inicio del partido).
"""
from __future__ import annotations

import dataclasses
import logging
import statistics
from collections import defaultdict
from collections.abc import Callable, Iterable
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta

from ..core.enums import InjuryStatus, Sport
from ..core.models import Match
from ..core.stats import (
    LeagueData, LeagueGame, MatchContext, PastGame, PlayerValue, TeamData, Venue, Weather,
)
from ..matches.providers.base import ProviderError
from ..projection.params import PARAMS
from ..projection.ratings import fit_league
from .espn import (
    VENUE_SEP, EspnClient, FinishedGame, NbaPlayerLine, RosterRow, parse_injuries, parse_match_id,
    parse_nba_players, parse_soccer_rosters,
)
from .mlb import (
    MlbClient, fip_constants, innings, ops_plus, parse_wind, pitcher_metrics, team_offense, _f,
)
from .park_factors import PARK_FACTORS
from .weather import WeatherClient, safe_weather

log = logging.getLogger(__name__)
AVAIL_PROB = {InjuryStatus.OUT: 0.0, InjuryStatus.DOUBTFUL: 0.15, InjuryStatus.QUESTIONABLE: 0.5, InjuryStatus.AVAILABLE: 1.0}


# --------------------------------------------------------------------- utilidades
def split_venue(venue: str | None) -> tuple[str | None, str | None]:
    if not venue:
        return None, None
    name, _, city = venue.partition(VENUE_SEP)
    return (name or None), (city or None)


def league_games(finished: Iterable[FinishedGame]) -> list[LeagueGame]:
    return [LeagueGame(g.home_id, g.away_id, g.home_score, g.away_score, g.played_at, g.neutral) for g in finished]


def past_games(finished: Iterable[FinishedGame], team_id: str) -> list[PastGame]:
    out = []
    for g in finished:
        if g.home_id == team_id:
            out.append(PastGame(f"{g.league}:{g.event_id}", g.played_at, g.away_id, True, g.home_score, g.away_score, g.neutral))
        elif g.away_id == team_id:
            out.append(PastGame(f"{g.league}:{g.event_id}", g.played_at, g.home_id, False, g.away_score, g.home_score, g.neutral))
    return sorted(out, key=lambda g: g.played_at)


def _guard(notes: list[str], label: str, fn: Callable, default=None):
    """Ejecuta una consulta opcional; ante fallo anota el motivo y devuelve el valor por defecto."""
    try:
        return fn()
    except (ProviderError, KeyError, ValueError, TypeError, IndexError) as exc:
        log.warning("%s: %s", label, exc)
        notes.append(f"Sin {label}: {exc}")
        return default


# ------------------------------------------------------------------------ fútbol
XG_PER_SOT, XG_PER_OFF_TARGET = 0.27, 0.02  # proxy de xG por tiros (calibrado a promedios de ligas top)
GROUPS = {"G": "GK", "GK": "GK", "D": "DEF", "CD": "DEF", "CD-L": "DEF", "CD-R": "DEF", "CB": "DEF", "RB": "DEF",
          "LB": "DEF", "SW": "DEF", "RWB": "DEF", "LWB": "DEF", "WB": "DEF", "M": "MID", "DM": "MID", "CM": "MID",
          "CM-L": "MID", "CM-R": "MID", "AM": "MID", "RM": "MID", "LM": "MID", "CAM": "MID", "CDM": "MID",
          "F": "FWD", "CF": "FWD", "CF-L": "FWD", "CF-R": "FWD", "ST": "FWD", "LW": "FWD", "RW": "FWD", "SS": "FWD"}
OFF_BASE = {"GK": 0.0, "DEF": 0.04, "MID": 0.06, "FWD": 0.08}
DEF_POS = {"GK": 4.0, "DEF": 2.0, "MID": 0.8, "FWD": 0.3}


def soccer_group(pos: str | None) -> str:
    p = (pos or "").upper()
    if p in GROUPS:
        return GROUPS[p]
    return {"G": "GK", "D": "DEF", "M": "MID", "F": "FWD", "S": "FWD"}.get(p[:1], "MID")


def soccer_player_value(row: RosterRow, team_games: int) -> PlayerValue:
    apps = row.stats.get("appearances", 0.0)
    starts = max(apps - row.stats.get("subIns", 0.0), 0.0)
    usage = min(1.0, starts / max(team_games, 1)) if row.stats else 0.5
    group = soccer_group(row.position)
    output = (row.stats.get("totalGoals", 0.0) + 0.7 * row.stats.get("goalAssists", 0.0)) / max(apps, 1.0)
    return PlayerValue(row.player_id, row.name, group, usage, output + OFF_BASE[group], DEF_POS[group])


def team_shots(summary: dict) -> dict[str, tuple[float, float]]:
    out = {}
    for t in (summary.get("boxscore") or {}).get("teams") or []:
        vals = {}
        for s in t.get("statistics") or []:
            try:
                vals[s["name"]] = float(s.get("displayValue", s.get("value")))
            except (KeyError, TypeError, ValueError):
                continue
        if "totalShots" in vals:
            out[str((t.get("team") or {}).get("id"))] = (vals["totalShots"], vals.get("shotsOnTarget", 0.0))
    return out


def xg_proxy(shots: float, on_target: float) -> float:
    return XG_PER_SOT * on_target + XG_PER_OFF_TARGET * max(shots - on_target, 0.0)


class FootballContextBuilder:
    LOOKBACK_DAYS = 300
    XG_LAST_N = 6

    def __init__(self, espn: EspnClient, leagues: Iterable[str], weather: WeatherClient | None = None) -> None:
        self.espn, self.leagues, self.weather = espn, tuple(leagues), weather

    def build(self, match: Match, asof: datetime) -> MatchContext:
        p, notes = PARAMS[Sport.FOOTBALL], []
        finished = [g for g in self.espn.finished_games("soccer", self.leagues, asof.date(), self.LOOKBACK_DAYS) if g.played_at < asof]
        if not finished:
            notes.append("Sin resultados históricos de las ligas configuradas.")
        league = fit_league(league_games(finished), asof=asof, prior_games=p.ratings_prior_games,
                            half_life_days=p.ratings_half_life_days) or LeagueData(1.4, 1.1)
        parsed = parse_match_id(match.match_id)
        today = _guard(notes, "resumen del partido", lambda: self.espn.summary(parsed[0], parsed[1], parsed[2])) if parsed else None
        rosters = parse_soccer_rosters(today) if today else {}
        injuries = parse_injuries(today) if today else {}
        teams = []
        for team, lineup in ((match.home, match.home_lineup), (match.away, match.away_lineup)):
            hist = past_games(finished, team.team_id)
            hist = self._with_xg(team.team_id, hist, notes)
            pool = self._players(team.team_id, hist, rosters.get(team.team_id, []), finished, notes)
            avail = {e.player_id: AVAIL_PROB[e.status] for e in injuries.get(team.team_id, [])}
            active = tuple(s.player_id for s in lineup.starters) if lineup else ()
            teams.append(TeamData(team.team_id, tuple(hist), tuple(pool), active, avail))
        name, city = split_venue(match.venue)
        w, why = safe_weather(self.weather, city, None, match.kickoff_utc)
        if why:
            notes.append(why)
        return MatchContext(match, teams[0], teams[1], league, Venue(name, city, neutral=match.neutral_venue), w, asof, tuple(notes))

    def _with_xg(self, team_id: str, hist: list[PastGame], notes: list[str]) -> list[PastGame]:
        last = [g for g in hist[-self.XG_LAST_N:]]

        def one(g: PastGame):
            lg, _, eid = g.game_id.partition(":")
            try:
                return g, team_shots(self.espn.summary("soccer", lg, eid, final=True))
            except ProviderError:
                return g, {}

        enriched = {}
        for g, shots in self.espn.map(one, last):
            mine, theirs = shots.get(team_id), shots.get(g.opponent_id)
            if mine and theirs:
                enriched[g.game_id] = dataclasses.replace(g, xg_for=xg_proxy(*mine), xg_against=xg_proxy(*theirs))
        return [enriched.get(g.game_id, g) for g in hist]

    def _players(self, team_id: str, hist: list[PastGame], today_rows: list[RosterRow], finished: list[FinishedGame],
                 notes: list[str]) -> list[PlayerValue]:
        rows: dict[str, RosterRow] = {}
        if hist:  # plantilla del último partido: incluye a habituales que hoy no están en la convocatoria
            lg, _, eid = hist[-1].game_id.partition(":")
            prev = _guard(notes, "plantilla del último partido", lambda: self.espn.summary("soccer", lg, eid, final=True))
            if prev:
                for r in parse_soccer_rosters(prev).get(team_id, []):
                    rows[r.player_id] = r
        for r in today_rows:
            rows[r.player_id] = r
        games = max(1, sum(1 for g in hist if g.played_at >= (hist[-1].played_at - timedelta(days=200)))) if hist else 1
        return [soccer_player_value(r, games) for r in rows.values()]


# -------------------------------------------------------------------- baloncesto
class _Totals:
    __slots__ = ("pts", "fgm", "fga", "tpm", "tpa", "fta", "oreb", "tov", "minutes")

    def __init__(self, lines: list[NbaPlayerLine]) -> None:
        self.pts = sum(l.pts for l in lines)
        self.fgm, self.fga = sum(l.fgm for l in lines), sum(l.fga for l in lines)
        self.tpm, self.tpa = sum(l.tpm for l in lines), sum(l.tpa for l in lines)
        self.fta, self.oreb = sum(l.fta for l in lines), sum(l.oreb for l in lines)
        self.tov, self.minutes = sum(l.tov for l in lines), sum(l.minutes for l in lines)

    @property
    def poss(self) -> float:
        return self.fga + 0.44 * self.fta - self.oreb + self.tov


def nba_profile(team_id: str, boxes: list[dict[str, list[NbaPlayerLine]]]):
    """(métricas de equipo, jugadores, pace de liga, triples (anotados, intentados) de liga)."""
    acc = defaultdict(float)
    games = 0
    per_player: dict[str, dict] = {}
    lg_pace, lg3m, lg3a = [], 0.0, 0.0
    for box in boxes:
        if team_id not in box or len(box) != 2:
            continue
        opp_id = next(t for t in box if t != team_id)
        own, opp = _Totals(box[team_id]), _Totals(box[opp_id])
        if own.minutes <= 0 or own.poss <= 0 or opp.poss <= 0:
            continue
        game_min = max(own.minutes / 5.0, 48.0)
        games += 1
        pace = (own.poss + opp.poss) / 2 * 48.0 / game_min
        lg_pace.append(pace)
        lg3m += own.tpm + opp.tpm
        lg3a += own.tpa + opp.tpa
        acc["pace"] += pace
        for k, v in (("ortg", 100 * own.pts / own.poss), ("drtg", 100 * opp.pts / opp.poss),
                     ("fga_pg", own.fga), ("three_pa_pg", own.tpa), ("three_pm_pg", own.tpm), ("poss_pg", own.poss),
                     ("opp_fga_pg", opp.fga), ("opp_three_pa_pg", opp.tpa), ("opp_three_pm_pg", opp.tpm), ("opp_poss_pg", opp.poss)):
            acc[k] += v
        for l in box[team_id]:
            if l.minutes <= 0:
                continue
            d = per_player.setdefault(l.player_id, defaultdict(float, name=l.name))
            d["min"] += l.minutes
            d["off"] += l.pts + 0.7 * l.ast - 0.9 * l.tov - 0.7 * (l.fga - l.fgm) - 0.35 * (l.fta - l.ftm)
            d["def"] += 1.5 * l.stl + 1.2 * l.blk + 0.3 * l.dreb
    if games == 0:
        return {}, [], [], (0.0, 0.0)
    metrics = {k: v / games for k, v in acc.items()}
    metrics["games_n"] = float(games)
    shrink_k = 300.0
    offs = [d["off"] * 36 / d["min"] for d in per_player.values() if d["min"] >= 30]
    defs = [d["def"] * 36 / d["min"] for d in per_player.values() if d["min"] >= 30]
    m_off, m_def = (statistics.median(offs) if offs else 0.0), (statistics.median(defs) if defs else 0.0)
    players = []
    for pid, d in per_player.items():
        mpg = d["min"] / games
        if d["min"] < 30 or mpg < 3:
            continue
        w = d["min"] / (d["min"] + shrink_k)
        players.append(PlayerValue(pid, d["name"], "G", usage=min(1.0, mpg / 36.0),
                                   off_value=w * d["off"] * 36 / d["min"] + (1 - w) * m_off,
                                   def_value=w * d["def"] * 36 / d["min"] + (1 - w) * m_def, minutes=mpg))
    return metrics, players, lg_pace, (lg3m, lg3a)


class BasketballContextBuilder:
    LOOKBACK_DAYS = 400
    LAST_N = 12

    def __init__(self, espn: EspnClient) -> None:
        self.espn = espn

    def build(self, match: Match, asof: datetime) -> MatchContext:
        p, notes = PARAMS[Sport.BASKETBALL], []
        finished = [g for g in self.espn.finished_games("basketball", ["nba"], asof.date(), self.LOOKBACK_DAYS) if g.played_at < asof]
        if not finished:
            notes.append("Sin resultados históricos de la NBA.")
        league = fit_league(league_games(finished), asof=asof, prior_games=p.ratings_prior_games,
                            half_life_days=p.ratings_half_life_days) or LeagueData(114.0, 111.0)
        parsed = parse_match_id(match.match_id)
        today = _guard(notes, "resumen del partido", lambda: self.espn.summary(parsed[0], parsed[1], parsed[2])) if parsed else None
        injuries = parse_injuries(today) if today else {}
        teams, pace_all, lg3 = [], [], [0.0, 0.0]
        for team, lineup in ((match.home, match.home_lineup), (match.away, match.away_lineup)):
            hist = past_games(finished, team.team_id)
            events = [g.game_id.partition(":")[2] for g in hist[-self.LAST_N:]]

            def fetch(eid: str):
                try:
                    return parse_nba_players(self.espn.summary("basketball", "nba", eid, final=True))
                except ProviderError:
                    return {}

            boxes = [b for b in self.espn.map(fetch, events) if b]
            metrics, players, pace, three = nba_profile(team.team_id, boxes)
            if not metrics:
                notes.append(f"Sin box scores recientes de {team.label}.")
            pace_all += pace
            lg3[0] += three[0]
            lg3[1] += three[1]
            avail = {e.player_id: AVAIL_PROB[e.status] for e in injuries.get(team.team_id, [])}
            active = tuple(s.player_id for s in lineup.starters) if lineup else ()
            teams.append(TeamData(team.team_id, tuple(hist), tuple(players), active, avail, metrics))
        lg_metrics = {}
        if pace_all:
            lg_metrics["pace"] = sum(pace_all) / len(pace_all)
        if lg3[1] > 0:
            lg_metrics["three_pct"] = lg3[0] / lg3[1]
        league = dataclasses.replace(league, metrics={**league.metrics, **lg_metrics})
        return MatchContext(match, teams[0], teams[1], league, Venue(match.venue, neutral=match.neutral_venue, roof="dome"),
                            None, asof, tuple(notes))


# ------------------------------------------------------------------------ béisbol
class BaseballContextBuilder:
    LOOKBACK_DAYS = 365
    PA_PRIOR, SPLIT_PRIOR = 150.0, 100.0

    def __init__(self, mlb: MlbClient, weather: WeatherClient | None = None) -> None:
        self.mlb, self.weather = mlb, weather

    @staticmethod
    def _season(asof: datetime) -> int:
        return asof.year if asof.month >= 3 else asof.year - 1

    def build(self, match: Match, asof: datetime) -> MatchContext:
        p, notes = PARAMS[Sport.BASEBALL], []
        season = self._season(asof)
        finished = [g for g in self.mlb.finished_games(asof.date(), self.LOOKBACK_DAYS) if g.played_at < asof]
        if not finished:
            notes.append("Sin resultados históricos de MLB.")
        league = fit_league(league_games(finished), asof=asof, prior_games=p.ratings_prior_games,
                            half_life_days=p.ratings_half_life_days) or LeagueData(4.6, 4.4)
        hitting = _guard(notes, "estadísticas de bateo por equipo", lambda: self.mlb.team_stats("hitting", season), {})
        pitching = _guard(notes, "estadísticas de pitcheo por equipo", lambda: self.mlb.team_stats("pitching", season), {})
        off, consts = team_offense(hitting), fip_constants(pitching)
        lg_metrics = {}
        if off:
            lg_metrics["runs_pg"] = off["runs_pg"]
        if consts:
            lg_metrics["lg_fip"] = consts["lg_fip"]
        league = dataclasses.replace(league, metrics={**league.metrics, **lg_metrics})

        pk = match.match_id.partition(":")[2]
        game = _guard(notes, "datos del juego (clima/parque)", lambda: next(
            g for d in self.mlb.schedule(asof.date(), asof.date(), hydrate="weather,venue(location),team", game_pk=pk, ttl=300.0)["dates"] for g in d["games"]), {})
        venue, weather = self._venue_weather(match, game, asof, notes)

        sp = {"home": match.home_lineup.starting_pitcher if match.home_lineup else None,
              "away": match.away_lineup.starting_pitcher if match.away_lineup else None}
        hands = {side: self._hand(pl.player_id, notes) if pl else None for side, pl in sp.items()}
        teams = []
        for side, team, lineup in (("home", match.home, match.home_lineup), ("away", match.away, match.away_lineup)):
            opp_side = "away" if side == "home" else "home"
            hist = past_games(finished, team.team_id)
            metrics: dict[str, float] = {}
            wrc = ops_plus(hitting.get(team.team_id, {}), off) if off else None
            if wrc is not None:
                metrics.update(wrc_plus=wrc, wrc_plus_is_proxy=1.0)
            roster = _guard(notes, f"plantilla de {team.label}", lambda: self.mlb.roster(team.team_id, season), [])
            bullpen = self._bullpen(roster, consts)
            metrics.update(bullpen)
            if sp[side] is not None and consts:
                metrics.update(self._starter(sp[side].player_id, season, consts, notes))
            metrics["bullpen_pitches_3d"] = self._bullpen_pitches(team.team_id, finished, asof, notes)
            active = tuple(s.player_id for s in lineup.starters) if lineup else ()
            players = self._batters(roster, season, active, hands[opp_side], off, notes)
            teams.append(TeamData(team.team_id, tuple(hist), tuple(players), active, {}, metrics))
        return MatchContext(match, teams[0], teams[1], league, venue, weather, asof, tuple(notes))

    # -- piezas
    def _venue_weather(self, match: Match, game: dict, asof: datetime, notes: list[str]):
        name, city = split_venue(match.venue)
        abbr = ((game.get("teams") or {}).get("home") or {}).get("team", {}).get("abbreviation") or match.home.short_name
        pf, roof = PARK_FACTORS.get(abbr, (None, "open"))
        loc = ((game.get("venue") or {}).get("location") or {}).get("defaultCoordinates") or {}
        lat, lon = loc.get("latitude"), loc.get("longitude")
        venue = Venue(name, city, lat, lon, roof=roof, park_factor=pf)
        w = game.get("weather") or {}
        weather: Weather | None = None
        if w.get("temp") not in (None, ""):
            try:
                weather = Weather(temp_c=(float(w["temp"]) - 32) * 5 / 9, wind_out_ms=parse_wind(w.get("wind")),
                                  wind_ms=abs(parse_wind(w.get("wind")) or 0.0))
            except ValueError:
                weather = None
        if weather is None and roof != "dome":
            weather, why = safe_weather(self.weather, city, None, match.kickoff_utc, lat, lon)
            if why:
                notes.append(why)
        return venue, weather

    def _hand(self, pid: str, notes: list[str]) -> str | None:
        person = _guard(notes, "mano del abridor", lambda: self.mlb.person(pid), {})
        return ((person.get("pitchHand") or {}).get("code") or None)

    def _starter(self, pid: str, season: int, consts: dict, notes: list[str]) -> dict[str, float]:
        for yr in (season, season - 1):
            splits = _guard(notes, "estadísticas del abridor", lambda yr=yr: self.mlb.person_stat(pid, "pitching", yr), [])
            if splits:
                m = pitcher_metrics(splits[0].get("stat") or {}, consts)
                if m:
                    return {"sp_fip": m["fip"], "sp_xfip": m["xfip"], "sp_ip": m["ip"],
                            "sp_ip_per_start": m.get("ip_per_start", 5.3)}
        return {}

    @staticmethod
    def _roster_stat(person: dict, group: str) -> dict:
        for s in person.get("stats") or []:
            if str((s.get("group") or {}).get("displayName", "")).lower() == group:
                splits = s.get("splits") or []
                if splits:
                    return splits[0].get("stat") or {}
        return {}

    def _bullpen(self, roster: list[dict], consts: dict) -> dict[str, float]:
        agg = defaultdict(float)
        for r in roster:
            st = self._roster_stat(r.get("person") or {}, "pitching")
            if st and _f(st, "gamesStarted") == 0 and innings(st.get("inningsPitched")) > 0:
                for k in ("homeRuns", "baseOnBalls", "hitBatsmen", "strikeOuts"):
                    agg[k] += _f(st, k)
                agg["ip"] += innings(st.get("inningsPitched"))
        if agg["ip"] < 20 or "c_fip" not in consts:
            return {}
        fip = (13 * agg["homeRuns"] + 3 * (agg["baseOnBalls"] + agg["hitBatsmen"]) - 2 * agg["strikeOuts"]) / agg["ip"] + consts["c_fip"]
        return {"bullpen_fip": fip}

    def _bullpen_pitches(self, team_id: str, finished: list[FinishedGame], asof: datetime, notes: list[str]) -> float:
        recent = [g for g in finished if g.played_at >= asof - timedelta(days=3) and team_id in (g.home_id, g.away_id)]
        total = 0.0
        for g in recent:
            box = _guard(notes, "boxscore reciente", lambda g=g: self.mlb.boxscore(g.event_id), None)
            if not box:
                continue
            side = "home" if g.home_id == team_id else "away"
            t = (box.get("teams") or {}).get(side) or {}
            for pid in (t.get("pitchers") or [])[1:]:  # el primero es el abridor
                st = (((t.get("players") or {}).get(f"ID{pid}") or {}).get("stats") or {}).get("pitching") or {}
                total += _f(st, "pitchesThrown")
        return total

    def _batters(self, roster: list[dict], season: int, active: tuple[str, ...], opp_hand: str | None,
                 off: dict, notes: list[str]) -> list[PlayerValue]:
        lg_ops = off.get("lg_ops") if off else None
        rows = []
        for r in roster:
            person = r.get("person") or {}
            st = self._roster_stat(person, "hitting")
            pa = _f(st, "plateAppearances")
            if pa > 0 and person.get("id") is not None:
                rows.append((str(person["id"]), person.get("fullName", "?"), st, pa))
        if not rows or not lg_ops:
            return []
        max_pa = max(r[3] for r in rows)
        top = {r[0] for r in sorted(rows, key=lambda r: r[3], reverse=True)[:9]}
        want = top | set(active)
        code = {"L": "vl", "R": "vr"}.get(opp_hand or "")

        def split_ops(pid: str) -> tuple[float, float] | None:
            if not code:
                return None
            try:
                for s in self.mlb.person_stat(pid, "hitting", season, stats="statSplits", sit_codes="vl,vr"):
                    if (s.get("split") or {}).get("code") == code:
                        st = s.get("stat") or {}
                        return float(st["ops"]), _f(st, "plateAppearances")
            except (ProviderError, KeyError, ValueError, TypeError):
                return None
            return None

        ids = sorted(want)
        with ThreadPoolExecutor(max_workers=self.mlb.workers) as pool:
            splits = dict(zip(ids, pool.map(split_ops, ids))) if code else {}
        out = []
        for pid, name, st, pa in rows:
            try:
                ops = float(st["ops"])
            except (KeyError, ValueError, TypeError):
                continue
            sp = splits.get(pid)
            if sp:
                ops = (sp[1] * sp[0] + self.SPLIT_PRIOR * ops) / (sp[1] + self.SPLIT_PRIOR)
            value = (pa * ops + self.PA_PRIOR * lg_ops) / (pa + self.PA_PRIOR) / lg_ops
            out.append(PlayerValue(pid, name, "BAT", usage=pa / max_pa, off_value=value))
        return out


# ------------------------------------------------------------------------- fábrica
class ContextFactory:
    def __init__(self, builders: dict[Sport, object]) -> None:
        self._builders = builders

    def build(self, match: Match, asof: datetime) -> MatchContext:
        builder = self._builders.get(match.sport)
        if builder is None:
            raise ProviderError(f"Sin constructor de datos para {match.sport.value}")
        return builder.build(match, asof)  # type: ignore[attr-defined]
