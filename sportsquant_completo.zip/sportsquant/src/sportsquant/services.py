"""Composición de la aplicación: proveedores, servicio de partidos, motor y trabajador."""
from __future__ import annotations

import os
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

import httpx

from .core.enums import Sport
from .data.context import BaseballContextBuilder, BasketballContextBuilder, ContextFactory, FootballContextBuilder
from .data.espn import EspnClient, EspnProvider
from .data.http import HttpClient
from .data.mlb import MlbClient, MlbProvider
from .data.storage import Storage
from .data.weather import WeatherClient
from .matches.providers.composite import CompositeProvider
from .matches.service import MatchService
from .projection.engine import ProjectionEngine
from .settings import UserSettings, load_settings
from .workers.projection_worker import ProjectionWorker


def default_data_dir() -> Path:
    # Flet define FLET_APP_STORAGE_DATA en Android/iOS (almacenamiento persistente de la app).
    base = os.getenv("FLET_APP_STORAGE_DATA")
    return Path(base) if base else Path.home() / ".sportsquant"


@dataclass
class Services:
    storage: Storage
    http: HttpClient
    espn_provider: EspnProvider
    football_builder: FootballContextBuilder
    matches: MatchService
    worker: ProjectionWorker
    settings: UserSettings

    def apply_leagues(self, leagues: list[str]) -> None:
        self.espn_provider.football_leagues = tuple(leagues)
        self.football_builder.leagues = tuple(leagues)

    def close(self) -> None:
        self.worker.shutdown()
        self.http.close()
        self.storage.close()


def create_services(data_dir: Path | None = None, *, transport: httpx.BaseTransport | None = None,
                    clock: Callable[[], datetime] | None = None) -> Services:
    """`transport` y `clock` permiten inyectar red y reloj falsos en pruebas de integración."""
    data_dir = data_dir or default_data_dir()
    storage = Storage(data_dir / "sportsquant.db")
    storage.purge()
    settings = load_settings(storage)
    http = HttpClient(storage, transport=transport)
    espn, mlb, weather = EspnClient(http), MlbClient(http), WeatherClient(http)
    espn_provider = EspnProvider(espn, settings.football_leagues, clock=clock)
    provider = CompositeProvider({Sport.FOOTBALL: espn_provider, Sport.BASKETBALL: espn_provider,
                                  Sport.BASEBALL: MlbProvider(mlb, odds_client=espn)})
    football = FootballContextBuilder(espn, settings.football_leagues, weather)
    factory = ContextFactory({Sport.FOOTBALL: football, Sport.BASKETBALL: BasketballContextBuilder(espn),
                              Sport.BASEBALL: BaseballContextBuilder(mlb, weather)})
    matches = MatchService(provider, clock=clock)
    worker = ProjectionWorker(matches, factory, ProjectionEngine(), storage, clock=clock)
    return Services(storage, http, espn_provider, football, matches, worker, settings)
