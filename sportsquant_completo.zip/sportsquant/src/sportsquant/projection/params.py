"""Parámetros del modelo por deporte (ajustables y documentados)."""
from __future__ import annotations

from dataclasses import dataclass

from ..core.enums import Sport


@dataclass(frozen=True, slots=True)
class SportParams:
    ratings_prior_games: float  # pseudo-partidos de contracción en el IPF
    ratings_half_life_days: float  # decaimiento de los resultados que entran al IPF
    half_life_days: float  # decaimiento de la forma reciente (capa 3)
    form_prior: float  # pseudo-partidos que contraen la forma hacia lo esperado
    form_weight: float  # peso del log-ratio de forma
    form_clip: tuple[float, float]
    scenario_prior: float  # capa 2: escenarios similares
    scenario_weight: float
    scenario_clip: tuple[float, float]
    layer_clip: tuple[float, float]  # límite del producto capas 1-3 por equipo
    lineup_beta: float  # capa 1: elasticidad de la tasa respecto al ratio de alineación
    lineup_clip: tuple[float, float]
    park_weight: float = 0.5  # béisbol: cuánto del park factor se aplica


PARAMS: dict[Sport, SportParams] = {
    Sport.FOOTBALL: SportParams(
        ratings_prior_games=4.0, ratings_half_life_days=180.0, half_life_days=35.0,
        form_prior=4.0, form_weight=0.5, form_clip=(0.85, 1.15),
        scenario_prior=8.0, scenario_weight=0.35, scenario_clip=(0.92, 1.08),
        layer_clip=(0.75, 1.30), lineup_beta=0.8, lineup_clip=(0.82, 1.08),
    ),
    Sport.BASKETBALL: SportParams(
        ratings_prior_games=6.0, ratings_half_life_days=120.0, half_life_days=21.0,
        form_prior=5.0, form_weight=0.5, form_clip=(0.93, 1.07),
        scenario_prior=10.0, scenario_weight=0.3, scenario_clip=(0.96, 1.04),
        layer_clip=(0.88, 1.12), lineup_beta=1.0, lineup_clip=(0.85, 1.06),
    ),
    Sport.BASEBALL: SportParams(
        ratings_prior_games=8.0, ratings_half_life_days=240.0, half_life_days=30.0,
        form_prior=8.0, form_weight=0.4, form_clip=(0.90, 1.10),
        scenario_prior=15.0, scenario_weight=0.3, scenario_clip=(0.95, 1.05),
        layer_clip=(0.80, 1.25), lineup_beta=1.0, lineup_clip=(0.85, 1.10),
        park_weight=0.5,
    ),
}
