"""Resultado serializable de una proyección."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone

MIN_SIMULATIONS = 1_000
MAX_SIMULATIONS = 50_000
DEFAULT_SIMULATIONS = 10_000


def clamp_simulations(n: int | float) -> int:
    return int(min(MAX_SIMULATIONS, max(MIN_SIMULATIONS, int(n))))


@dataclass(frozen=True, slots=True)
class LayerReport:
    name: str
    home_mult: float
    away_mult: float
    coverage: float
    notes: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class ProjectionResult:
    match_id: str
    sport: str
    n_simulations: int
    created_at: datetime
    kickoff_utc: datetime
    probs: dict[str, float]  # HOME / DRAW (solo fútbol) / AWAY
    mc_se: dict[str, float]  # error estándar Monte Carlo de cada probabilidad
    exp_home: float  # marcador esperado simulado
    exp_away: float
    base_home: float  # tasas tras capa 4 y tras capas 1-3
    base_away: float
    rate_home: float
    rate_away: float
    layers: tuple[LayerReport, ...]
    coverage: float  # cobertura de datos promedio ponderada (0..1)
    top_scores: tuple[tuple[int, int, float], ...] = ()
    margin_sd: float | None = None
    total_sd: float | None = None
    notes: tuple[str, ...] = field(default_factory=tuple)

    @property
    def exp_total(self) -> float:
        return self.exp_home + self.exp_away

    def to_dict(self) -> dict:
        return {
            "match_id": self.match_id, "sport": self.sport, "n_simulations": self.n_simulations,
            "created_at": self.created_at.isoformat(), "kickoff_utc": self.kickoff_utc.isoformat(),
            "probs": self.probs, "mc_se": self.mc_se,
            "exp_home": self.exp_home, "exp_away": self.exp_away,
            "base_home": self.base_home, "base_away": self.base_away,
            "rate_home": self.rate_home, "rate_away": self.rate_away,
            "layers": [
                {"name": l.name, "home_mult": l.home_mult, "away_mult": l.away_mult,
                 "coverage": l.coverage, "notes": list(l.notes)} for l in self.layers
            ],
            "coverage": self.coverage,
            "top_scores": [list(t) for t in self.top_scores],
            "margin_sd": self.margin_sd, "total_sd": self.total_sd, "notes": list(self.notes),
        }

    @classmethod
    def from_dict(cls, d: dict) -> ProjectionResult:
        def dt(s: str) -> datetime:
            x = datetime.fromisoformat(s)
            return x if x.tzinfo else x.replace(tzinfo=timezone.utc)

        return cls(
            match_id=d["match_id"], sport=d["sport"], n_simulations=int(d["n_simulations"]),
            created_at=dt(d["created_at"]), kickoff_utc=dt(d["kickoff_utc"]),
            probs={k: float(v) for k, v in d["probs"].items()},
            mc_se={k: float(v) for k, v in d["mc_se"].items()},
            exp_home=float(d["exp_home"]), exp_away=float(d["exp_away"]),
            base_home=float(d["base_home"]), base_away=float(d["base_away"]),
            rate_home=float(d["rate_home"]), rate_away=float(d["rate_away"]),
            layers=tuple(
                LayerReport(l["name"], float(l["home_mult"]), float(l["away_mult"]),
                            float(l["coverage"]), tuple(l.get("notes", ())))
                for l in d["layers"]
            ),
            coverage=float(d["coverage"]),
            top_scores=tuple((int(a), int(b), float(p)) for a, b, p in d.get("top_scores", ())),
            margin_sd=d.get("margin_sd"), total_sd=d.get("total_sd"), notes=tuple(d.get("notes", ())),
        )
