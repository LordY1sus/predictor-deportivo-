"""Capa 3 — Forma, fatiga y contexto.

* Forma: razón real/esperado con decaimiento exponencial (vida media por deporte).
  Las rachas se capturan aquí (los residuos recientes pesan más); la importancia de la
  competición entra como `PastGame.weight`.
* Fatiga: descanso, back-to-back y viajes (fútbol/baloncesto); carga de bullpen (béisbol).
"""
from __future__ import annotations

from ...core.enums import Sport
from ...core.stats import MatchContext, TeamData
from ..params import SportParams
from .common import LayerOutput, cut_time, damped, residual_ratios

BULLPEN_TYPICAL_3D = 420.0  # lanzamientos de relevistas en 3 días (referencia)


def rest_effects(sport: Sport, team: TeamData, ctx: MatchContext, *, away_today: bool) -> tuple[float, float, list[str]]:
    """(multiplicador de su ataque, multiplicador sobre el ataque rival, notas)."""
    kick, cut = ctx.match.kickoff_utc, cut_time(ctx)
    past = sorted((g for g in team.history if g.played_at < cut), key=lambda g: g.played_at, reverse=True)
    notes: list[str] = []
    att = opp = 1.0
    if sport is Sport.FOOTBALL:
        if past:
            rest = (kick - past[0].played_at).total_seconds() / 86400
            eff = max(-0.012 * max(0.0, 4.0 - rest), -0.05)
            if sum(1 for g in past if (kick - g.played_at).days <= 14) >= 5:
                eff -= 0.015
                notes.append("calendario congestionado")
            att += eff
            if eff < 0:
                notes.append(f"descanso {rest:.1f} d")
    elif sport is Sport.BASKETBALL:
        if past:
            rest = (kick - past[0].played_at).total_seconds() / 86400
            eff = 0.0
            if rest < 1.3:
                eff -= 0.022
                notes.append("back-to-back")
                if sum(1 for g in past if (kick - g.played_at).days < 4) >= 2:
                    eff -= 0.008
                    notes.append("3 partidos en 4 noches")
            elif rest >= 3.0:
                eff += 0.004
            streak = 0
            for g in past:
                if g.is_home:
                    break
                streak += 1
            if away_today and streak >= 3:
                eff -= 0.006
                notes.append(f"{streak} partidos seguidos de visita")
            att += eff
    else:
        pitches = team.metrics.get("bullpen_pitches_3d")
        if pitches is not None and pitches > BULLPEN_TYPICAL_3D:
            extra = min(0.06, 0.015 * (pitches - BULLPEN_TYPICAL_3D) / 100.0)
            opp += extra  # bullpen cansado => el rival anota más
            notes.append(f"bullpen exigido ({pitches:.0f} lanz. en 3 d)")
    return att, opp, notes


def form_fatigue_layer(ctx: MatchContext, p: SportParams) -> LayerOutput:
    sport, lg, cut = ctx.match.sport, ctx.league, cut_time(ctx)
    fh = residual_ratios(ctx.home, lg, cut, half_life=p.half_life_days, prior=p.form_prior)
    fa = residual_ratios(ctx.away, lg, cut, half_life=p.half_life_days, prior=p.form_prior)
    att_h, def_h = damped(fh[0], p.form_weight, p.form_clip), damped(fh[1], p.form_weight, p.form_clip)
    att_a, def_a = damped(fa[0], p.form_weight, p.form_clip), damped(fa[1], p.form_weight, p.form_clip)
    ra_h, ro_h, n1 = rest_effects(sport, ctx.home, ctx, away_today=False)
    ra_a, ro_a, n2 = rest_effects(sport, ctx.away, ctx, away_today=True)
    notes = [
        f"Forma local ataque×{att_h:.3f} defensa×{def_h:.3f} ({fh[2]} partidos); "
        f"visita ataque×{att_a:.3f} defensa×{def_a:.3f} ({fa[2]} partidos)."
    ]
    notes += [f"Local: {x}" for x in n1] + [f"Visita: {x}" for x in n2]
    coverage = min(1.0, (fh[2] + fa[2]) / 12.0)
    return LayerOutput(
        "L3 forma/fatiga",
        home_mult=att_h * def_a * ra_h * ro_a,
        away_mult=att_a * def_h * ra_a * ro_h,
        coverage=coverage,
        notes=tuple(notes),
    )
