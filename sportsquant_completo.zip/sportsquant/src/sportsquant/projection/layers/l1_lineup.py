"""Capa 1 — Alineación: impacto de quién entra y sale respecto a la plantilla habitual.

Fútbol/béisbol: razón entre el valor de los titulares de hoy y el de los titulares habituales.
Baloncesto: redistribución de minutos (jugadores OUT/dudosos) con valor sobre reemplazo.
"""
from __future__ import annotations

import statistics

from ...core.enums import Sport
from ...core.stats import MatchContext, TeamData
from ..params import SportParams
from .common import LayerOutput, clip

QUALITY_BASE, QUALITY_SLOPE = 0.8, 0.4  # peso de calidad = 0.8 + 0.4·uso
BASEBALL_SLOT_WEIGHTS = (1.13, 1.09, 1.06, 1.03, 1.00, 0.97, 0.94, 0.91, 0.88)  # PA relativos por turno
BASKET_MINUTES_CAP = 38.0
BASKET_TEAM_MINUTES = 240.0
BASKET_OFF_SCALE = 0.5  # parte del aporte individual que no absorben los compañeros
BASKET_DEF_SCALE = 1.0
REDISTRIBUTED_SHARE = 0.7  # resto de minutos va a nivel de reemplazo


def _unknown(p: SportParams) -> tuple[float, float, float, str]:
    return 1.0, 1.0, 0.0, "sin datos de jugadores/alineación"


def _ratio_team(team: TeamData, p: SportParams, size: int) -> tuple[float, float, float, str]:
    pool = {pl.player_id: pl for pl in team.players}
    if not pool or not team.active_ids:
        return _unknown(p)
    med_off = statistics.median(pl.off_value for pl in pool.values())
    med_def = statistics.median(pl.def_value for pl in pool.values())

    def val(pid: str) -> tuple[float, float, float]:
        pl = pool.get(pid)
        return (pl.usage, pl.off_value, pl.def_value) if pl else (0.3, med_off, med_def)

    active = [val(pid) for pid in team.active_ids]
    usual = sorted(pool.values(), key=lambda x: (x.usage, x.off_value), reverse=True)[:size]
    usual_v = [(x.usage, x.off_value, x.def_value) for x in usual]

    def score(vals: list[tuple[float, float, float]], i: int, weights=None) -> float:
        ws = weights or [1.0] * len(vals)
        return sum(w * (QUALITY_BASE + QUALITY_SLOPE * v[0]) * v[i] for w, v in zip(ws, vals))

    weights = BASEBALL_SLOT_WEIGHTS[: len(active)] if size == 9 else None
    uw = BASEBALL_SLOT_WEIGHTS[: len(usual_v)] if size == 9 else None
    so, su = score(active, 1, weights), score(usual_v, 1, uw)
    do, du = score(active, 2), score(usual_v, 2)
    r_off = so / su if su > 0 else 1.0
    r_def = do / du if du > 0 else 1.0
    cov = sum(1 for pid in team.active_ids if pid in pool) / len(team.active_ids)
    missing = [pl.name for pl in usual if pl.player_id not in team.active_ids]
    note = f"ratio ataque {r_off:.3f}, defensa {r_def:.3f}" + (f"; habituales fuera: {', '.join(missing[:4])}" if missing else "")
    return r_off, r_def, cov, note


def _percentile(values: list[float], q: float) -> float:
    s = sorted(values)
    return s[min(len(s) - 1, int(q * (len(s) - 1)))]


def _basketball_team(team: TeamData, ref_pts: float) -> tuple[float, float, float, str]:
    pool = [pl for pl in team.players if pl.minutes > 0]
    if not pool or not team.active_ids:
        return 1.0, 1.0, 0.0, "sin datos de jugadores/alineación"
    active = set(team.active_ids)
    rep_o = _percentile([pl.off_value for pl in pool], 0.2)
    rep_d = _percentile([pl.def_value for pl in pool], 0.2)
    avail = {pl.player_id: (1.0 if pl.player_id in active else float(team.availability.get(pl.player_id, 1.0))) for pl in pool}
    base = {pl.player_id: pl.minutes * avail[pl.player_id] for pl in pool}
    lost = sum(pl.minutes * (1 - avail[pl.player_id]) for pl in pool)
    given = {pid: 0.0 for pid in base}
    pool_share = lost * REDISTRIBUTED_SHARE
    for _ in range(3):  # reparto proporcional con tope por jugador
        room = {pid: max(0.0, BASKET_MINUTES_CAP - (base[pid] + given[pid])) for pid in base if base[pid] > 0}
        weights = {pid: base[pid] for pid in room if room[pid] > 0}
        tot = sum(weights.values())
        if tot <= 0 or pool_share <= 1e-9:
            break
        spent = 0.0
        for pid, w in weights.items():
            add = min(room[pid], pool_share * w / tot)
            given[pid] += add
            spent += add
        pool_share -= spent
    d_off = d_def = 0.0
    for pl in pool:
        new_m = base[pl.player_id] + given[pl.player_id]
        d_m = new_m - pl.minutes
        d_off += d_m * (pl.off_value - rep_o) / 36.0
        d_def += d_m * (pl.def_value - rep_d) / 36.0
    off_mult = 1.0 + BASKET_OFF_SCALE * d_off / ref_pts
    def_mult_on_opp = 1.0 - BASKET_DEF_SCALE * d_def / ref_pts
    cov = sum(1 for pid in team.active_ids if pid in avail) / len(team.active_ids)
    out = [pl.name for pl in pool if avail[pl.player_id] < 1.0]
    note = f"Δataque {d_off:+.2f} pts, Δdefensa {d_def:+.2f}" + (f"; bajas/dudas: {', '.join(out[:4])}" if out else "")
    return off_mult, def_mult_on_opp, cov, note


def lineup_layer(ctx: MatchContext, p: SportParams) -> LayerOutput:
    sport = ctx.match.sport
    res = []
    for team in (ctx.home, ctx.away):
        if sport is Sport.BASKETBALL:
            ref = (ctx.league.avg_home + ctx.league.avg_away) / 2 or 110.0
            r = _basketball_team(team, ref)
            off, dfn_opp = r[0], r[1]
        else:
            r_off, r_def, cov_, note_ = _ratio_team(team, p, 11 if sport is Sport.FOOTBALL else 9)
            off = r_off ** p.lineup_beta
            dfn_opp = (1.0 / r_def) ** p.lineup_beta if sport is Sport.FOOTBALL else 1.0
            r = (off, dfn_opp, cov_, note_)
        off = clip(off, *p.lineup_clip)
        dfn_opp = clip(dfn_opp, 1 / p.lineup_clip[1], 1 / p.lineup_clip[0])
        res.append((off, dfn_opp, r[2], r[3]))
    (oh, dh, ch, nh), (oa, da, ca, na) = res
    return LayerOutput(
        "L1 alineación",
        home_mult=oh * da,
        away_mult=oa * dh,
        coverage=(ch + ca) / 2,
        notes=(f"Local: {nh}", f"Visita: {na}"),
    )
