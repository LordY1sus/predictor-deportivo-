"""Capa 4 — Estadística base: métricas estructurales de temporada ajustadas por rival.

Fútbol:     fuerzas IPF de goles (ajustadas por rival) + corrección por xG/tiros recientes.
Baloncesto: puntos esperados (IPF) descompuestos en ritmo (pace) y eficiencia (ORtg/DRtg),
            con regresión del % de triples (eFG%) hacia la media de la liga.
Béisbol:    wRC+ del ataque × (abridor FIP/xFIP regresado + bullpen) del rival × localía.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from ...core.enums import Sport
from ...core.stats import MatchContext, TeamData
from ..params import SportParams
from .common import InsufficientDataError, LayerOutput, clip, cut_time


@dataclass(frozen=True, slots=True)
class BaseRates:
    home_rate: float  # goles / puntos / carreras esperados del local
    away_rate: float
    pace: float | None = None  # baloncesto: posesiones por partido


def base_rates(ctx: MatchContext, p: SportParams) -> tuple[BaseRates, LayerOutput]:
    fn = {Sport.FOOTBALL: _football, Sport.BASKETBALL: _basketball, Sport.BASEBALL: _baseball}[ctx.match.sport]
    return fn(ctx, p)


# ------------------------------------------------------------------------- fútbol
XG_PRIOR_GOALS = 3.0  # pseudo-goles de contracción de la corrección xG
XG_WEIGHT = 0.35
XG_CLIP = (0.88, 1.12)
XG_LAST_N = 8


def _xg_ratios(team: TeamData, cut) -> tuple[float, float, int]:
    games = sorted((g for g in team.history if g.played_at < cut and g.xg_for is not None and g.xg_against is not None),
                   key=lambda g: g.played_at, reverse=True)[:XG_LAST_N]
    if len(games) < 3:
        return 1.0, 1.0, 0
    xf = sum(g.xg_for for g in games)  # type: ignore[misc]
    xa = sum(g.xg_against for g in games)  # type: ignore[misc]
    gf = sum(g.scored for g in games)
    ga = sum(g.conceded for g in games)
    return (xf + XG_PRIOR_GOALS) / (gf + XG_PRIOR_GOALS), (xa + XG_PRIOR_GOALS) / (ga + XG_PRIOR_GOALS), len(games)


def _football(ctx: MatchContext, p: SportParams) -> tuple[BaseRates, LayerOutput]:
    lg = ctx.league
    h, a = ctx.match.home.team_id, ctx.match.away.team_id
    vals = [lg.att.get(h), lg.defn.get(h), lg.att.get(a), lg.defn.get(a)]
    known = sum(v is not None for v in vals)
    if lg.n_games == 0 or known == 0:
        raise InsufficientDataError("Sin resultados de liga para estimar la fuerza de los equipos.")
    ah, dh, aa, da = (v if v is not None else 1.0 for v in vals)
    lam_h = lg.avg_home * ah * da
    lam_a = lg.avg_away * aa * dh
    notes = [f"Fuerzas IPF sobre {lg.n_games} partidos ({known}/4 equipos-rol con datos)."]

    cut = cut_time(ctx)
    hf_att, hf_def, nh = _xg_ratios(ctx.home, cut)
    af_att, af_def, na = _xg_ratios(ctx.away, cut)
    if nh and na:
        lam_h *= clip(hf_att ** XG_WEIGHT, *XG_CLIP) * clip(af_def ** XG_WEIGHT, *XG_CLIP)
        lam_a *= clip(af_att ** XG_WEIGHT, *XG_CLIP) * clip(hf_def ** XG_WEIGHT, *XG_CLIP)
        notes.append(f"Corrección xG/tiros ({nh}+{na} partidos recientes).")
    else:
        notes.append("Sin xG/tiros recientes suficientes: solo goles.")
    coverage = (known / 4) * (0.8 + 0.2 * (1.0 if (nh and na) else 0.0))
    return BaseRates(max(lam_h, 0.05), max(lam_a, 0.05)), LayerOutput("L4 base", coverage=coverage, notes=tuple(notes))


# --------------------------------------------------------------------- baloncesto
LEAGUE_THREE_PCT_DEFAULT = 0.36
THREE_PRIOR_ATTEMPTS = 300.0  # intentos de triple de contracción
EFG_TO_RTG = 2.0  # ΔORtg ≈ 2·(FGA/pos)·100·ΔeFG
RTG_ADJ_CAP = 3.0


def _three_adj(m, prefix: str, lg_three: float) -> float:
    """ΔRtg por regresión del % de triples (prefix '' = propio, 'opp_' = permitido)."""
    games = float(m.get("games_n", 0.0))
    tpa = float(m.get(prefix + "three_pa_pg", 0.0))
    tpm = float(m.get(prefix + "three_pm_pg", 0.0))
    fga = float(m.get(prefix + "fga_pg", 0.0))
    poss = float(m.get(prefix + "poss_pg", 0.0))
    if games <= 0 or tpa <= 0 or fga <= 0 or poss <= 0:
        return 0.0
    att, made = tpa * games, tpm * games
    reg = (made + THREE_PRIOR_ATTEMPTS * lg_three) / (att + THREE_PRIOR_ATTEMPTS)
    d_efg = 0.5 * (tpa / fga) * (reg - made / att)
    return clip(EFG_TO_RTG * (fga / poss) * 100 * d_efg, -RTG_ADJ_CAP, RTG_ADJ_CAP)


def _basketball(ctx: MatchContext, p: SportParams) -> tuple[BaseRates, LayerOutput]:
    lg = ctx.league
    h, a = ctx.match.home.team_id, ctx.match.away.team_id
    vals = [lg.att.get(h), lg.defn.get(h), lg.att.get(a), lg.defn.get(a)]
    known = sum(v is not None for v in vals)
    if lg.n_games == 0 or known == 0:
        raise InsufficientDataError("Sin resultados de liga para estimar la fuerza de los equipos.")
    ah, dh, aa, da = (v if v is not None else 1.0 for v in vals)
    pts_h = lg.avg_home * ah * da
    pts_a = lg.avg_away * aa * dh
    notes = [f"Puntos esperados IPF sobre {lg.n_games} partidos ({known}/4 equipos-rol con datos)."]

    lg_pace = float(lg.metrics.get("pace", 0.0)) or 99.0
    ph = float(ctx.home.metrics.get("pace", 0.0))
    pa = float(ctx.away.metrics.get("pace", 0.0))
    have_pace = ph > 0 and pa > 0
    pace = ph * pa / lg_pace if have_pace else lg_pace
    pace = clip(pace, 85.0, 115.0)
    notes.append(f"Pace esperado {pace:.1f}" + ("" if have_pace else " (promedio de liga: sin datos de equipo)"))

    lg3 = float(lg.metrics.get("three_pct", LEAGUE_THREE_PCT_DEFAULT))
    eff_h = pts_h / pace * 100
    eff_a = pts_a / pace * 100
    adj_h = _three_adj(ctx.home.metrics, "", lg3) + _three_adj(ctx.away.metrics, "opp_", lg3)
    adj_a = _three_adj(ctx.away.metrics, "", lg3) + _three_adj(ctx.home.metrics, "opp_", lg3)
    have_shots = bool(ctx.home.metrics.get("three_pa_pg") and ctx.away.metrics.get("three_pa_pg"))
    if have_shots:
        eff_h += adj_h
        eff_a += adj_a
        notes.append(f"Regresión eFG%/triples: local {adj_h:+.1f}, visita {adj_a:+.1f} pts/100 pos.")
    else:
        notes.append("Sin datos de tiro (eFG%) recientes.")
    coverage = (known / 4) * (0.6 + 0.2 * have_pace + 0.2 * bool(have_shots))
    return (
        BaseRates(max(pace * eff_h / 100, 40.0), max(pace * eff_a / 100, 40.0), pace),
        LayerOutput("L4 base", coverage=coverage, notes=tuple(notes)),
    )


# ------------------------------------------------------------------------- béisbol
SP_PRIOR_IP = 60.0  # entradas de contracción del abridor hacia la media de la liga
DEFAULT_SP_SHARE = 5.3 / 9.0


def _pitching_factor(team: TeamData, lg_fip: float, lg_bp: float) -> tuple[float | None, list[str]]:
    """Factor de carreras permitidas (1.0 = liga) = share·abridor + (1-share)·bullpen."""
    m = team.metrics
    notes: list[str] = []
    sp_fip = m.get("sp_fip")
    sp_x = m.get("sp_xfip", sp_fip)
    sp_ip = float(m.get("sp_ip", 0.0))
    bp = m.get("bullpen_fip")
    if sp_fip is None and bp is None:
        return None, notes
    if sp_fip is not None:
        blend = 0.5 * (sp_fip + (sp_x if sp_x is not None else sp_fip))
        reg = (sp_ip * blend + SP_PRIOR_IP * lg_fip) / (sp_ip + SP_PRIOR_IP)
        sp_factor = reg / lg_fip
    else:
        sp_factor = 1.0
        notes.append("sin abridor")
    bp_factor = (bp / lg_bp) if bp is not None else 1.0
    share = clip(float(m.get("sp_ip_per_start", 0.0)) / 9.0 or DEFAULT_SP_SHARE, 0.45, 0.72)
    return share * sp_factor + (1 - share) * bp_factor, notes


def _baseball(ctx: MatchContext, p: SportParams) -> tuple[BaseRates, LayerOutput]:
    lg = ctx.league
    lg_fip = float(lg.metrics.get("lg_fip", 0.0)) or 4.1
    lg_bp = float(lg.metrics.get("lg_bullpen_fip", 0.0)) or lg_fip
    lg_rpg = float(lg.metrics.get("runs_pg", 0.0)) or (lg.avg_home + lg.avg_away) / 2
    if lg_rpg <= 0:
        raise InsufficientDataError("Sin carreras por partido de la liga.")
    hfa = math.sqrt(lg.avg_home / lg.avg_away) if lg.avg_home > 0 and lg.avg_away > 0 else 1.0
    notes: list[str] = []
    present = 0.0

    def team_runs(off: TeamData, pit: TeamData, side_mult: float) -> float:
        nonlocal present
        wrc = off.metrics.get("wrc_plus")
        o = wrc / 100.0 if wrc else lg.att.get(off.team_id, 1.0)
        # Respaldo: fuerzas IPF de carreras (resultados) valen media cobertura; sin ellas, 0.
        present += 1.0 if wrc else (0.5 if off.team_id in lg.att else 0.0)
        f, n = _pitching_factor(pit, lg_fip, lg_bp)
        if f is None:
            f = lg.defn.get(pit.team_id, 1.0)
            present += 0.5 if pit.team_id in lg.defn else 0.0
        else:
            present += 1.0
        notes.extend(n)
        return lg_rpg * side_mult * o * f

    rate_h = team_runs(ctx.home, ctx.away, hfa)
    rate_a = team_runs(ctx.away, ctx.home, 1 / hfa)
    for t, lbl in ((ctx.home, "local"), (ctx.away, "visita")):
        if t.metrics.get("wrc_plus_is_proxy"):
            notes.append(f"wRC+ {lbl}: proxy por OPS (sin ajuste de parque).")
    if present == 0:
        raise InsufficientDataError("Sin wRC+/pitcheo para estimar carreras esperadas.")
    notes.insert(0, f"Carreras base {rate_h:.2f}–{rate_a:.2f} (liga {lg_rpg:.2f}/equipo).")
    return BaseRates(max(rate_h, 0.5), max(rate_a, 0.5)), LayerOutput("L4 base", coverage=present / 4, notes=tuple(notes))
