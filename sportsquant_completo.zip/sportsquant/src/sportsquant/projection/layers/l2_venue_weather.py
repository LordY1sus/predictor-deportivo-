"""Capa 2 — Sede, clima y escenarios similares."""
from __future__ import annotations

import math
import statistics

from ...core.enums import Sport
from ...core.stats import MatchContext, TeamData, Venue, Weather
from ..params import SportParams
from .common import LayerOutput, cut_time, damped, residual_ratios


def weather_multiplier(sport: Sport, venue: Venue, w: Weather | None) -> tuple[float, list[str]]:
    """Multiplicador común de anotación por clima (ambos equipos)."""
    if w is None or sport is Sport.BASKETBALL or venue.roof == "dome":
        return 1.0, []
    scale = 0.5 if venue.roof == "retractable" else 1.0
    mult, notes = 1.0, []
    if sport is Sport.FOOTBALL:
        if w.precip_mm is not None:
            if w.precip_mm >= 2.0:
                mult *= 0.97
                notes.append(f"lluvia fuerte ({w.precip_mm:.1f} mm/h)")
            elif w.precip_mm >= 0.5:
                mult *= 0.985
                notes.append(f"lluvia ({w.precip_mm:.1f} mm/h)")
        if w.wind_ms is not None:
            if w.wind_ms >= 10:
                mult *= 0.97
                notes.append(f"viento fuerte ({w.wind_ms:.0f} m/s)")
            elif w.wind_ms >= 7:
                mult *= 0.985
        if w.temp_c is not None and (w.temp_c >= 32 or w.temp_c <= 0):
            mult *= 0.98
            notes.append(f"temperatura extrema ({w.temp_c:.0f} °C)")
    else:  # béisbol
        eff = 0.0
        if w.temp_c is not None:
            eff += 0.004 * (w.temp_c - 20.0)
            notes.append(f"{w.temp_c:.0f} °C")
        if w.wind_out_ms is not None and w.wind_out_ms != 0:
            eff += 0.0112 * w.wind_out_ms  # ≈ 0.5 % por mph hacia afuera/adentro
            notes.append(f"viento {'afuera' if w.wind_out_ms > 0 else 'adentro'} {abs(w.wind_out_ms):.1f} m/s")
        mult *= 1 + max(-0.06, min(0.06, eff)) * scale
    return mult, notes


def _tier_fn(ctx: MatchContext):
    lg = ctx.league
    ratings = {t: lg.att[t] / lg.defn[t] for t in lg.att if t in lg.defn and lg.defn[t] > 0}
    if not ratings:
        return None
    med = statistics.median(ratings.values())
    return lambda team_id: None if team_id not in ratings else ratings[team_id] >= med


def _scenario(team: TeamData, ctx: MatchContext, p: SportParams, *, home_today: bool, opp_id: str, tier) -> tuple[float, float, int]:
    if tier is None or tier(opp_id) is None:
        return 1.0, 1.0, 0
    want = tier(opp_id)
    keep = lambda g: (not g.neutral) and g.is_home == home_today and tier(g.opponent_id) == want
    f_att, f_def, n = residual_ratios(
        team, ctx.league, cut_time(ctx), half_life=p.half_life_days * 3, prior=p.scenario_prior, keep=keep
    )
    if n < 3:
        return 1.0, 1.0, n
    return (damped(f_att, p.scenario_weight, p.scenario_clip), damped(f_def, p.scenario_weight, p.scenario_clip), n)


def venue_weather_layer(ctx: MatchContext, p: SportParams) -> LayerOutput:
    sport, lg, v = ctx.match.sport, ctx.league, ctx.venue
    hm = am = 1.0
    notes: list[str] = []
    present = total = 0

    if ctx.match.neutral_venue or v.neutral:
        if lg.avg_home > 0 and lg.avg_away > 0:
            r = math.sqrt(lg.avg_away / lg.avg_home)
            hm *= r
            am /= r
            notes.append("sede neutral: se elimina la ventaja de local")

    if sport is Sport.BASEBALL:
        total += 1
        if v.park_factor:
            present += 1
            f = 1 + p.park_weight * (v.park_factor - 1)
            hm *= f
            am *= f
            notes.append(f"park factor {v.park_factor:.2f} (aplicado {f:.3f})")

    if sport is not Sport.BASKETBALL:
        total += 1
        if ctx.weather is not None:
            present += 1
            wm, wn = weather_multiplier(sport, v, ctx.weather)
            hm *= wm
            am *= wm
            if wn:
                notes.append("clima: " + ", ".join(wn) + f" → ×{wm:.3f}")

    tier = _tier_fn(ctx)
    h_id, a_id = ctx.match.home.team_id, ctx.match.away.team_id
    sh = _scenario(ctx.home, ctx, p, home_today=True, opp_id=a_id, tier=tier)
    sa = _scenario(ctx.away, ctx, p, home_today=False, opp_id=h_id, tier=tier)
    hm *= sh[0] * sa[1]
    am *= sa[0] * sh[1]
    notes.append(f"escenarios similares: local×{sh[0]:.3f}/{sh[1]:.3f} ({sh[2]} p.), visita×{sa[0]:.3f}/{sa[1]:.3f} ({sa[2]} p.)")
    total += 1
    present += 1 if (sh[2] >= 3 and sa[2] >= 3) else 0
    return LayerOutput("L2 sede/clima", home_mult=hm, away_mult=am, coverage=present / total if total else 1.0, notes=tuple(notes))
