"""Tipos y utilidades compartidas por las 4 capas."""
from __future__ import annotations

import math
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from datetime import datetime

from ...core.stats import LeagueData, MatchContext, PastGame, TeamData
from ..ratings import decay_weight, expected_scores


class InsufficientDataError(RuntimeError):
    """No hay datos base suficientes para proyectar este partido."""


@dataclass(frozen=True, slots=True)
class LayerOutput:
    name: str
    home_mult: float = 1.0  # multiplicador de la tasa de anotación del local
    away_mult: float = 1.0
    coverage: float = 1.0  # 0..1: fracción de insumos disponibles
    notes: tuple[str, ...] = ()
    extras: Mapping[str, float] = field(default_factory=dict)


def clip(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def cut_time(ctx: MatchContext) -> datetime:
    """Instante t de corte: nunca posterior al inicio T."""
    kick = ctx.match.kickoff_utc
    return min(ctx.asof, kick) if ctx.asof else kick


def expected_for_game(lg: LeagueData, team_id: str, g: PastGame) -> tuple[float, float] | None:
    """(esperado a favor, esperado en contra) del equipo en un partido pasado, con las fuerzas actuales."""
    if g.is_home:
        return expected_scores(lg, team_id, g.opponent_id, g.neutral)
    r = expected_scores(lg, g.opponent_id, team_id, g.neutral)
    return (r[1], r[0]) if r else None


def residual_ratios(
    team: TeamData,
    lg: LeagueData,
    cut: datetime,
    *,
    half_life: float,
    prior: float,
    keep: Callable[[PastGame], bool] | None = None,
) -> tuple[float, float, int]:
    """Razón (real/esperado) ofensiva y defensiva con decaimiento exponencial y contracción.

    F_att = (Σw·anotado + k·ē) / (Σw·esperado + k·ē); k pseudo-partidos "exactamente esperados".
    Devuelve (F_att, F_def, partidos usados). F_def > 1 = recibió más de lo esperado.
    """
    w_sum = s = e = c = ec = 0.0
    used = 0
    for g in team.history:
        if g.played_at >= cut or (keep is not None and not keep(g)):
            continue
        exp = expected_for_game(lg, team.team_id, g)
        if exp is None:
            continue
        w = decay_weight((cut - g.played_at).total_seconds() / 86400, half_life) * g.weight
        w_sum += w
        s += w * g.scored
        c += w * g.conceded
        e += w * exp[0]
        ec += w * exp[1]
        used += 1
    if used == 0 or w_sum <= 0 or e <= 0 or ec <= 0:
        return 1.0, 1.0, 0
    ebar, ecbar = e / w_sum, ec / w_sum
    f_att = (s + prior * ebar) / (e + prior * ebar)
    f_def = (c + prior * ecbar) / (ec + prior * ecbar)
    return f_att, f_def, used


def damped(ratio: float, weight: float, bounds: tuple[float, float]) -> float:
    """exp(weight·ln ratio) acotado."""
    return clip(math.exp(weight * math.log(max(ratio, 1e-6))), *bounds)
