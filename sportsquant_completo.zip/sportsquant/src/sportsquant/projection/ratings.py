"""Fuerzas ofensiva/defensiva ajustadas por rival (modelo multiplicativo de Poisson, IPF)."""
from __future__ import annotations

import math
from collections.abc import Sequence
from datetime import datetime

import numpy as np

from ..core.stats import LeagueData, LeagueGame
from ..core.timeutil import to_utc


def decay_weight(age_days: float, half_life_days: float) -> float:
    return 0.5 ** (max(age_days, 0.0) / half_life_days)


def fit_league(
    games: Sequence[LeagueGame],
    *,
    asof: datetime | None = None,
    prior_games: float = 4.0,
    half_life_days: float | None = None,
    iterations: int = 80,
    metrics: dict[str, float] | None = None,
) -> LeagueData | None:
    """Ajusta E[local] = mu_h·att[local]·def[visita] y E[visita] = mu_a·att[visita]·def[local].

    Solo usa partidos con played_at < asof (regla t < T). Contrae cada equipo hacia 1.0 con
    `prior_games` pseudo-partidos promedio. Devuelve None si no hay partidos válidos.
    """
    if asof is not None:
        cut = to_utc(asof)
        games = [g for g in games if to_utc(g.played_at) < cut]
    if not games:
        return None
    ref = to_utc(asof) if asof is not None else max(to_utc(g.played_at) for g in games)
    ids = sorted({g.home_id for g in games} | {g.away_id for g in games})
    idx = {t: i for i, t in enumerate(ids)}
    n = len(ids)
    h = np.array([idx[g.home_id] for g in games])
    a = np.array([idx[g.away_id] for g in games])
    hs = np.array([g.home_score for g in games], dtype=float)
    as_ = np.array([g.away_score for g in games], dtype=float)
    neutral = np.array([g.neutral for g in games], dtype=bool)
    if half_life_days:
        ages = np.array([(ref - to_utc(g.played_at)).total_seconds() / 86400 for g in games])
        w = 0.5 ** (np.maximum(ages, 0) / half_life_days)
    else:
        w = np.ones(len(games))

    side = ~neutral if (~neutral).any() else np.ones(len(games), dtype=bool)
    mu_h = float(np.average(hs[side], weights=w[side]))
    mu_a = float(np.average(as_[side], weights=w[side]))
    mu_h, mu_a = max(mu_h, 1e-6), max(mu_a, 1e-6)
    mid = math.sqrt(mu_h * mu_a)
    mh = np.where(neutral, mid, mu_h)
    ma = np.where(neutral, mid, mu_a)
    prior = prior_games * (mu_h + mu_a) / 2

    att = np.ones(n)
    dfn = np.ones(n)
    for _ in range(iterations):
        num = np.bincount(h, w * hs, n) + np.bincount(a, w * as_, n)
        den = np.bincount(h, w * mh * dfn[a], n) + np.bincount(a, w * ma * dfn[h], n)
        att = (num + prior) / (den + prior)
        num_d = np.bincount(a, w * hs, n) + np.bincount(h, w * as_, n)
        den_d = np.bincount(a, w * mh * att[h], n) + np.bincount(h, w * ma * att[a], n)
        dfn = (num_d + prior) / (den_d + prior)
        att /= att.mean()
        dfn /= dfn.mean()

    return LeagueData(
        avg_home=mu_h,
        avg_away=mu_a,
        att={t: float(att[i]) for t, i in idx.items()},
        defn={t: float(dfn[i]) for t, i in idx.items()},
        n_games=len(games),
        metrics=dict(metrics or {}),
    )


def expected_scores(
    lg: LeagueData, home_id: str, away_id: str, neutral: bool = False
) -> tuple[float, float] | None:
    """(esperado local, esperado visita) con las fuerzas IPF, o None si falta algún equipo."""
    ah, dh = lg.att.get(home_id), lg.defn.get(home_id)
    aa, da = lg.att.get(away_id), lg.defn.get(away_id)
    if None in (ah, dh, aa, da):
        return None
    mh, ma = lg.avg_home, lg.avg_away
    if neutral:
        mh = ma = math.sqrt(mh * ma)
    return mh * ah * da, ma * aa * dh  # type: ignore[operator]
