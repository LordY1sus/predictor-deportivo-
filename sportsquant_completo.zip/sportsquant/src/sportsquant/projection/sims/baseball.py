"""Béisbol: carreras Binomial Negativa (Gamma-Poisson) + entradas extra con corredor fantasma."""
from __future__ import annotations

import numpy as np

from .common import SimSummary, summarize

RUN_SHAPE = 4.0  # var = λ + λ²/4 ≈ 2.1·λ a λ=4.5 (dispersión observada en MLB)
EXTRA_INNING_RUN_MULT = 2.0  # el corredor fantasma duplica aprox. las carreras por entrada
MAX_EXTRA_INNINGS = 12


def simulate_baseball(
    rate_h: float, rate_a: float, n: int, rng: np.random.Generator, *, pace: float | None = None,
    shape: float = RUN_SHAPE,
) -> SimSummary:
    gh = rng.gamma(shape, 1.0 / shape, n)
    ga = rng.gamma(shape, 1.0 / shape, n)
    hg = rng.poisson(rate_h * gh).astype(np.int64)
    ag = rng.poisson(rate_a * ga).astype(np.int64)
    tie = hg == ag
    per_h = rate_h / 9.0 * EXTRA_INNING_RUN_MULT
    per_a = rate_a / 9.0 * EXTRA_INNING_RUN_MULT
    for _ in range(MAX_EXTRA_INNINGS):
        k = int(tie.sum())
        if k == 0:
            break
        hg[tie] += rng.poisson(per_h, k)
        ag[tie] += rng.poisson(per_a, k)
        tie = hg == ag
    k = int(tie.sum())
    if k:  # tras 12 entradas extra: moneda justa
        home_wins = rng.random(k) < 0.5
        hg[tie] += home_wins.astype(np.int64)
        ag[tie] += (~home_wins).astype(np.int64)
    return summarize(hg, ag, draws=False)
