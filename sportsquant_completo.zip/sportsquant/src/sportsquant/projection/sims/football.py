"""Fútbol: Poisson con incertidumbre de tasa (Gamma) y corrección Dixon-Coles de marcadores bajos."""
from __future__ import annotations

import numpy as np

from .common import SimSummary, summarize

RHO = -0.05  # dependencia en marcadores bajos (Dixon-Coles); típico entre -0.03 y -0.10
RATE_SHAPE = 25.0  # Gamma(k, 1/k): CV de la tasa = 1/√k = 20 % (incertidumbre del modelo)


def simulate_football(
    rate_h: float, rate_a: float, n: int, rng: np.random.Generator, *, pace: float | None = None,
    rho: float = RHO, shape: float = RATE_SHAPE,
) -> SimSummary:
    rate_h, rate_a = max(rate_h, 0.05), max(rate_a, 0.05)
    gh = rng.gamma(shape, 1.0 / shape, n)
    ga = rng.gamma(shape, 1.0 / shape, n)
    hg = rng.poisson(rate_h * gh)
    ag = rng.poisson(rate_a * ga)
    w = np.ones(n)
    w[(hg == 0) & (ag == 0)] = 1.0 - rate_h * rate_a * rho
    w[(hg == 0) & (ag == 1)] = 1.0 + rate_h * rho
    w[(hg == 1) & (ag == 0)] = 1.0 + rate_a * rho
    w[(hg == 1) & (ag == 1)] = 1.0 - rho
    w = np.clip(w, 0.05, None)
    return summarize(hg, ag, draws=True, weights=w)
