"""Resumen común de una simulación Monte Carlo."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True, slots=True)
class SimSummary:
    probs: dict[str, float]
    se: dict[str, float]
    exp_home: float
    exp_away: float
    top_scores: tuple[tuple[int, int, float], ...]
    margin_sd: float
    total_sd: float


def summarize(
    hg: np.ndarray, ag: np.ndarray, *, draws: bool, weights: np.ndarray | None = None, top: int = 5
) -> SimSummary:
    """Probabilidades (con pesos opcionales), error estándar y marcadores más probables."""
    n = len(hg)
    w = np.ones(n) if weights is None else weights
    total_w = float(w.sum())
    n_eff = total_w**2 / float((w**2).sum())
    outcomes = {"HOME": hg > ag, "AWAY": ag > hg}
    if draws:
        outcomes["DRAW"] = hg == ag
    probs, se = {}, {}
    for k, mask in outcomes.items():
        p = float((w * mask).sum() / total_w)
        probs[k] = p
        se[k] = float(np.sqrt(max(p * (1 - p), 0.0) / n_eff))
    cap = 9
    flat = np.minimum(hg, cap) * (cap + 1) + np.minimum(ag, cap)
    hist = np.bincount(flat.astype(np.int64), weights=w, minlength=(cap + 1) ** 2) / total_w
    order = np.argsort(hist)[::-1][:top]
    top_scores = tuple((int(i // (cap + 1)), int(i % (cap + 1)), float(hist[i])) for i in order)
    margin = (hg - ag).astype(float)
    total = (hg + ag).astype(float)
    return SimSummary(
        probs=probs, se=se,
        exp_home=float((w * hg).sum() / total_w), exp_away=float((w * ag).sum() / total_w),
        top_scores=top_scores,
        margin_sd=float(np.sqrt(np.average((margin - np.average(margin, weights=w)) ** 2, weights=w))),
        total_sd=float(np.sqrt(np.average((total - np.average(total, weights=w)) ** 2, weights=w))),
    )
