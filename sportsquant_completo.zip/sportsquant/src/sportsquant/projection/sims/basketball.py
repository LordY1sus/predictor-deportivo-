"""Baloncesto: posesiones compartidas × puntos por posesión (ruido) + incertidumbre de fuerza; prórroga."""
from __future__ import annotations

import numpy as np

from .common import SimSummary, summarize

PACE_SD = 3.0  # desviación de posesiones por partido
PPP_SD = 0.08  # ruido de puntos por posesión (≈ 8 pts/equipo → margen ≈ 12)
STRENGTH_SD = 2.5  # incertidumbre de la fuerza esperada (pts)
OT_POSSESSIONS = (10.5, 1.2)  # media y sd de posesiones por equipo en 5 min


def simulate_basketball(
    rate_h: float, rate_a: float, n: int, rng: np.random.Generator, *, pace: float | None = None,
    pace_sd: float = PACE_SD, ppp_sd: float = PPP_SD, strength_sd: float = STRENGTH_SD,
) -> SimSummary:
    pace = float(pace or 99.0)
    ppp_h, ppp_a = rate_h / pace, rate_a / pace
    poss = np.clip(rng.normal(pace, pace_sd, n), 70.0, None)
    pts_h = np.rint(poss * (ppp_h + rng.normal(0, ppp_sd, n)) + rng.normal(0, strength_sd, n)).astype(np.int64)
    pts_a = np.rint(poss * (ppp_a + rng.normal(0, ppp_sd, n)) + rng.normal(0, strength_sd, n)).astype(np.int64)
    tie = pts_h == pts_a
    for _ in range(8):
        k = int(tie.sum())
        if k == 0:
            break
        po = np.clip(rng.normal(*OT_POSSESSIONS, k), 6.0, None)
        pts_h[tie] += np.rint(po * (ppp_h + rng.normal(0, ppp_sd, k))).astype(np.int64)
        pts_a[tie] += np.rint(po * (ppp_a + rng.normal(0, ppp_sd, k))).astype(np.int64)
        tie = pts_h == pts_a
    k = int(tie.sum())
    if k:  # desempate residual (prácticamente inexistente tras 8 prórrogas): 50/50
        home_wins = rng.random(k) < 0.5
        pts_h[tie] += home_wins.astype(np.int64)
        pts_a[tie] += (~home_wins).astype(np.int64)
    return summarize(pts_h, pts_a, draws=False)
