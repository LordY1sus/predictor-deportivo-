"""Diagnóstico de fuentes de datos (requiere red): `python -m sportsquant.tools.check_sources [--sport football]`.

Comprueba, deporte por deporte, que cada endpoint responde y que el parseo encuentra partidos,
cuotas y alineaciones oficiales. Útil tras actualizaciones de las APIs públicas (ESPN/MLB).
"""
from __future__ import annotations

import argparse
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from ..core.enums import MatchStatus, Sport
from ..matches.gate import projection_gate
from ..projection.results import DEFAULT_SIMULATIONS
from ..services import create_services


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--sport", choices=[s.value for s in Sport], help="Solo este deporte")
    ap.add_argument("--project", action="store_true", help="Intenta proyectar el primer partido con alineación oficial")
    args = ap.parse_args(argv)
    svc = create_services(Path(tempfile.mkdtemp(prefix="sq-check-")))
    exit_code = 0
    for sport in (Sport(args.sport),) if args.sport else tuple(Sport):
        print(f"\n=== {sport.value} ===")
        report = svc.matches.refresh(sport)
        if report.error:
            print(f"  ✗ la fuente falló: {report.error}")
            exit_code = 1
            continue
        matches = svc.matches.today_matches(sport)
        now = datetime.now(timezone.utc)
        by_status = {s: sum(1 for m in matches if m.status is s) for s in MatchStatus}
        print(f"  partidos recibidos {report.fetched} · visibles hoy {report.visible} · descartados {len(report.skipped)}")
        print(f"  SCHEDULED {by_status[MatchStatus.SCHEDULED]} · LIVE {by_status[MatchStatus.LIVE]}")
        print(f"  con cuotas {sum(1 for m in matches if m.odds)} · con alineación oficial "
              f"{sum(1 for m in matches if projection_gate(m, now).lineup and projection_gate(m, now).lineup.ok)}")
        for s in report.skipped[:5]:
            print(f"  · descartado: {s}")
        ready = next((m for m in matches if projection_gate(m, now).allowed), None)
        if args.project and ready:
            status = svc.worker.submit(ready.match_id, DEFAULT_SIMULATIONS, wait=True)
            print(f"  proyección de {ready.title}: {status.state.value} · {status.message}")
            if status.result:
                r = status.result
                print(f"    probs {({k: round(v, 3) for k, v in r.probs.items()})} · cobertura {r.coverage:.0%}")
                for layer in r.layers:
                    print(f"    {layer.name}: cobertura {layer.coverage:.0%}")
            exit_code |= int(status.state.value == "ERROR")
        elif args.project:
            print("  (ningún partido listo para proyectar ahora: faltan alineaciones oficiales)")
    svc.close()
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
